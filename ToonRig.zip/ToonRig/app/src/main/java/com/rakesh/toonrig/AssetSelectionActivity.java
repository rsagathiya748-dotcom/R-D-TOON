package com.rakesh.toonrig;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;

public class AssetSelectionActivity extends Activity {
    private Button btnAssetBack, tabMovingObjects, tabProps, btnImportAsset;
    private GridView assetGridView;
    
    // STATIC CLASS TAAKI DATA SAVE RAHE
    public static class AssetItem {
        String name; int resId; Uri imageUri;
        public AssetItem(String name, int resId, Uri uri) { 
            this.name = name; this.resId = resId; this.imageUri = uri; 
        }
    }

    public static ArrayList<AssetItem> assetsList = new ArrayList<>();
    private AssetAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asset_selection);

        btnAssetBack = findViewById(R.id.btnAssetBack);
        tabMovingObjects = findViewById(R.id.tabMovingObjects);
        tabProps = findViewById(R.id.tabProps);
        btnImportAsset = findViewById(R.id.btnImportAsset);
        assetGridView = findViewById(R.id.assetGridView);

        if (assetsList.isEmpty()) {
            assetsList.add(new AssetItem("Tree", 0, null));
            assetsList.add(new AssetItem("Chair", 0, null));
        }

        adapter = new AssetAdapter(this, assetsList);
        assetGridView.setAdapter(adapter);

        btnAssetBack.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); } 
        });

        tabMovingObjects.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Build.VERSION.SDK_INT >= 21) {
                    tabMovingObjects.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#D19035"))); 
                    tabProps.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#424242"))); 
                }
            }
        });

        tabProps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Build.VERSION.SDK_INT >= 21) {
                    tabProps.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#D19035"))); 
                    tabMovingObjects.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#424242"))); 
                }
            }
        });

        btnImportAsset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); 
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*"); 
                startActivityForResult(intent, 202);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 202 && resultCode == RESULT_OK && data != null) {
            try {
                // PHOTO HAMESHA KE LIYE SAVE RAKHNE KA LOGIC
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    getContentResolver().takePersistableUriPermission(data.getData(), Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
            } catch (Exception e) {}
            assetsList.add(new AssetItem("Imported Prop", 0, data.getData()));
            adapter.notifyDataSetChanged();
        }
    }

    class AssetAdapter extends BaseAdapter {
        Context context; ArrayList<AssetItem> list;
        AssetAdapter(Context c, ArrayList<AssetItem> l) { this.context = c; this.list = l; }
        @Override public int getCount() { return list.size(); }
        @Override public Object getItem(int pos) { return list.get(pos); }
        @Override public long getItemId(int pos) { return pos; }
        
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout layout = new LinearLayout(context);
            layout.setOrientation(LinearLayout.VERTICAL); 
            layout.setGravity(Gravity.CENTER); 
            layout.setPadding(10, 10, 10, 10);
            
            AssetItem item = list.get(position);
            
            if(item.imageUri != null) {
                ImageView iv = new ImageView(context); 
                iv.setLayoutParams(new LinearLayout.LayoutParams(150, 150));
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP); 
                iv.setImageURI(item.imageUri); 
                layout.addView(iv);
            } else if(item.resId != 0) {
                ImageView iv = new ImageView(context); 
                iv.setLayoutParams(new LinearLayout.LayoutParams(150, 150));
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP); 
                iv.setImageResource(item.resId); 
                layout.addView(iv);
            } else {
                View placeholder = new View(context); 
                placeholder.setLayoutParams(new LinearLayout.LayoutParams(150, 150));
                placeholder.setBackgroundColor(Color.parseColor("#888888")); 
                layout.addView(placeholder);
            }

            TextView tv = new TextView(context); 
            tv.setText(item.name); 
            tv.setTextColor(Color.WHITE);
            tv.setGravity(Gravity.CENTER); 
            tv.setPadding(0, 10, 0, 0); 
            layout.addView(tv);
            return layout;
        }
    }
}
