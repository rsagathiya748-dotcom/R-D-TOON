package com.rakesh.toonrig;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class CharacterStorage {

    private static final String PREF_NAME = "ToonRig_Custom_Chars";
    private static final String KEY_CHARS = "custom_characters_list";

    // 1. Storage me Bitmap photo save karne ke liye
    public static String saveBitmapInternal(Context context, Bitmap bmp, String prefix) {
        try {
            File dir = context.getDir("custom_chars_images", Context.MODE_PRIVATE);
            String fileName = prefix + "_" + System.currentTimeMillis() + ".png";
            File myPath = new File(dir, fileName);
            
            FileOutputStream fos = new FileOutputStream(myPath);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
            
            return myPath.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    // 2. Naya Character entry database me jodna (AB VERSION BHI SAVE HOGA)
    public static void addCustomCharacter(Context context, String name, String filePath, int type, int version) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            String currentData = prefs.getString(KEY_CHARS, "[]");
            JSONArray array = new JSONArray(currentData);
            JSONArray newArray = new JSONArray();

            // Agar is naam ka character pehle se hai, toh usko list me mat dalo (Purana hatao)
            for (int i = 0; i < array.length(); i++) {
                JSONObject existingObj = array.getJSONObject(i);
                if (!existingObj.getString("name").equals(name)) {
                    newArray.put(existingObj);
                }
            }

            // Naya (ya updated) character daalo
            JSONObject obj = new JSONObject();
            obj.put("name", name);
            obj.put("path", filePath);
            obj.put("type", type); 
            obj.put("version", version); //  Version yahan save ho raha hai

            newArray.put(obj);
            prefs.edit().putString(KEY_CHARS, newArray.toString()).apply();
        } catch (Exception e) {}
    }

    // 3. Saare Custom Characters ki list nikalna (AB VERSION BHI READ HOGA)
    public static ArrayList<CharacterModel> getCustomCharacters(Context context) {
        ArrayList<CharacterModel> list = new ArrayList<>();
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            String currentData = prefs.getString(KEY_CHARS, "[]");
            JSONArray array = new JSONArray(currentData);

            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                String name = obj.getString("name");
                String path = obj.getString("path");
                
                int type = obj.optInt("type", CharacterModel.TYPE_CUSTOM);
                int version = obj.optInt("version", 1); //  Default version 1 rahega
                
                // TYPE AUR VERSION KE HISAB SE LIST ME ADD HOGA
                list.add(new CharacterModel(name, path, type, version));
            }
        } catch (Exception e) {}
        return list;
    }

    // 4. DELETE LOGIC
    public static void removeCustomCharacter(Context context, String filePath) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            String currentData = prefs.getString(KEY_CHARS, "[]");
            JSONArray array = new JSONArray(currentData);
            JSONArray newArray = new JSONArray();

            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                String path = obj.getString("path");
                if (!path.equals(filePath)) {
                    newArray.put(obj);
                }
            }
            prefs.edit().putString(KEY_CHARS, newArray.toString()).apply();

            File file = new File(filePath);
            if (file.exists()) {
                file.delete();
            }
        } catch (Exception e) {}
    }

    // 5. RENAME LOGIC
    public static void renameCustomCharacter(Context context, String filePath, String newName) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            String currentData = prefs.getString(KEY_CHARS, "[]");
            JSONArray array = new JSONArray(currentData);

            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                String path = obj.getString("path");
                
                if (path.equals(filePath)) {
                    obj.put("name", newName);
                    break;
                }
            }
            prefs.edit().putString(KEY_CHARS, array.toString()).apply();
        } catch (Exception e) {}
    }
}
