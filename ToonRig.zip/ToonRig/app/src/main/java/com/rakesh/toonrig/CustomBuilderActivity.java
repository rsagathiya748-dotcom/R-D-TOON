package com.rakesh.toonrig;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout; 
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;

public class CustomBuilderActivity extends Activity {

    private int currentPose = 1; 
    private int activePartIdx = -1;
    private String customCharName = "My Custom Char";
    
    private String[] partNames = {"Head", "Torso", "L-Arm Top", "L-Arm Bot", "R-Arm Top", "R-Arm Bot", "L-Leg Top", "L-Leg Bot", "L-Foot", "R-Leg Top", "R-Leg Bot", "R-Foot"};
    private int[] baseIndices = {0, 5, 15, 25, 10, 20, 35, 45, 55, 30, 40, 50}; 
    
    private Bitmap[] templateParts = new Bitmap[60];  
    private Bitmap[] originalParts = new Bitmap[60];  
    private Bitmap[] savedCustomParts = new Bitmap[60]; 
    private Bitmap[] poseParts = new Bitmap[12];     
    
    private float[] partX = new float[12];
    private float[] partY = new float[12];
    private float[] partScale = new float[12];
    
    private float[] savedX = new float[60];
    private float[] savedY = new float[60];
    private float[] savedScale = new float[60];

    private int[] partZ = {60, 40, 10, 15, 50, 55, 20, 25, 26, 30, 35, 36}; 

    private LinearLayout leftPanelList, controlsContainer, cropControlsContainer;
    private TextView tvTitle;
    private Button btnNextPose, btnSaveExit, btnImport;
    private BuilderView builderView;
    private CropView cropView;

    private Bitmap tempUncroppedBmp;
    private boolean isCroppingMode = false;

    public float sheetW = 1000f;
    public float sheetH = 1000f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inScaled = false; 
        
        Bitmap tempSheetRaw = null;
        Bitmap origSheetRaw = null;
        try { tempSheetRaw = BitmapFactory.decodeResource(getResources(), R.drawable.template_char, opts); } catch (Exception e) {}
        try { origSheetRaw = BitmapFactory.decodeResource(getResources(), R.drawable.character_sheet, opts); } catch (Exception e) {}
        
        if (tempSheetRaw != null) { sheetW = tempSheetRaw.getWidth(); sheetH = tempSheetRaw.getHeight(); } 
        else if (origSheetRaw != null) { sheetW = origSheetRaw.getWidth(); sheetH = origSheetRaw.getHeight(); }

        Bitmap tempSheet = tempSheetRaw;
        Bitmap origSheet = origSheetRaw;
        
        if (tempSheet != null && (tempSheet.getWidth() != sheetW || tempSheet.getHeight() != sheetH)) {
            tempSheet = Bitmap.createScaledBitmap(tempSheetRaw, (int)sheetW, (int)sheetH, true);
        }
        if (origSheet != null && (origSheet.getWidth() != sheetW || origSheet.getHeight() != sheetH)) {
            origSheet = Bitmap.createScaledBitmap(origSheetRaw, (int)sheetW, (int)sheetH, true);
        }

        if (sheetW > 0 && sheetH > 0) {
            for (int i = 0; i < 60; i++) {
                float[] rect = CharacterSheetView.cropParts[i];
                if (rect != null && rect.length >= 4) {
                    float valX = rect[0], valY = rect[1], valW = rect[2], valH = rect[3];
                    float x, y, w, h;
                    
                    if (valW <= 1.0f && valH <= 1.0f) { x = valX * sheetW; y = valY * sheetH; w = valW * sheetW; h = valH * sheetH; } 
                    else if (valW <= 100.0f) { x = (valX / 100f) * sheetW; y = (valY / 100f) * sheetH; w = (valW / 100f) * sheetW; h = (valH / 100f) * sheetH; } 
                    else { x = valX; y = valY; w = valW; h = valH; }
                    
                    int ix = Math.max(0, Math.min((int)x, (int)sheetW - 1));
                    int iy = Math.max(0, Math.min((int)y, (int)sheetH - 1));
                    int iw = Math.max(1, Math.min((int)w, (int)sheetW - ix));
                    int ih = Math.max(1, Math.min((int)h, (int)sheetH - iy));

                    if (tempSheet != null) templateParts[i] = Bitmap.createBitmap(tempSheet, ix, iy, iw, ih);
                    if (origSheet != null) originalParts[i] = Bitmap.createBitmap(origSheet, ix, iy, iw, ih);
                }
            }
        }

        // ==========================================
        // EDIT MODE: Puraane parts ko list me load karta hai
        // ==========================================
        String editPath = getIntent().getStringExtra("EDIT_PATH");
        if (editPath != null && !editPath.isEmpty()) {
            Bitmap editSheetRaw = BitmapFactory.decodeFile(editPath);
            if (editSheetRaw != null) {
                Bitmap editSheet = Bitmap.createScaledBitmap(editSheetRaw, (int)sheetW, (int)sheetH, true);
                
                for (int i = 0; i < 60; i++) {
                    float[] rect = CharacterSheetView.cropParts[i];
                    if (rect != null && rect.length >= 4) {
                        float valX = rect[0], valY = rect[1], valW = rect[2], valH = rect[3];
                        float x = valW <= 1.0f ? valX * sheetW : (valX <= 100f ? (valX/100f)*sheetW : valX);
                        float y = valH <= 1.0f ? valY * sheetH : (valY <= 100f ? (valY/100f)*sheetH : valY);
                        float w = valW <= 1.0f ? valW * sheetW : (valW <= 100f ? (valW/100f)*sheetW : valW);
                        float h = valH <= 1.0f ? valH * sheetH : (valH <= 100f ? (valH/100f)*sheetH : valH);

                        int ix = Math.max(0, Math.min((int)x, (int)sheetW - 1));
                        int iy = Math.max(0, Math.min((int)y, (int)sheetH - 1));
                        int iw = Math.max(1, Math.min((int)w, (int)sheetW - ix));
                        int ih = Math.max(1, Math.min((int)h, (int)sheetH - iy));

                        savedCustomParts[i] = Bitmap.createBitmap(editSheet, ix, iy, iw, ih);
                        savedX[i] = 0; savedY[i] = 0; savedScale[i] = 1.0f;
                    }
                }
                String oldName = getIntent().getStringExtra("EDIT_NAME");
                if (oldName != null) { customCharName = oldName; }
                Toast.makeText(this, "Editing Mode Ready!", Toast.LENGTH_SHORT).show();
            }
        }

        // UI Setup
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.HORIZONTAL); root.setBackgroundColor(Color.parseColor("#1E1E1E"));
        
        ScrollView leftScroll = new ScrollView(this); leftScroll.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(140), ViewGroup.LayoutParams.MATCH_PARENT)); leftScroll.setBackgroundColor(Color.parseColor("#252525"));
        leftPanelList = new LinearLayout(this); leftPanelList.setOrientation(LinearLayout.VERTICAL); leftPanelList.setPadding(10, 10, 10, 10);
        TextView lblParts = new TextView(this); lblParts.setText("BODY PARTS"); lblParts.setTextColor(Color.WHITE); lblParts.setTextSize(14f); lblParts.setGravity(Gravity.CENTER); lblParts.setPadding(0,0,0,20); leftPanelList.addView(lblParts);
        
        for (int i = 0; i < 12; i++) {
            Button btn = new Button(this); btn.setText(partNames[i] + "\n(LOCKED)"); btn.setTextSize(10f); btn.setId(100 + i);
            btn.setBackgroundColor(Color.parseColor("#D32F2F")); btn.setTextColor(Color.WHITE);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(0, 0, 0, 10); btn.setLayoutParams(lp);
            final int index = i;
            btn.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { 
                    if(isCroppingMode) { Toast.makeText(CustomBuilderActivity.this, "Pehle Crop Apply ya Cancel karo!", Toast.LENGTH_SHORT).show(); return; }
                    activePartIdx = index; refreshLeftPanelUI(); builderView.invalidate(); 
                }
            });
            leftPanelList.addView(btn);
        }
        leftScroll.addView(leftPanelList); root.addView(leftScroll);

        LinearLayout centerLayout = new LinearLayout(this); centerLayout.setOrientation(LinearLayout.VERTICAL); centerLayout.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        tvTitle = new TextView(this); tvTitle.setText("TEMPLATE SWAP: POSE 1 / 5"); tvTitle.setTextColor(Color.parseColor("#FFCA28")); tvTitle.setTextSize(18f); tvTitle.setGravity(Gravity.CENTER); tvTitle.setPadding(10,10,10,10); centerLayout.addView(tvTitle);
        
        FrameLayout canvasContainer = new FrameLayout(this);
        canvasContainer.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        builderView = new BuilderView(this); canvasContainer.addView(builderView);
        cropView = new CropView(this); cropView.setVisibility(View.GONE); canvasContainer.addView(cropView);
        centerLayout.addView(canvasContainer); root.addView(centerLayout);

        ScrollView rightScroll = new ScrollView(this); rightScroll.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(160), ViewGroup.LayoutParams.MATCH_PARENT)); rightScroll.setBackgroundColor(Color.parseColor("#252525"));
        LinearLayout rightPanel = new LinearLayout(this); rightPanel.setOrientation(LinearLayout.VERTICAL); rightPanel.setPadding(15, 15, 15, 15);

        controlsContainer = new LinearLayout(this); controlsContainer.setOrientation(LinearLayout.VERTICAL);
        controlsContainer.addView(createHeader("MOVE PART"));
        LinearLayout row1 = new LinearLayout(this); row1.setGravity(Gravity.CENTER); Button btnUp = createCtrlBtn("UP"); row1.addView(btnUp); controlsContainer.addView(row1);
        LinearLayout row2 = new LinearLayout(this); row2.setGravity(Gravity.CENTER); Button btnL = createCtrlBtn("L"); Button btnR = createCtrlBtn("R"); row2.addView(btnL); row2.addView(btnR); controlsContainer.addView(row2);
        LinearLayout row3 = new LinearLayout(this); row3.setGravity(Gravity.CENTER); Button btnDn = createCtrlBtn("DN"); row3.addView(btnDn); controlsContainer.addView(row3);

        controlsContainer.addView(createHeader("SCALE"));
        LinearLayout rowScale = new LinearLayout(this); rowScale.setGravity(Gravity.CENTER); Button btnSclM = createCtrlBtn("-"); Button btnSclP = createCtrlBtn("+"); rowScale.addView(btnSclM); rowScale.addView(btnSclP); controlsContainer.addView(rowScale);

        btnImport = new Button(this); btnImport.setText("IMPORT PNG"); btnImport.setBackgroundColor(Color.parseColor("#00897B")); btnImport.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams lpBtn = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lpBtn.setMargins(0, 30, 0, 10); btnImport.setLayoutParams(lpBtn); controlsContainer.addView(btnImport);

        btnNextPose = new Button(this); btnNextPose.setText("NEXT POSE "); btnNextPose.setBackgroundColor(Color.parseColor("#424242")); btnNextPose.setTextColor(Color.GRAY); btnNextPose.setLayoutParams(lpBtn); controlsContainer.addView(btnNextPose);

        btnSaveExit = new Button(this); btnSaveExit.setText("FINISH & SAVE"); btnSaveExit.setBackgroundColor(Color.parseColor("#4CAF50")); btnSaveExit.setTextColor(Color.WHITE); btnSaveExit.setLayoutParams(lpBtn); controlsContainer.addView(btnSaveExit);
        rightPanel.addView(controlsContainer);

        cropControlsContainer = new LinearLayout(this); cropControlsContainer.setOrientation(LinearLayout.VERTICAL); cropControlsContainer.setVisibility(View.GONE);
        cropControlsContainer.addView(createHeader("CROP MODE"));
        TextView cropInst = new TextView(this); cropInst.setText("Box draw karke part select karein!"); cropInst.setTextColor(Color.parseColor("#FFCA28")); cropInst.setTextSize(12f); cropInst.setGravity(Gravity.CENTER); cropInst.setPadding(0,20,0,20); cropControlsContainer.addView(cropInst);
        Button btnCropApply = new Button(this); btnCropApply.setText(" CROP & APPLY"); btnCropApply.setBackgroundColor(Color.parseColor("#4CAF50")); btnCropApply.setTextColor(Color.WHITE); btnCropApply.setLayoutParams(lpBtn); cropControlsContainer.addView(btnCropApply);
        Button btnCropCancel = new Button(this); btnCropCancel.setText(" CANCEL"); btnCropCancel.setBackgroundColor(Color.parseColor("#D32F2F")); btnCropCancel.setTextColor(Color.WHITE); btnCropCancel.setLayoutParams(lpBtn); cropControlsContainer.addView(btnCropCancel);
        rightPanel.addView(cropControlsContainer);
        rightScroll.addView(rightPanel); root.addView(rightScroll); setContentView(root);

        // ==========================================
        //  FIX: LOAD POSE 1 AUTOMATICALLY IN UI 
        // ==========================================
        loadPoseState(); // Pehle se maujood parts ko poseParts array me load karega

        // Events
        btnImport.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if(activePartIdx == -1) { Toast.makeText(CustomBuilderActivity.this, "Left panel se Body Part select karo!", Toast.LENGTH_SHORT).show(); return; }
                Intent intent = new Intent(Intent.ACTION_PICK); intent.setType("image/*"); startActivityForResult(intent, 500);
            }
        });

        btnUp.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activePartIdx!=-1){ partY[activePartIdx]-=5; builderView.invalidate();} }});
        btnDn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activePartIdx!=-1){ partY[activePartIdx]+=5; builderView.invalidate();} }});
        btnL.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activePartIdx!=-1){ partX[activePartIdx]-=5; builderView.invalidate();} }});
        btnR.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activePartIdx!=-1){ partX[activePartIdx]+=5; builderView.invalidate();} }});
        btnSclM.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activePartIdx!=-1){ partScale[activePartIdx]-=0.02f; builderView.invalidate();} }});
        btnSclP.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activePartIdx!=-1){ partScale[activePartIdx]+=0.02f; builderView.invalidate();} }});

        btnCropApply.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Bitmap cropped = cropView.getCroppedBitmap();
                if (cropped != null) {
                    poseParts[activePartIdx] = cropped; closeCropMode();
                    refreshLeftPanelUI(); builderView.invalidate();
                } else { Toast.makeText(CustomBuilderActivity.this, "Box theek se draw karo!", Toast.LENGTH_SHORT).show(); }
            }
        });

        btnCropCancel.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { closeCropMode(); } });

        btnNextPose.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if(!checkAllPartsLoaded()) { Toast.makeText(CustomBuilderActivity.this, " Pehle Pose " + currentPose + " ke saare parts import karo!", Toast.LENGTH_LONG).show(); return; }
                savePoseState(); 
                if(currentPose < 5) { 
                    currentPose++; 
                    tvTitle.setText("TEMPLATE SWAP: POSE " + currentPose + " / 5"); 
                    loadPoseState(); //  FIX: Naye pose me aate hi purane parts load karega
                } 
                else { Toast.makeText(CustomBuilderActivity.this, "All 5 Poses Done! Click Finish.", Toast.LENGTH_SHORT).show(); }
            }
        });

        btnSaveExit.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if(currentPose == 1 && !checkAllPartsLoaded()) { Toast.makeText(CustomBuilderActivity.this, "Kam se kam Pose 1 to pura karo!", Toast.LENGTH_SHORT).show(); return; }
                if(checkAllPartsLoaded()) { savePoseState(); }
                
                AlertDialog.Builder builder = new AlertDialog.Builder(CustomBuilderActivity.this);
                builder.setTitle("Name your Character");
                final EditText input = new EditText(CustomBuilderActivity.this); input.setText(customCharName); builder.setView(input);
                builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        customCharName = input.getText().toString().trim();
                        Bitmap finalSheet = buildFinalSpriteSheet(); 
                        if (finalSheet != null) {
                            String savedPath = CharacterStorage.saveBitmapInternal(CustomBuilderActivity.this, finalSheet, "Custom_Char_" + System.currentTimeMillis());
                            if (savedPath != null) {
                                CharacterStorage.addCustomCharacter(CustomBuilderActivity.this, customCharName, savedPath, 2,1); 
                                Toast.makeText(CustomBuilderActivity.this, customCharName + " Saved successfully! ", Toast.LENGTH_LONG).show();
                                finish();
                            }
                        }
                    }
                }); builder.show();
            }
        });
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == 500 && resultCode == RESULT_OK && data != null) {
            try {
                Bitmap bmp = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData());
                tempUncroppedBmp = bmp; openCropMode();
            } catch (Exception e) {}
        }
    }

    // ==========================================
    //  NEW FUNCTION: Puraane Parts Ko UI me Dikhana 
    // ==========================================
    private void loadPoseState() {
        for(int i=0; i<12; i++) {
            int dhIndex = baseIndices[i] + (currentPose - 1);
            if (savedCustomParts[dhIndex] != null) {
                poseParts[i] = savedCustomParts[dhIndex]; // Memory se nikaal kar active pose me daalo
                partX[i] = savedX[dhIndex];
                partY[i] = savedY[dhIndex];
                partScale[i] = savedScale[dhIndex];
            } else {
                poseParts[i] = null;
                partX[i] = 0f; partY[i] = 0f; partScale[i] = 1.0f;
            }
        }
        activePartIdx = -1;
        refreshLeftPanelUI();
        if (builderView != null) builderView.invalidate();
    }

    private void openCropMode() {
        isCroppingMode = true; tvTitle.setText(" CROP " + partNames[activePartIdx].toUpperCase());
        builderView.setVisibility(View.GONE); controlsContainer.setVisibility(View.GONE);
        cropView.setVisibility(View.VISIBLE); cropControlsContainer.setVisibility(View.VISIBLE);
        cropView.setImage(tempUncroppedBmp);
    }

    private void closeCropMode() {
        isCroppingMode = false; tvTitle.setText("TEMPLATE SWAP: POSE " + currentPose + " / 5");
        cropView.setVisibility(View.GONE); cropControlsContainer.setVisibility(View.GONE);
        builderView.setVisibility(View.VISIBLE); controlsContainer.setVisibility(View.VISIBLE);
        tempUncroppedBmp = null;
    }

    private void refreshLeftPanelUI() {
        for (int i = 0; i < 12; i++) {
            Button btn = findViewById(100 + i);
            if(btn != null) {
                if(poseParts[i] != null) { btn.setText(partNames[i] + "\n(ADDED)"); btn.setBackgroundColor(i == activePartIdx ? Color.parseColor("#1B5E20") : Color.parseColor("#4CAF50")); } 
                else { btn.setText(partNames[i] + "\n(EMPTY)"); btn.setBackgroundColor(i == activePartIdx ? Color.parseColor("#B71C1C") : Color.parseColor("#D32F2F")); }
                if(i == activePartIdx) btn.setText(btn.getText() + " ");
            }
        }
        if(checkAllPartsLoaded()) {
            btnNextPose.setBackgroundColor(Color.parseColor("#2196F3")); btnNextPose.setTextColor(Color.WHITE);
        } else {
            btnNextPose.setBackgroundColor(Color.parseColor("#424242")); btnNextPose.setTextColor(Color.GRAY);
        }
    }

    private boolean checkAllPartsLoaded() { 
        // Ab ye poseParts ke sath-sath memory check karega
        for(int i=0; i<12; i++) { 
            int dhIndex = baseIndices[i] + (currentPose - 1);
            if(poseParts[i] == null && savedCustomParts[dhIndex] == null) return false; 
        } 
        return true; 
    }

    private void savePoseState() {
        for(int c = 0; c < 12; c++) {
            if(poseParts[c] != null) {
                int dhIndex = baseIndices[c] + (currentPose - 1);
                savedCustomParts[dhIndex] = poseParts[c];
                savedX[dhIndex] = partX[c];
                savedY[dhIndex] = partY[c];
                savedScale[dhIndex] = partScale[c];
            }
        }
    }

    private Bitmap buildFinalSpriteSheet() {
        try {
            Bitmap sheet = Bitmap.createBitmap((int)sheetW, (int)sheetH, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(sheet);
            
            ArrayList<String> paintedBoxes = new ArrayList<>();

            for(int i=0; i<60; i++) {
                if(savedCustomParts[i] != null) {
                    float[] rect = CharacterSheetView.cropParts[i];
                    if(rect != null && rect.length >= 4) {
                        float valX = rect[0], valY = rect[1], valW = rect[2], valH = rect[3];
                        float x = valW <= 1.0f ? valX * sheetW : (valX <= 100f ? (valX/100f)*sheetW : valX);
                        float y = valH <= 1.0f ? valY * sheetH : (valY <= 100f ? (valY/100f)*sheetH : valY);
                        float w = valW <= 1.0f ? valW * sheetW : (valW <= 100f ? (valW/100f)*sheetW : valW);
                        float h = valH <= 1.0f ? valH * sheetH : (valH <= 100f ? (valH/100f)*sheetH : valH);
                        
                        String boxKey = (int)x + "_" + (int)y; 
                        paintedBoxes.add(boxKey); 

                        float drawX = x + (w - savedCustomParts[i].getWidth() * savedScale[i]) / 2f + savedX[i];
                        float drawY = y + (h - savedCustomParts[i].getHeight() * savedScale[i]) / 2f + savedY[i];
                        
                        c.save(); 
                        c.clipRect(x, y, x + w, y + h); 
                        c.translate(drawX, drawY); 
                        c.scale(savedScale[i], savedScale[i]);
                        c.drawBitmap(savedCustomParts[i], 0, 0, null); 
                        c.restore();
                    }
                }
            }

            for(int i=0; i<60; i++) {
                if(savedCustomParts[i] == null) {
                    float[] rect = CharacterSheetView.cropParts[i];
                    if(rect != null && rect.length >= 4) {
                        float valX = rect[0], valY = rect[1], valW = rect[2], valH = rect[3];
                        float x = valW <= 1.0f ? valX * sheetW : (valX <= 100f ? (valX/100f)*sheetW : valX);
                        float y = valH <= 1.0f ? valY * sheetH : (valY <= 100f ? (valY/100f)*sheetH : valY);
                        float w = valW <= 1.0f ? valW * sheetW : (valW <= 100f ? (valW/100f)*sheetW : valW);
                        float h = valH <= 1.0f ? valH * sheetH : (valH <= 100f ? (valH/100f)*sheetH : valH);
                        
                        String boxKey = (int)x + "_" + (int)y;

                        boolean isPainted = false;
                        for(String p : paintedBoxes) {
                            if(p.equals(boxKey)) { isPainted = true; break; }
                        }

                        if (!isPainted) {
                            if (originalParts[i] != null) {
                                c.drawBitmap(originalParts[i], x, y, null);
                                paintedBoxes.add(boxKey);
                            } else if (templateParts[i] != null) {
                                c.drawBitmap(templateParts[i], x, y, null);
                                paintedBoxes.add(boxKey);
                            }
                        }
                    }
                }
            }
            return sheet;
        } catch (Exception e) { Toast.makeText(this, "Save Error!", Toast.LENGTH_SHORT).show(); return null; }
    }

    private Button createCtrlBtn(String text) { Button b = new Button(this); b.setText(text); b.setTextSize(10f); b.setBackgroundColor(Color.parseColor("#424242")); b.setTextColor(Color.WHITE); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dpToPx(50), dpToPx(40)); lp.setMargins(5,5,5,5); b.setLayoutParams(lp); return b; }
    private TextView createHeader(String text) { TextView t = new TextView(this); t.setText(text); t.setTextColor(Color.parseColor("#9E9E9E")); t.setTextSize(10f); t.setGravity(Gravity.CENTER); t.setPadding(0,15,0,5); return t; }
    private int dpToPx(int dp) { return (int) (dp * getResources().getDisplayMetrics().density); }

    // ==========================================
    // CROP VIEW 
    // ==========================================
    private class CropView extends View {
        private Bitmap image; private RectF cropRect = new RectF();
        private float startX, startY, scale, dx, dy;
        public CropView(Context context) { super(context); }
        public void setImage(Bitmap bmp) { this.image = bmp; cropRect.setEmpty(); invalidate(); }

        @Override protected void onDraw(final Canvas canvas) {
            super.onDraw(canvas); canvas.drawColor(Color.parseColor("#121212"));
            if (image == null) return;
            float viewW = getWidth(); float viewH = getHeight(); float bmpW = image.getWidth(); float bmpH = image.getHeight();
            scale = Math.min(viewW / bmpW, viewH / bmpH); dx = (viewW - bmpW * scale) / 2f; dy = (viewH - bmpH * scale) / 2f;
            canvas.save(); canvas.translate(dx, dy); canvas.scale(scale, scale); canvas.drawBitmap(image, 0, 0, null); canvas.restore();

            if (!cropRect.isEmpty()) {
                Paint dim = new Paint(); dim.setColor(Color.parseColor("#99000000")); 
                canvas.drawRect(0, 0, viewW, cropRect.top, dim); canvas.drawRect(0, cropRect.bottom, viewW, viewH, dim); canvas.drawRect(0, cropRect.top, cropRect.left, cropRect.bottom, dim); canvas.drawRect(cropRect.right, cropRect.top, viewW, cropRect.bottom, dim); 
                Paint border = new Paint(); border.setStyle(Paint.Style.STROKE); border.setColor(Color.WHITE); border.setStrokeWidth(5f); canvas.drawRect(cropRect, border);
            } else { Paint textPaint = new Paint(); textPaint.setColor(Color.WHITE); textPaint.setTextSize(40f); textPaint.setTextAlign(Paint.Align.CENTER); canvas.drawText(" Drag box to select part!", viewW/2f, 100f, textPaint); }
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            float x = event.getX(); float y = event.getY();
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: startX = x; startY = y; cropRect.set(x, y, x, y); break;
                case MotionEvent.ACTION_MOVE: cropRect.left = Math.min(startX, x); cropRect.top = Math.min(startY, y); cropRect.right = Math.max(startX, x); cropRect.bottom = Math.max(startY, y); break;
                case MotionEvent.ACTION_UP: if(cropRect.width() < 20) cropRect.right = cropRect.left + 20; if(cropRect.height() < 20) cropRect.bottom = cropRect.top + 20; break;
            }
            invalidate(); return true;
        }

        public Bitmap getCroppedBitmap() {
            if (image == null || cropRect.isEmpty()) return null;
            float bx1 = (cropRect.left - dx) / scale; float by1 = (cropRect.top - dy) / scale; float bx2 = (cropRect.right - dx) / scale; float by2 = (cropRect.bottom - dy) / scale;
            bx1 = Math.max(0, Math.min(bx1, image.getWidth())); by1 = Math.max(0, Math.min(by1, image.getHeight())); bx2 = Math.max(0, Math.min(bx2, image.getWidth())); by2 = Math.max(0, Math.min(by2, image.getHeight()));
            int w = (int)(bx2 - bx1); int h = (int)(by2 - by1); if (w <= 0 || h <= 0) return null;
            return Bitmap.createBitmap(image, (int)bx1, (int)by1, w, h);
        }
    }

    // ==========================================
    // 3. SYNCHRONIZED PREVIEW ENGINE
    // ==========================================
    private class BuilderView extends View {
        private Paint ghostPt;

        class DrawAction implements Comparable<DrawAction> {
            int z; Runnable a; DrawAction(int z, Runnable a) { this.z = z; this.a = a; }
            public int compareTo(DrawAction o) { return Integer.compare(this.z, o.z); }
        }

        public BuilderView(Context ctx) { 
            super(ctx); 
            ghostPt = new Paint(); ghostPt.setFilterBitmap(true);
            ghostPt.setAlpha(120); 
        }

        private float[] getRelPiv(int partIdx, int p, float[] bone) {
            if (bone == null || bone.length < 2) return new float[]{0,0};
            int cIdx = baseIndices[partIdx] + p;
            float[] crop = CharacterSheetView.cropParts[cIdx];
            if (crop == null || crop.length < 4) return new float[]{0,0};
            
            float cX = crop[0] <= 1.0f ? crop[0]*sheetW : (crop[0] <= 100f ? crop[0]/100f*sheetW : crop[0]);
            float cY = crop[1] <= 1.0f ? crop[1]*sheetH : (crop[1] <= 100f ? crop[1]/100f*sheetH : crop[1]);
            
            float bX = bone[0] <= 1.0f ? bone[0]*sheetW : (bone[0] <= 100f ? bone[0]/100f*sheetW : bone[0]);
            float bY = bone[1] <= 1.0f ? bone[1]*sheetH : (bone[1] <= 100f ? bone[1]/100f*sheetH : bone[1]);
            
            return new float[]{ bX - cX, bY - cY };
        }

        private int getSharedCustomIndex(int dhIndex) {
            if (savedCustomParts[dhIndex] != null) return dhIndex;
            float[] myRect = CharacterSheetView.cropParts[dhIndex];
            if (myRect == null) return -1;
            for(int i=0; i<60; i++) {
                if (savedCustomParts[i] != null) {
                    float[] other = CharacterSheetView.cropParts[i];
                    if (other != null && Math.abs(myRect[0] - other[0]) < 0.001f && Math.abs(myRect[1] - other[1]) < 0.001f) {
                        return i; 
                    }
                }
            }
            return -1;
        }

        private void drawPart(Canvas c, int partIdx) {
            int dhIndex = baseIndices[partIdx] + (currentPose - 1);
            int customIdx = getSharedCustomIndex(dhIndex);
            
            Bitmap defPart = templateParts[dhIndex] != null ? templateParts[dhIndex] : originalParts[dhIndex]; 
            Bitmap activeCustom = poseParts[partIdx];

            if (defPart != null) c.drawBitmap(defPart, 0, 0, ghostPt);
            
            if (activeCustom != null && defPart != null) {
                c.save();
                c.clipRect(0, 0, defPart.getWidth(), defPart.getHeight());
                float dx = (defPart.getWidth() - activeCustom.getWidth() * partScale[partIdx]) / 2f + partX[partIdx];
                float dy = (defPart.getHeight() - activeCustom.getHeight() * partScale[partIdx]) / 2f + partY[partIdx];
                c.translate(dx, dy); c.scale(partScale[partIdx], partScale[partIdx]);
                c.drawBitmap(activeCustom, 0, 0, null);
                c.restore();
                
                if (partIdx == activePartIdx) {
                    Paint box = new Paint(); box.setStyle(Paint.Style.STROKE); 
                    box.setColor(Color.RED); box.setStrokeWidth(4f);
                    c.drawRect(0, 0, defPart.getWidth(), defPart.getHeight(), box);
                }
            } else if (customIdx != -1 && defPart != null) {
                c.save();
                c.clipRect(0, 0, defPart.getWidth(), defPart.getHeight());
                float dx = (defPart.getWidth() - savedCustomParts[customIdx].getWidth() * savedScale[customIdx]) / 2f + savedX[customIdx];
                float dy = (defPart.getHeight() - savedCustomParts[customIdx].getHeight() * savedScale[customIdx]) / 2f + savedY[customIdx];
                c.translate(dx, dy); c.scale(savedScale[customIdx], savedScale[customIdx]);
                c.drawBitmap(savedCustomParts[customIdx], 0, 0, null);
                c.restore();
            }
        }

        @Override protected void onDraw(final Canvas canvas) {
            super.onDraw(canvas); canvas.drawColor(Color.parseColor("#2A2A2A"));
            float cx = getWidth() / 2f; float cy = getHeight() / 2f;
            
            final int p = currentPose - 1; 
            final float[][] rb = CharacterSheetView.boneParts; 
            final int b = p * 22; 
            
            Bitmap torsoDef = templateParts[baseIndices[1] + p] != null ? templateParts[baseIndices[1] + p] : originalParts[baseIndices[1] + p];
            if(torsoDef == null || rb == null) {
                Paint textPaint = new Paint(); textPaint.setColor(Color.WHITE); textPaint.setTextSize(40f); textPaint.setTextAlign(Paint.Align.CENTER);
                canvas.drawText("Error: Sheets not loaded!", cx, cy, textPaint); return;
            }

            final float tW = torsoDef.getWidth(); final float tH = torsoDef.getHeight(); 
            final float s = (getHeight() * 0.45f) / tH; 
            final float tL = -tW/2f; final float tT = -tH/2f;
            
            canvas.save(); canvas.translate(cx, cy); canvas.scale(s, s);
            
            ArrayList<DrawAction> draws = new ArrayList<>();
            draws.add(new DrawAction(partZ[0], new Runnable() { public void run() { 
                float[] tN = getRelPiv(1, p, getRb(rb, b+0)); float[] hN = getRelPiv(0, p, getRb(rb, b+1)); 
                canvas.save(); canvas.translate(tL + tN[0], tT + tN[1]); canvas.translate(-hN[0], -hN[1]); drawPart(canvas, 0); canvas.restore(); 
            }}));
            draws.add(new DrawAction(partZ[1], new Runnable() { public void run() { canvas.save(); canvas.translate(tL, tT); drawPart(canvas, 1); canvas.restore(); }}));
            draws.add(new DrawAction(partZ[2], new Runnable() { public void run() { drawLimb(canvas, tL, tT, p, getRb(rb, b+6), 2, 3, -1, getRb(rb, b+7), getRb(rb, b+8), getRb(rb, b+9), null, null); }}));
            draws.add(new DrawAction(partZ[4], new Runnable() { public void run() { drawLimb(canvas, tL, tT, p, getRb(rb, b+2), 4, 5, -1, getRb(rb, b+3), getRb(rb, b+4), getRb(rb, b+5), null, null); }}));
            draws.add(new DrawAction(partZ[6], new Runnable() { public void run() { drawLimb(canvas, tL, tT, p, getRb(rb, b+16), 6, 7, 8, getRb(rb, b+17), getRb(rb, b+18), getRb(rb, b+19), getRb(rb, b+20), getRb(rb, b+21)); }}));
            draws.add(new DrawAction(partZ[9], new Runnable() { public void run() { drawLimb(canvas, tL, tT, p, getRb(rb, b+10), 9, 10, 11, getRb(rb, b+11), getRb(rb, b+12), getRb(rb, b+13), getRb(rb, b+14), getRb(rb, b+15)); }}));

            Collections.sort(draws); for(DrawAction d : draws) { d.a.run(); }
            canvas.restore();
        }
        
        private void drawLimb(Canvas c, float tL, float tT, int p, float[] tPivB, int id1, int id2, int id3, float[] p1PivB, float[] p1EndB, float[] p2PivB, float[] p2EndB, float[] p3PivB) {
            c.save(); 
            if(tPivB != null) { float[] tP = getRelPiv(1, p, tPivB); c.translate(tL + tP[0], tT + tP[1]); }
            if (p1PivB != null) { float[] p1Piv = getRelPiv(id1, p, p1PivB); c.translate(-p1Piv[0], -p1Piv[1]); }
            c.save(); drawPart(c, id1); c.restore();
            
            if (id2 != -1 && p1EndB != null && p2PivB != null) {
                float[] p1End = getRelPiv(id1, p, p1EndB); c.translate(p1End[0], p1End[1]);
                float[] p2Piv = getRelPiv(id2, p, p2PivB); c.translate(-p2Piv[0], -p2Piv[1]);
                c.save(); drawPart(c, id2); c.restore();
                
                if (id3 != -1 && p2EndB != null && p3PivB != null) {
                    float[] p2End = getRelPiv(id2, p, p2EndB); c.translate(p2End[0], p2End[1]);
                    float[] p3Piv = getRelPiv(id3, p, p3PivB); c.translate(-p3Piv[0], -p3Piv[1]);
                    c.save(); drawPart(c, id3); c.restore();
                }
            }
            c.restore();
        }
        private float[] getRb(float[][] rb, int i) { return (rb!=null && i>=0 && i<rb.length) ? rb[i] : null; }
    }
}
