package com.rakesh.toonrig;

import android.graphics.Bitmap;
import java.util.ArrayList;
import java.util.HashMap;

public class DataHolder {
    public static Bitmap[] parts = new Bitmap[60]; 
    public static float[][] relBones = new float[110][2]; 
    public static int currentPose = 1; 
    public static int selectedResId = -1; 
    public static String selectedCustomPath = null;
    public static CharacterRigProfile currentRigProfile = new CharacterRigProfile("default_rig");

    public static int bgColor = android.graphics.Color.parseColor("#222222");
    public static Bitmap bgBitmap = null;

    // GLOBAL EFFECTS SYSTEM
    public static boolean isShadowEnabled = false;
    public static int shadowDirection = 4;
    public static float shadowLength = 1.0f;
    public static boolean isOnionSkinEnabled = true;

    // NAYA: MESH AUR PERSPECTIVE STORAGE
    public static HashMap<String, float[]> partMeshes = new HashMap<>();
    public static HashMap<String, float[]> partPerspectives = new HashMap<>(); // Perspective ke 4 corners

    // --- MULTI-CHARACTER ENGINE SYSTEM ---
    public static ArrayList<SceneCharacter> sceneCharacters = new ArrayList<>();
    public static int activeCharIndex = 0; 
    
    public static boolean isAddingNewChar = false; 

    public static void addNewCharacterToScene(String name) {
        SceneCharacter sc = new SceneCharacter(name);
        sc.loadFromCurrentData();
        sc.zOrder = sceneCharacters.size(); 
        sceneCharacters.add(sc);
        activeCharIndex = sceneCharacters.size() - 1; 
    }

    public static SceneCharacter getActiveChar() {
        if (sceneCharacters.isEmpty()) return null;
        if (activeCharIndex < 0 || activeCharIndex >= sceneCharacters.size()) activeCharIndex = 0;
        return sceneCharacters.get(activeCharIndex);
    }
}
