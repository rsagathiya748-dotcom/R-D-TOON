package com.rakesh.toonrig;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.CountDownLatch;

public class AnimationExporter {

    public static void exportVideo(final Context context, final PreviewView previewView, final int width, final int height, final int bitRate, final String qName) {
        final ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("Rendering " + qName + " Video");
        progressDialog.setMessage("Please wait... 0%");
        progressDialog.setCancelable(false);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setMax(100);
        progressDialog.show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File tempFile = new File(context.getCacheDir(), "toonrig_hq_temp.mp4");

                    MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
                    format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar);
                    format.setInteger(MediaFormat.KEY_BIT_RATE, bitRate);
                    format.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
                    format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

                    MediaCodec encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
                    
                    try {
                        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                    } catch (Exception configError) {
                        throw new Exception("Aapka Phone Hardware " + qName + " size support nahi karta! Kripya isse kam quality chunein.");
                    }
                    
                    encoder.start();

                    MediaMuxer muxer = new MediaMuxer(tempFile.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                    int trackIndex = -1;
                    boolean muxerStarted = false;

                    int tempFrames = previewView.getLastKeyframeNumber();
                    if (tempFrames <= 0) tempFrames = 30; 
                    final int totalFrames = tempFrames;

                    long presentationTimeUs = 0;
                    long frameTimeUs = 1000000 / 30; 

                    final Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    int[] argb = new int[width * height];
                    byte[] yuv = new byte[width * height * 3 / 2];
                    MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();

                    for (int i = 0; i <= totalFrames; i++) {
                        final int currentFrame = i;
                        final CountDownLatch latch = new CountDownLatch(1);

                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    previewView.setFrameManual(currentFrame);
                                    Canvas canvas = new Canvas(bitmap);
                                    
                                    // --- RENDER HOTE WAQT BHI WAHI BACKGROUND COLOR AAYEGA ---
                                    canvas.drawColor(previewView.getChromaColor()); 
                                    
                                    int viewW = previewView.getWidth();
                                    int viewH = previewView.getHeight();
                                    
                                    if (viewW > 0 && viewH > 0) {
                                        float scaleX = (float) width / viewW;
                                        float scaleY = (float) height / viewH;
                                        canvas.scale(scaleX, scaleY);
                                        previewView.draw(canvas);
                                    }

                                    int percent = (currentFrame * 100) / totalFrames;
                                    progressDialog.setProgress(percent);
                                    progressDialog.setMessage("Rendering... " + percent + "%");
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                } finally {
                                    latch.countDown();
                                }
                            }
                        });

                        latch.await(); 

                        bitmap.getPixels(argb, 0, width, 0, 0, width, height);
                        encodeYUV420SP(yuv, argb, width, height);

                        int inputBufferIndex = encoder.dequeueInputBuffer(10000);
                        if (inputBufferIndex >= 0) {
                            ByteBuffer inputBuffer = encoder.getInputBuffer(inputBufferIndex);
                            inputBuffer.clear();
                            inputBuffer.put(yuv);
                            encoder.queueInputBuffer(inputBufferIndex, 0, yuv.length, presentationTimeUs, 0);
                            presentationTimeUs += frameTimeUs;
                        }

                        while (true) {
                            int outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, 10000);
                            if (outputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                                trackIndex = muxer.addTrack(encoder.getOutputFormat());
                                muxer.start();
                                muxerStarted = true;
                            } else if (outputBufferIndex >= 0) {
                                ByteBuffer outputBuffer = encoder.getOutputBuffer(outputBufferIndex);
                                if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) bufferInfo.size = 0;
                                if (bufferInfo.size != 0 && muxerStarted) {
                                    outputBuffer.position(bufferInfo.offset);
                                    outputBuffer.limit(bufferInfo.offset + bufferInfo.size);
                                    muxer.writeSampleData(trackIndex, outputBuffer, bufferInfo);
                                }
                                encoder.releaseOutputBuffer(outputBufferIndex, false);
                                if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
                            } else {
                                break;
                            }
                        }
                    }

                    int inputBufferIndex = encoder.dequeueInputBuffer(10000);
                    if (inputBufferIndex >= 0) {
                        encoder.queueInputBuffer(inputBufferIndex, 0, 0, presentationTimeUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    }
                    while (true) {
                        int outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, 10000);
                        if (outputBufferIndex >= 0) {
                            if (bufferInfo.size != 0 && muxerStarted) {
                                ByteBuffer outputBuffer = encoder.getOutputBuffer(outputBufferIndex);
                                outputBuffer.position(bufferInfo.offset);
                                outputBuffer.limit(bufferInfo.offset + bufferInfo.size);
                                muxer.writeSampleData(trackIndex, outputBuffer, bufferInfo);
                            }
                            encoder.releaseOutputBuffer(outputBufferIndex, false);
                            if ((bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
                        } else if (outputBufferIndex != MediaCodec.INFO_TRY_AGAIN_LATER) {
                            break;
                        }
                    }

                    encoder.stop();
                    encoder.release();
                    muxer.stop();
                    muxer.release();
                    bitmap.recycle();

                    saveToGallery(context, tempFile, qName);

                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override public void run() {
                            progressDialog.dismiss();
                            Toast.makeText(context, "✅ " + qName + " Render Complete!", Toast.LENGTH_LONG).show();
                        }
                    });

                } catch (final Throwable e) {
                    e.printStackTrace();
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override public void run() {
                            progressDialog.dismiss();
                            String errorMsg = e.getMessage();
                            if (e instanceof OutOfMemoryError) {
                                errorMsg = "Phone ki RAM full ho gayi hai! Kripya 2K ya HD chunein.";
                            } else if (errorMsg == null) {
                                errorMsg = e.toString();
                            }
                            Toast.makeText(context, "Render Error: " + errorMsg, Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }

    private static void encodeYUV420SP(byte[] yuv420sp, int[] argb, int width, int height) {
        int yIndex = 0;
        int uvIndex = width * height;
        int index = 0;
        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                int c = argb[index];
                int R = (c & 0xff0000) >> 16;
                int G = (c & 0x00ff00) >> 8;
                int B = (c & 0x0000ff);
                int Y = ((66 * R + 129 * G + 25 * B + 128) >> 8) + 16;
                int U = ((-38 * R - 74 * G + 112 * B + 128) >> 8) + 128;
                int V = ((112 * R - 94 * G - 18 * B + 128) >> 8) + 128;
                yuv420sp[yIndex++] = (byte) ((Y < 0) ? 0 : ((Y > 255) ? 255 : Y));
                if (j % 2 == 0 && i % 2 == 0 && uvIndex < yuv420sp.length - 1) {
                    yuv420sp[uvIndex++] = (byte) ((U < 0) ? 0 : ((U > 255) ? 255 : U));
                    yuv420sp[uvIndex++] = (byte) ((V < 0) ? 0 : ((V > 255) ? 255 : V));
                }
                index++;
            }
        }
    }

    private static void saveToGallery(Context context, File tempFile, String qName) throws Exception {
        String fileName = "ToonRig_" + qName + "_" + System.currentTimeMillis() + ".mp4";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = context.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ToonRig");
            Uri videoUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (videoUri != null) {
                OutputStream out = resolver.openOutputStream(videoUri);
                FileInputStream in = new FileInputStream(tempFile);
                byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = in.read(buffer)) > 0) out.write(buffer, 0, bytesRead);
                in.close(); out.close();
            }
        } else {
            File moviesDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "ToonRig");
            if (!moviesDir.exists()) moviesDir.mkdirs();
            File finalFile = new File(moviesDir, fileName);
            FileOutputStream out = new FileOutputStream(finalFile);
            FileInputStream in = new FileInputStream(tempFile);
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) > 0) out.write(buffer, 0, bytesRead);
            in.close(); out.close();
            android.media.MediaScannerConnection.scanFile(context, new String[]{finalFile.getAbsolutePath()}, new String[]{"video/mp4"}, null);
        }
        tempFile.delete();
    }
}
