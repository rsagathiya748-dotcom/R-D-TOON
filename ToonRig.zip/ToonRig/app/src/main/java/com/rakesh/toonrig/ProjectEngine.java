package com.rakesh.toonrig;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.HashMap;

public class ProjectEngine {

    // 1. DATA SAVE KARNE KA SYSTEM
    public static void saveAutoSave(Context ctx) {
        if (DataHolder.sceneCharacters == null || DataHolder.sceneCharacters.isEmpty()) return;
        
        SharedPreferences prefs = ctx.getSharedPreferences("ToonRigApp", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        
        editor.putBoolean("has_draft", true);
        editor.putInt("char_count", DataHolder.sceneCharacters.size());
        editor.putInt("bg_color", DataHolder.bgColor);
        
        if (AnimationSelectionActivity.charAnimChains != null) {
            for (int i = 0; i < DataHolder.sceneCharacters.size(); i++) {
                if (AnimationSelectionActivity.charAnimChains.containsKey(i)) {
                    JSONArray arr = new JSONArray(AnimationSelectionActivity.charAnimChains.get(i));
                    editor.putString("chain_" + i, arr.toString());
                }
            }
        }
        editor.apply();
    }

    // 2. DATA WAPAS LOAD KARNE KA SYSTEM
    public static void loadAutoSave(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences("ToonRigApp", Context.MODE_PRIVATE);
        
        if (DataHolder.sceneCharacters == null) DataHolder.sceneCharacters = new ArrayList<>();
        DataHolder.sceneCharacters.clear();
        
        DataHolder.bgColor = prefs.getInt("bg_color", android.graphics.Color.parseColor("#222222"));
        
        if (AnimationSelectionActivity.charAnimChains == null) AnimationSelectionActivity.charAnimChains = new HashMap<>();
        AnimationSelectionActivity.charAnimChains.clear();

        int count = prefs.getInt("char_count", 1);
        for (int i = 0; i < count; i++) {
            DataHolder.addNewCharacterToScene("Player " + (i + 1));
            
            String chainStr = prefs.getString("chain_" + i, "");
            if (!chainStr.isEmpty()) {
                try {
                    JSONArray arr = new JSONArray(chainStr);
                    ArrayList<String> list = new ArrayList<>();
                    for (int j = 0; j < arr.length(); j++) list.add(arr.getString(j));
                    AnimationSelectionActivity.charAnimChains.put(i, list);
                } catch (Exception e) {}
            }
        }
    }
    
    // 3. PROJECT CLEAR KARNA (Naya project banate waqt)
    public static void clearDraft(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences("ToonRigApp", Context.MODE_PRIVATE);
        prefs.edit().putBoolean("has_draft", false).apply();
    }
}
