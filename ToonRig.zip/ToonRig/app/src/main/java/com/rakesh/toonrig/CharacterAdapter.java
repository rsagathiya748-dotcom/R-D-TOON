package com.rakesh.toonrig;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class CharacterAdapter extends BaseAdapter {

    private CharacterSelectionActivity activity; 
    private ArrayList<CharacterModel> list;
    private int selectedPosition = -1;

    public CharacterAdapter(CharacterSelectionActivity activity, ArrayList<CharacterModel> list) {
        this.activity = activity;
        this.list = list;
    }

    public CharacterModel getSelectedCharacter() {
        if (selectedPosition >= 0 && selectedPosition < list.size()) return list.get(selectedPosition);
        return null;
    }

    @Override public int getCount() { return list.size(); }
    @Override public Object getItem(int position) { return list.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(activity).inflate(R.layout.item_character, parent, false);
            holder = new ViewHolder();
            holder.borderContainer = (FrameLayout) convertView.findViewById(R.id.borderContainer);
            holder.charThumbnail = (ImageView) convertView.findViewById(R.id.charThumbnail);
            holder.charName = (TextView) convertView.findViewById(R.id.charName);
            holder.tagText = (TextView) convertView.findViewById(R.id.tagText);
            convertView.setTag(holder);
        } else { holder = (ViewHolder) convertView.getTag(); }

        final CharacterModel model = list.get(position);
        holder.charName.setText(model.getName());

        if (model.getType() == CharacterModel.TYPE_PRO) {
            holder.tagText.setText("PRO"); holder.tagText.setBackgroundColor(Color.parseColor("#800080"));
        } else if (model.getType() == CharacterModel.TYPE_CUSTOM) {
            holder.tagText.setText("CUSTOM"); holder.tagText.setBackgroundColor(Color.parseColor("#008080"));
        } else {
            holder.tagText.setText("FREE"); holder.tagText.setBackgroundColor(Color.parseColor("#4CAF50"));
        }

        if (selectedPosition == position) {
            holder.borderContainer.setBackgroundColor(Color.parseColor("#FFD700")); holder.borderContainer.setPadding(6, 6, 6, 6);
        } else {
            holder.borderContainer.setBackgroundColor(Color.TRANSPARENT); holder.borderContainer.setPadding(2, 2, 2, 2);
        }

        if (model.getThumbnail() == null) {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 2; 
            Bitmap originalSheet = null;
            
            // ==========================================
            // 🔥 GITHUB FIX: UNIVERSAL PATH CHECKER 🔥
            // Ab type chahe jo ho, agar FilePath hai toh wahin se load hoga!
            // ==========================================
            String path = model.getFilePath();
            if (path != null && !path.isEmpty()) { 
                originalSheet = BitmapFactory.decodeFile(path, opts); 
            } else if (model.getResId() != 0 && model.getResId() != -1) { 
                originalSheet = BitmapFactory.decodeResource(activity.getResources(), model.getResId(), opts); 
            }

            if (originalSheet != null) {
                Bitmap thumb = assemblePerfectThumbnail(originalSheet);
                model.setThumbnail(thumb);
                originalSheet.recycle(); 
            }
        }
        
        // Agar fir bhi thumbnail null hai, toh kam se kam transparent set karega, crash nahi hoga
        if (model.getThumbnail() != null) {
            holder.charThumbnail.setImageBitmap(model.getThumbnail());
        } else {
            holder.charThumbnail.setImageBitmap(null); 
        }

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectedPosition = position; notifyDataSetChanged(); }
        });

        convertView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                if (model.isCustom()) {
                    activity.showCustomOptionsDialog(model);
                } else {
                    Toast.makeText(activity, "Aap sirf Custom characters ko edit ya delete kar sakte hain!", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        
        return convertView;
    }

    private Bitmap assemblePerfectThumbnail(Bitmap sheet) {
        Bitmap canvasBmp = Bitmap.createBitmap(800, 1200, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(canvasBmp);
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        float[][] cp = CharacterSheetView.cropParts; float[][] bp = CharacterSheetView.boneParts;
        
        Bitmap t1 = getSafeCrop(sheet, cp[5]); Bitmap h1 = getSafeCrop(sheet, cp[0]);
        Bitmap la1 = getSafeCrop(sheet, cp[15]), la2 = getSafeCrop(sheet, cp[25]);
        Bitmap ra1 = getSafeCrop(sheet, cp[10]), ra2 = getSafeCrop(sheet, cp[20]);
        Bitmap ll1 = getSafeCrop(sheet, cp[35]), ll2 = getSafeCrop(sheet, cp[45]), lf = getSafeCrop(sheet, cp[55]);
        Bitmap rl1 = getSafeCrop(sheet, cp[30]), rl2 = getSafeCrop(sheet, cp[40]), rf = getSafeCrop(sheet, cp[50]);
        
        if (t1 == null) return canvasBmp;
        float tL = 400 - (t1.getWidth() / 2f), tT = 600 - (t1.getHeight() / 2f);

        if (la1 != null) {
            canvas.save(); canvas.translate(tL + t1.getWidth() * getRelX(cp[5], bp[6]), tT + t1.getHeight() * getRelY(cp[5], bp[6]));
            if (la2 != null) {
                canvas.save();
                canvas.translate(la1.getWidth() * (getRelX(cp[15], bp[8]) - getRelX(cp[15], bp[7])), la1.getHeight() * (getRelY(cp[15], bp[8]) - getRelY(cp[15], bp[7])));
                canvas.translate(-(la2.getWidth() * getRelX(cp[25], bp[9])), -(la2.getHeight() * getRelY(cp[25], bp[9])));
                canvas.drawBitmap(la2, 0, 0, paint); canvas.restore();
            }
            canvas.translate(-(la1.getWidth() * getRelX(cp[15], bp[7])), -(la1.getHeight() * getRelY(cp[15], bp[7])));
            canvas.drawBitmap(la1, 0, 0, paint); canvas.restore();
        }

        if (ll1 != null) {
            canvas.save(); canvas.translate(tL + t1.getWidth() * getRelX(cp[5], bp[16]), tT + t1.getHeight() * getRelY(cp[5], bp[16]));
            if (ll2 != null) {
                canvas.save();
                canvas.translate(ll1.getWidth() * (getRelX(cp[35], bp[18]) - getRelX(cp[35], bp[17])), ll1.getHeight() * (getRelY(cp[35], bp[18]) - getRelY(cp[35], bp[17])));
                if (lf != null) {
                    canvas.save();
                    canvas.translate(ll2.getWidth() * (getRelX(cp[45], bp[20]) - getRelX(cp[45], bp[19])), ll2.getHeight() * (getRelY(cp[45], bp[20]) - getRelY(cp[45], bp[19])));
                    canvas.translate(-(lf.getWidth() * getRelX(cp[55], bp[21])), -(lf.getHeight() * getRelY(cp[55], bp[21])));
                    canvas.drawBitmap(lf, 0, 0, paint); canvas.restore();
                }
                canvas.translate(-(ll2.getWidth() * getRelX(cp[45], bp[19])), -(ll2.getHeight() * getRelY(cp[45], bp[19])));
                canvas.drawBitmap(ll2, 0, 0, paint); canvas.restore();
            }
            canvas.translate(-(ll1.getWidth() * getRelX(cp[35], bp[17])), -(ll1.getHeight() * getRelY(cp[35], bp[17])));
            canvas.drawBitmap(ll1, 0, 0, paint); canvas.restore();
        }

        if (rl1 != null) {
            canvas.save(); canvas.translate(tL + t1.getWidth() * getRelX(cp[5], bp[10]), tT + t1.getHeight() * getRelY(cp[5], bp[10]));
            if (rl2 != null) {
                canvas.save();
                canvas.translate(rl1.getWidth() * (getRelX(cp[30], bp[12]) - getRelX(cp[30], bp[11])), rl1.getHeight() * (getRelY(cp[30], bp[12]) - getRelY(cp[30], bp[11])));
                if (rf != null) {
                    canvas.save();
                    canvas.translate(rl2.getWidth() * (getRelX(cp[40], bp[14]) - getRelX(cp[40], bp[13])), rl2.getHeight() * (getRelY(cp[40], bp[14]) - getRelY(cp[40], bp[13])));
                    canvas.translate(-(rf.getWidth() * getRelX(cp[50], bp[15])), -(rf.getHeight() * getRelY(cp[50], bp[15])));
                    canvas.drawBitmap(rf, 0, 0, paint); canvas.restore();
                }
                canvas.translate(-(rl2.getWidth() * getRelX(cp[40], bp[13])), -(rl2.getHeight() * getRelY(cp[40], bp[13])));
                canvas.drawBitmap(rl2, 0, 0, paint); canvas.restore();
            }
            canvas.translate(-(rl1.getWidth() * getRelX(cp[30], bp[11])), -(rl1.getHeight() * getRelY(cp[30], bp[11])));
            canvas.drawBitmap(rl1, 0, 0, paint); canvas.restore();
        }

        canvas.drawBitmap(t1, tL, tT, paint);

        if (ra1 != null) {
            canvas.save(); canvas.translate(tL + t1.getWidth() * getRelX(cp[5], bp[2]), tT + t1.getHeight() * getRelY(cp[5], bp[2]));
            if (ra2 != null) {
                canvas.save();
                canvas.translate(ra1.getWidth() * (getRelX(cp[10], bp[4]) - getRelX(cp[10], bp[3])), ra1.getHeight() * (getRelY(cp[10], bp[4]) - getRelY(cp[10], bp[3])));
                canvas.translate(-(ra2.getWidth() * getRelX(cp[20], bp[5])), -(ra2.getHeight() * getRelY(cp[20], bp[5])));
                canvas.drawBitmap(ra2, 0, 0, paint); canvas.restore();
            }
            canvas.translate(-(ra1.getWidth() * getRelX(cp[10], bp[3])), -(ra1.getHeight() * getRelY(cp[10], bp[3])));
            canvas.drawBitmap(ra1, 0, 0, paint); canvas.restore();
        }

        if (h1 != null) {
            canvas.save(); canvas.translate(tL + t1.getWidth() * getRelX(cp[5], bp[0]), tT + t1.getHeight() * getRelY(cp[5], bp[0]));
            canvas.translate(-(h1.getWidth() * getRelX(cp[0], bp[1])), -(h1.getHeight() * getRelY(cp[0], bp[1])));
            canvas.drawBitmap(h1, 0, 0, paint); canvas.restore();
        }

        Bitmap finalThumb = Bitmap.createScaledBitmap(canvasBmp, 200, 300, true);
        canvasBmp.recycle();
        return finalThumb;
    }

    private float getRelX(float[] crop, float[] bone) { return ((bone[0] + (bone[2] / 2f)) - crop[0]) / crop[2]; }
    private float getRelY(float[] crop, float[] bone) { return ((bone[1] + (bone[3] / 2f)) - crop[1]) / crop[3]; }

    private Bitmap getSafeCrop(Bitmap sheet, float[] crop) {
        int w = sheet.getWidth(), h = sheet.getHeight();
        int x = (int)(crop[0]*w), y = (int)(crop[1]*h), cw = (int)(crop[2]*w), ch = (int)(crop[3]*h);
        if(x<0) x=0; if(y<0) y=0;
        if(x+cw>w) cw = w-x; if(y+ch>h) ch = h-y;
        if(cw<=0 || ch<=0) return null;
        return Bitmap.createBitmap(sheet, x, y, cw, ch);
    }
    static class ViewHolder { FrameLayout borderContainer; ImageView charThumbnail; TextView charName, tagText; }
}
