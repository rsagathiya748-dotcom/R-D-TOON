package com.rakesh.toonrig;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

public class HomeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // MODERN DARK STUDIO THEME BACKGROUND
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#15151E")); 
        root.setGravity(Gravity.CENTER);
        root.setPadding(40, 30, 40, 30);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("TOONRIG");
        tvTitle.setTextColor(Color.parseColor("#00E5FF")); 
        tvTitle.setTextSize(45);
        tvTitle.setGravity(Gravity.CENTER);
        tvTitle.setShadowLayer(10, 0, 0, Color.parseColor("#0088AA"));
        root.addView(tvTitle);

        TextView tvSub = new TextView(this);
        tvSub.setText("Professional 2D Animation Studio");
        tvSub.setTextColor(Color.LTGRAY);
        tvSub.setTextSize(14);
        tvSub.setGravity(Gravity.CENTER);
        tvSub.setPadding(0, 0, 0, 60);
        root.addView(tvSub);

        Button btnStart = new Button(this);
        btnStart.setText("🚀 ENTER WORKSPACE");
        btnStart.setTextColor(Color.WHITE);
        btnStart.setBackgroundColor(Color.parseColor("#FF0055")); 
        btnStart.setTextSize(20);
        btnStart.setPadding(0, 40, 0, 40);
        LinearLayout.LayoutParams lpStart = new LinearLayout.LayoutParams(600, LinearLayout.LayoutParams.WRAP_CONTENT);
        btnStart.setLayoutParams(lpStart);
        
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, CategoryActivity.class));
            }
        });
        root.addView(btnStart);

        View space = new View(this);
        space.setLayoutParams(new LinearLayout.LayoutParams(1, 80));
        root.addView(space);

        LinearLayout bottomRow = new LinearLayout(this);
        bottomRow.setOrientation(LinearLayout.HORIZONTAL);
        bottomRow.setGravity(Gravity.CENTER);

        bottomRow.addView(createBottomBtn("👤 Profile"));
        bottomRow.addView(createBottomBtn("⚙️ Settings"));
        bottomRow.addView(createBottomBtn("❓ Help"));

        root.addView(bottomRow);
        setContentView(root);
        
        // 🔥 AAPKA ORIGINAL PERMISSION LOGIC 🔥
        checkPermissionsAndDownload();
        checkForDraftProject();
    }

    private Button createBottomBtn(final String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.parseColor("#B0BEC5"));
        b.setBackgroundColor(Color.TRANSPARENT); 
        b.setTextSize(14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(20, 0, 20, 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Toast.makeText(HomeActivity.this, text + " Section Coming Soon!", Toast.LENGTH_SHORT).show();
            }
        });
        return b;
    }

    private void checkForDraftProject() {
        SharedPreferences prefs = getSharedPreferences("ToonRigApp", MODE_PRIVATE);
        if (prefs.getBoolean("has_draft", false)) {
            new AlertDialog.Builder(this)
                .setTitle("Project Recovered!")
                .setMessage("Aapka pichla project background me save tha. Kya aap wahi se shuru karna chahte hain?")
                .setCancelable(false)
                .setPositiveButton("YES (Resume)", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        ProjectEngine.loadAutoSave(HomeActivity.this);
                        startActivity(new Intent(HomeActivity.this, HubActivity.class));
                    }
                })
                .setNegativeButton("NO (Delete)", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        ProjectEngine.clearDraft(HomeActivity.this);
                    }
                }).show();
        }
    }

    private void checkPermissionsAndDownload() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
                return;
            }
        }
        startDownloading();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // 🔥 AAPKA ORIGINAL STRICT PERMISSION CHECK 🔥
        if(requestCode == 100 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startDownloading();
        } else {
            Toast.makeText(this, "Storage Permission Required for Updates!", Toast.LENGTH_LONG).show();
        }
    }

    private void startDownloading() {
        checkForNewCharactersOnline();
        checkForNewAnimationsOnline();
    }

    private void checkForNewCharactersOnline() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String jsonUrl = "https://raw.githubusercontent.com/rsagathiya748-dotcom/toonrig-data/main/characters.json?v=" + System.currentTimeMillis();
                    URL url = new URL(jsonUrl);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);

                    InputStream in = new BufferedInputStream(conn.getInputStream());
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line);
                    reader.close();

                    JSONArray jsonArray = new JSONArray(sb.toString());
                    ArrayList<CharacterModel> existingChars = CharacterStorage.getCustomCharacters(HomeActivity.this);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        final String charName = obj.getString("name");
                        String imgUrl = obj.getString("url");
                        
                        // 1. TYPE READ KAREGA
                        String typeStr = obj.optString("type", "free"); 
                        int charType = typeStr.equalsIgnoreCase("pro") ? 1 : (typeStr.equalsIgnoreCase("custom") ? 2 : 0);
                        
                        // 2. VERSION READ KAREGA
                        int onlineVersion = obj.optInt("version", 1); 

                        boolean exists = false;
                        boolean needsUpdate = false;
                        
                        for (CharacterModel c : existingChars) { 
                            if (c.getName().equals(charName)) { 
                                exists = true;
                                if (onlineVersion > c.getVersion()) {
                                    needsUpdate = true; // Agar version bada hai toh naya download
                                    CharacterStorage.removeCustomCharacter(HomeActivity.this, c.getFilePath());
                                }
                                break; 
                            } 
                        }

                        // Agar pehli baar aa raha hai (!exists) YA version update hua hai (needsUpdate)
                        if (!exists || needsUpdate) {
                            
                            // 🔥 AAPKA ORIGINAL FAST DOWNLOAD METHOD 🔥
                            URL iUrl = new URL(imgUrl);
                            Bitmap bitmap = BitmapFactory.decodeStream(iUrl.openConnection().getInputStream());
                            
                            if (bitmap != null) {
                                String savedPath = CharacterStorage.saveBitmapInternal(HomeActivity.this, bitmap, "Online_" + charName.replace(" ", "") + "_v" + onlineVersion);
                                if (savedPath != null) {
                                    
                                    // 5 parameter wala method: Version ke sath save
                                    CharacterStorage.addCustomCharacter(HomeActivity.this, charName, savedPath, charType, onlineVersion);
                                    
                                    // 🔥 LIVE UPDATE: GRID MEIN TURANT DIKHANE KE LIYE 🔥
                                    if (CharacterSelectionActivity.liveUpdateListener != null) {
                                        runOnUiThread(CharacterSelectionActivity.liveUpdateListener);
                                    }

                                    // AAPKA ORIGINAL TOAST MESSAGE
                                    runOnUiThread(new Runnable() {
                                        @Override public void run() { 
                                            Toast.makeText(HomeActivity.this, "New Character Downloaded: " + charName, Toast.LENGTH_LONG).show(); 
                                        }
                                    });
                                }
                            }
                        }
                    }
                } catch (Exception e) { 
                    e.printStackTrace(); 
                }
            }
        }).start();
    }

    private void checkForNewAnimationsOnline() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String jsonUrl = "https://raw.githubusercontent.com/rsagathiya748-dotcom/toonrig-data/main/animations.json";
                    URL url = new URL(jsonUrl);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);

                    InputStream in = new BufferedInputStream(conn.getInputStream());
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line);
                    reader.close();

                    JSONObject onlineAnimations = new JSONObject(sb.toString());
                    JSONObject localAnimations = AnimationStorage.readRootObject();
                    boolean isNewAdded = false;

                    Iterator<String> keys = onlineAnimations.keys();
                    while(keys.hasNext()) {
                        final String animName = keys.next();

                        if(!localAnimations.has(animName)) {
                            localAnimations.put(animName, onlineAnimations.getJSONObject(animName));
                            isNewAdded = true;

                            runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    Toast.makeText(HomeActivity.this, "New Animation Added: " + animName, Toast.LENGTH_LONG).show();
                                }
                            });
                        }
                    }

                    if(isNewAdded) {
                        AnimationStorage.writeRootObject(localAnimations);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
