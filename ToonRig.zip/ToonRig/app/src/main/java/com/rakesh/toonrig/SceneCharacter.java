package com.rakesh.toonrig;

import android.graphics.Bitmap;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class SceneCharacter {
    public String charName;
    
    public Bitmap[] parts = new Bitmap[60];
    public float[][] relBones = new float[110][2];
    public CharacterRigProfile rigProfile;
    
    public int currentPose = 1;
    public HashMap<Integer, HashMap<Integer, PreviewView.KeyFrame>> animationTimelines = new HashMap<>();
    
    public float globalX = 0f;
    public float globalY = 0f;
    public float globalScale = 1.0f;
    public int zOrder = 0;
    public boolean flipX = false;
    public boolean flipY = false;

    // PRO ANIMATION TOOLS VARIABLES
    public float skewX = 0f;
    public float skewY = 0f;
    public int alpha = 255; 
    public int easingType = 0; // 0=Linear, 1=EaseIn, 2=EaseOut, 3=EaseInOut

    public float headRot=0f, hl1Rot=0f, hl2Rot=0f, hr1Rot=0f, hr2Rot=0f;
    public float ll1Rot=0f, ll2Rot=0f, f1Rot=0f, lr1Rot=0f, lr2Rot=0f, f2Rot=0f;

    public SceneCharacter(String name) {
        this.charName = name;
        for (int i = 1; i <= 5; i++) {
            animationTimelines.put(i, new HashMap<Integer, PreviewView.KeyFrame>());
        }
    }

    public void loadFromCurrentData() {
        for (int i = 0; i < 60; i++) { this.parts[i] = DataHolder.parts[i]; }
        for (int i = 0; i < 110; i++) {
            this.relBones[i][0] = DataHolder.relBones[i][0];
            this.relBones[i][1] = DataHolder.relBones[i][1];
        }
        this.currentPose = DataHolder.currentPose;
        this.rigProfile = DataHolder.currentRigProfile; 
    }

    // 🔥 MASTER FIX: Chain Stitching Logic 🔥
    // ab is function ko boolean isChainMode parameter ke sath modify kiya gaya hai.
    // Taki jab user director mode me ho, to timeline clear na ho, balki aage judti chali jaye.
    public void loadAnimation(String jsonString, boolean isChainMode) {
        try {
            HashMap<Integer, PreviewView.KeyFrame> timeline = this.animationTimelines.get(this.currentPose);
            if (timeline == null) {
                timeline = new HashMap<>();
                this.animationTimelines.put(this.currentPose, timeline);
            }

            // Sabse aakhiri frame number nikalenge (Taki agla animation uske baad se shuru ho)
            int lastFrameOffset = 0;
            if (isChainMode && !timeline.isEmpty()) {
                for (Integer fNum : timeline.keySet()) {
                    if (fNum > lastFrameOffset) lastFrameOffset = fNum;
                }
                // Naya animation pichle wale se 1 frame chhod kar shuru ho
                lastFrameOffset += 1; 
            } else {
                // Agar normal mode hai (Preview screen), to timeline clear kardo
                timeline.clear();
            }

            Object jsonElement = new JSONTokener(jsonString).nextValue();
            if (jsonElement instanceof JSONObject) {
                JSONObject obj = (JSONObject) jsonElement;
                if (obj.has("frames")) {
                    Object framesData = obj.get("frames");
                    if (framesData instanceof JSONArray) { parseJSONArray((JSONArray) framesData, timeline, lastFrameOffset); } 
                    else if (framesData instanceof JSONObject) { parseJSONObject((JSONObject) framesData, timeline, lastFrameOffset); }
                } else { parseJSONObject(obj, timeline, lastFrameOffset); }
            } else if (jsonElement instanceof JSONArray) { parseJSONArray((JSONArray) jsonElement, timeline, lastFrameOffset); }
            
        } catch (Exception e) { e.printStackTrace(); }
    }

    // Purane function ko crash-proof rakhne ke liye default overloading
    public void loadAnimation(String jsonString) {
        loadAnimation(jsonString, false);
    }

    private void parseJSONObject(JSONObject framesObj, HashMap<Integer, PreviewView.KeyFrame> timeline, int offset) throws Exception {
        Iterator<String> keys = framesObj.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            try {
                // Offset add karke mega-timeline me joda
                int frameNum = Integer.parseInt(key) + offset; 
                JSONObject frameData = framesObj.getJSONObject(key);
                PreviewView.KeyFrame kf = createKeyFrame(frameNum, frameData);
                if (kf != null) { timeline.put(frameNum, kf); }
            } catch (NumberFormatException e) { }
        }
    }

    private void parseJSONArray(JSONArray framesArray, HashMap<Integer, PreviewView.KeyFrame> timeline, int offset) throws Exception {
        for (int i = 0; i < framesArray.length(); i++) {
            JSONObject frameData = framesArray.optJSONObject(i);
            if (frameData != null) {
                // Offset add karke mega-timeline me joda
                int frameNum = frameData.optInt("frame", i) + offset; 
                PreviewView.KeyFrame kf = createKeyFrame(frameNum, frameData);
                if (kf != null) { timeline.put(frameNum, kf); }
            }
        }
    }

    private PreviewView.KeyFrame createKeyFrame(int frameNum, JSONObject frameData) {
        float h = (float) frameData.optDouble("headRot", 0); float hl1 = (float) frameData.optDouble("hl1Rot", 0);
        float hl2 = (float) frameData.optDouble("hl2Rot", 0); float hr1 = (float) frameData.optDouble("hr1Rot", 0);
        float hr2 = (float) frameData.optDouble("hr2Rot", 0); float ll1 = (float) frameData.optDouble("ll1Rot", 0);
        float ll2 = (float) frameData.optDouble("ll2Rot", 0); float lr1 = (float) frameData.optDouble("lr1Rot", 0);
        float lr2 = (float) frameData.optDouble("lr2Rot", 0); float f1 = (float) frameData.optDouble("f1Rot", 0);
        float f2 = (float) frameData.optDouble("f2Rot", 0);

        try {
            java.lang.reflect.Constructor<?>[] cons = PreviewView.KeyFrame.class.getDeclaredConstructors();
            if (cons.length > 0) {
                cons[0].setAccessible(true);
                Class<?>[] paramTypes = cons[0].getParameterTypes();
                Object[] params = new Object[paramTypes.length];
                float[] myFloats = {h, hl1, hl2, hr1, hr2, ll1, ll2, lr1, lr2, f1, f2};
                int floatIndex = 0;
                
                for (int i = 0; i < paramTypes.length; i++) {
                    if (paramTypes[i] == int.class || paramTypes[i] == Integer.class) { params[i] = frameNum; } 
                    else if (paramTypes[i] == float.class || paramTypes[i] == Float.class) {
                        if (floatIndex < myFloats.length) { params[i] = myFloats[floatIndex]; floatIndex++; } 
                        else { params[i] = 0f; }
                    } else { params[i] = null; }
                }
                
                // Naya keyframe object ban gaya
                PreviewView.KeyFrame newKf = (PreviewView.KeyFrame) cons[0].newInstance(params);
                
                // Advanced values recover karna
                if(frameData.has("ease")) newKf.ease = frameData.optInt("ease", 0);
                if(frameData.has("alp")) newKf.alp = frameData.optInt("alp", 255);
                if(frameData.has("sX")) newKf.sX = (float) frameData.optDouble("sX", 0);
                if(frameData.has("sY")) newKf.sY = (float) frameData.optDouble("sY", 0);
                
                return newKf;
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null; 
    }
}
