package com.rakesh.toonrig;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class AdjustmentAdapter extends BaseAdapter {
    private Context context;
    private List<BoneSlot> slots;
    private int selectedPosition = -1;

    public AdjustmentAdapter(Context context, List<BoneSlot> slots) {
        this.context = context;
        this.slots = slots;
    }

    public void setSelectedIndex(int position) {
        this.selectedPosition = position;
        notifyDataSetChanged();
    }
    
    public BoneSlot getSelectedSlot() {
        if (selectedPosition >= 0 && selectedPosition < slots.size()) {
            return slots.get(selectedPosition);
        }
        return null;
    }

    @Override public int getCount() { return slots.size(); }
    @Override public Object getItem(int i) { return slots.get(i); }
    @Override public long getItemId(int i) { return i; }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.item_bone_part, viewGroup, false);
        }

        TextView tvPartName = view.findViewById(R.id.tvPartName);
        TextView tvZOrder = view.findViewById(R.id.tvZOrder);
        ImageView imgLock = view.findViewById(R.id.imgLock);

        BoneSlot slot = slots.get(i);
        tvPartName.setText(slot.getDisplayName());
        tvZOrder.setText("Z: " + slot.getZOrder());

        if (slot.isAspectLocked()) {
            imgLock.setVisibility(View.VISIBLE);
        } else {
            imgLock.setVisibility(View.INVISIBLE);
        }

        // Highlight selected item
        if (i == selectedPosition) {
            view.setBackgroundColor(Color.parseColor("#37474F")); // Highlight color
            tvPartName.setTextColor(Color.parseColor("#FFD700")); // Gold text
        } else {
            view.setBackgroundColor(Color.parseColor("#263238")); // Default
            tvPartName.setTextColor(Color.WHITE);
        }

        return view;
    }
}
