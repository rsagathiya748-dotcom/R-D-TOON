package com.rakesh.toonrig;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;
import java.io.InputStream;
import java.io.IOException;

public class CharacterSheetView extends View {
    private Bitmap sheet; 
    private Paint goldPaint, bonePaint;
    private boolean showMap = false;
    
    private BitmapRegionDecoder regionDecoder;
    private int originalWidth, originalHeight;
    
    // --- CROPPING BOXES ---
    public static final float[][] cropParts = {
        // --- HEAD (0 to 4) ---
        {0.0085f, 0.7495f, 0.1870f, 0.1567f}, 
        {0.2070f, 0.7471f, 0.1870f, 0.1567f}, 
        {0.4092f, 0.7495f, 0.1870f, 0.1567f}, 
        {0.6077f, 0.7495f, 0.1870f, 0.1567f}, 
        {0.8059f, 0.7495f, 0.1870f, 0.1567f}, 

        // --- TORSO (5 to 9) ---
        {0.0051f, 0.0044f, 0.2412f, 0.3623f}, 
        {0.2512f, 0.0027f, 0.2412f, 0.3623f}, 
        {0.5010f, 0.0037f, 0.2412f, 0.3623f}, 
        {0.7498f, 0.0024f, 0.2412f, 0.3623f}, 
        {0.0066f, 0.3767f, 0.2412f, 0.3623f}, 

        // --- RIGHT ARM TOP (10 to 14) ---
        {0.4070f, 0.3843f, 0.1333f, 0.1638f}, // Pose 1
        {0.2639f, 0.3838f, 0.1345f, 0.1616f}, // Pose 2 
        {0.4070f, 0.3843f, 0.1333f, 0.1638f}, // Pose 3 
        {0.2639f, 0.3838f, 0.1345f, 0.1616f}, // Pose 4
        {0.2639f, 0.3838f, 0.1345f, 0.1616f},

        // --- LEFT ARM TOP (15 to 19) ---
        {0.2639f, 0.3838f, 0.1345f, 0.1616f}, // Pose 1
        {0.4070f, 0.3843f, 0.1333f, 0.1638f}, // Pose 2 
        {0.2639f, 0.3838f, 0.1345f, 0.1616f}, // Pose 3 
        {0.2639f, 0.3838f, 0.1345f, 0.1616f}, // Pose 4
        {0.2639f, 0.3838f, 0.1345f, 0.1616f},

        // --- RIGHT ARM BOT (20 to 24) ---
        {0.3965f, 0.5542f, 0.1289f, 0.1633f}, // Pose 1
        {0.2632f, 0.5552f, 0.1277f, 0.1624f}, // Pose 2
        {0.3965f, 0.5542f, 0.1289f, 0.1633f}, // Pose 3 
        {0.2632f, 0.5552f, 0.1277f, 0.1624f}, // Pose 4
        {0.2632f, 0.5552f, 0.1277f, 0.1624f},

        // --- LEFT ARM BOT (25 to 29) ---
        {0.2632f, 0.5552f, 0.1277f, 0.1624f}, // Pose 1
        {0.3965f, 0.5542f, 0.1289f, 0.1633f}, // Pose 2
        {0.2632f, 0.5552f, 0.1277f, 0.1624f}, // Pose 3 
        {0.2632f, 0.5552f, 0.1277f, 0.1624f}, // Pose 4
        {0.2632f, 0.5552f, 0.1277f, 0.1624f},

        // --- RIGHT LEG TOP (30 to 34) ---
        {0.7166f, 0.3853f, 0.1309f, 0.1440f}, // Pose 1
        {0.5642f, 0.3843f, 0.1316f, 0.1440f}, // Pose 2 
        {0.7166f, 0.3853f, 0.1309f, 0.1440f}, // Pose 3 
        {0.5642f, 0.3843f, 0.1316f, 0.1440f}, // Pose 4
        {0.5642f, 0.3843f, 0.1316f, 0.1440f},

        // --- LEFT LEG TOP (35 to 39) ---
        {0.5642f, 0.3843f, 0.1316f, 0.1440f}, // Pose 1
        {0.7166f, 0.3853f, 0.1309f, 0.1440f}, // Pose 2 
        {0.5642f, 0.3843f, 0.1316f, 0.1440f}, // Pose 3 
        {0.5642f, 0.3843f, 0.1316f, 0.1440f}, // Pose 4
        {0.5642f, 0.3843f, 0.1316f, 0.1440f},

        // --- RIGHT LEG BOT (40 to 44) ---
        {0.7175f, 0.5359f, 0.1311f, 0.1616f}, // Pose 1
        {0.5657f, 0.5339f, 0.1309f, 0.1621f}, // Pose 2
        {0.7175f, 0.5359f, 0.1311f, 0.1616f}, // Pose 3 
        {0.5657f, 0.5339f, 0.1309f, 0.1621f}, // Pose 4
        {0.5657f, 0.5339f, 0.1309f, 0.1621f},

        // --- LEFT LEG BOT (45 to 49) ---
        {0.5657f, 0.5339f, 0.1309f, 0.1621f}, // Pose 1
        {0.7175f, 0.5359f, 0.1311f, 0.1616f}, // Pose 2
        {0.5657f, 0.5339f, 0.1309f, 0.1621f}, // Pose 3 
        {0.5657f, 0.5339f, 0.1309f, 0.1621f}, // Pose 4
        {0.5657f, 0.5339f, 0.1309f, 0.1621f},

        // --- RIGHT FOOT (50 to 54) ---
        {0.1379f, 0.9131f, 0.1057f, 0.0798f}, // Pose 1
        {0.3948f, 0.9131f, 0.1057f, 0.0798f}, // Pose 2 
        {0.6440f, 0.9131f, 0.1057f, 0.0798f}, // Pose 3 
        {0.7605f, 0.9131f, 0.1057f, 0.0798f}, // Pose 4
        {0.9314f, 0.3818f, 0.0632f, 0.0632f},

        // --- LEFT FOOT (55 to 59) ---
        {0.0081f, 0.9131f, 0.1057f, 0.0798f}, // Pose 1
        {0.2634f, 0.9131f, 0.1057f, 0.0798f}, // Pose 2 
        {0.5127f, 0.9131f, 0.1057f, 0.0798f}, // Pose 3 
        {0.7605f, 0.9131f, 0.1057f, 0.0798f}, // Pose 4
        {0.8525f, 0.3823f, 0.0625f, 0.0625f} 
    };

    // --- EXACT BONE MAPPING ---
    public static final float[][] boneParts = {
        // ================= POSE 1 =================
        {0.1042f, 0.0391f, 0.0137f, 0.0137f}, {0.0828f, 0.8479f, 0.0122f, 0.0122f}, 
        {0.1294f, 0.0630f, 0.0146f, 0.0146f}, {0.4487f, 0.4307f, 0.0146f, 0.0146f}, 
        {0.4705f, 0.4731f, 0.0146f, 0.0146f}, {0.4480f, 0.5842f, 0.0146f, 0.0146f}, 
        {0.0896f, 0.0623f, 0.0146f, 0.0146f}, {0.3252f, 0.4238f, 0.0146f, 0.0146f}, 
        {0.3135f, 0.4783f, 0.0146f, 0.0146f}, {0.3162f, 0.5945f, 0.0146f, 0.0146f}, 
        {0.1306f, 0.1765f, 0.0146f, 0.0146f}, {0.7808f, 0.4133f, 0.0146f, 0.0146f}, 
        {0.7715f, 0.4702f, 0.0146f, 0.0146f}, {0.7695f, 0.5750f, 0.0146f, 0.0146f}, 
        {0.7795f, 0.6379f, 0.0146f, 0.0146f}, {0.1819f, 0.9414f, 0.0078f, 0.0078f}, 
        {0.0994f, 0.1692f, 0.0146f, 0.0146f}, {0.6262f, 0.4172f, 0.0146f, 0.0146f}, 
        {0.6174f, 0.4705f, 0.0146f, 0.0146f}, {0.6211f, 0.5693f, 0.0146f, 0.0146f}, 
        {0.6294f, 0.6328f, 0.0146f, 0.0146f}, {0.0491f, 0.9365f, 0.0078f, 0.0078f}, 

        // ================= POSE 2 =================
        {0.3613f, 0.0369f, 0.0137f, 0.0137f}, {0.2920f, 0.8413f, 0.0122f, 0.0122f}, 
        {0.3760f, 0.0586f, 0.0146f, 0.0146f}, {0.3250f, 0.4241f, 0.0146f, 0.0146f}, 
        {0.3140f, 0.4778f, 0.0146f, 0.0146f}, {0.3164f, 0.5945f, 0.0146f, 0.0146f}, 
        {0.3352f, 0.0583f, 0.0159f, 0.0159f}, {0.4490f, 0.4307f, 0.0149f, 0.0149f}, 
        {0.4707f, 0.4731f, 0.0149f, 0.0149f}, {0.4482f, 0.5845f, 0.0146f, 0.0146f}, 
        {0.3657f, 0.1653f, 0.0149f, 0.0149f}, {0.6262f, 0.4172f, 0.0146f, 0.0146f}, 
        {0.6174f, 0.4705f, 0.0146f, 0.0146f}, {0.6211f, 0.5693f, 0.0146f, 0.0146f}, 
        {0.6294f, 0.6328f, 0.0146f, 0.0146f}, {0.4468f, 0.9395f, 0.0081f, 0.0081f},
        {0.3347f, 0.1724f, 0.0149f, 0.0149f}, {0.7808f, 0.4133f, 0.0146f, 0.0146f}, 
        {0.7715f, 0.4702f, 0.0146f, 0.0146f}, {0.7695f, 0.5750f, 0.0146f, 0.0146f}, 
        {0.7795f, 0.6379f, 0.0146f, 0.0146f}, {0.3040f, 0.9326f, 0.0076f, 0.0076f}, 

        // ================= POSE 3 =================
        {0.5977f, 0.0420f, 0.0134f, 0.0134f}, {0.4883f, 0.8279f, 0.0122f, 0.0122f},
        {0.6152f, 0.0632f, 0.0125f, 0.0125f}, {0.4497f, 0.4312f, 0.0144f, 0.0144f}, 
        {0.4702f, 0.4731f, 0.0144f, 0.0144f}, {0.4482f, 0.5845f, 0.0144f, 0.0144f}, 
        {0.6152f, 0.0632f, 0.0125f, 0.0125f}, {0.3257f, 0.4246f, 0.0144f, 0.0144f}, 
        {0.3137f, 0.4807f, 0.0144f, 0.0144f}, {0.3167f, 0.5950f, 0.0144f, 0.0144f}, 
        {0.6099f, 0.1641f, 0.0144f, 0.0144f}, {0.7808f, 0.4133f, 0.0146f, 0.0146f}, 
        {0.7715f, 0.4700f, 0.0146f, 0.0146f}, {0.7698f, 0.5747f, 0.0146f, 0.0146f}, 
        {0.7800f, 0.6382f, 0.0144f, 0.0144f}, {0.6970f, 0.9402f, 0.0073f, 0.0073f},
        {0.6099f, 0.1641f, 0.0144f, 0.0144f}, {0.6262f, 0.4175f, 0.0149f, 0.0149f}, 
        {0.6177f, 0.4705f, 0.0146f, 0.0146f}, {0.6213f, 0.5693f, 0.0146f, 0.0146f}, 
        {0.6299f, 0.6328f, 0.0144f, 0.0144f}, {0.5627f, 0.9363f, 0.0073f, 0.0073f},

        // ================= POSE 4 (Hip 1 Foot fixed, Hip 2 100% Restored) =================
        // 1. Head / Neck 
        {0.8503f, 0.0444f, 0.0132f, 0.0132f}, {0.6868f, 0.8491f, 0.0132f, 0.0132f}, 

        // 2. Right Arm Slot -> Attached to Right Shoulder (Shoulder 1)
        {0.8792f, 0.0637f, 0.0164f, 0.0164f}, {0.3250f, 0.4238f, 0.0149f, 0.0149f},
        {0.3135f, 0.4780f, 0.0149f, 0.0149f}, {0.3159f, 0.5945f, 0.0149f, 0.0146f},

        // 3. Left Arm Slot -> Attached to Left Shoulder (Shoulder 2)
        {0.8220f, 0.0647f, 0.0144f, 0.0144f}, {0.3252f, 0.4243f, 0.0146f, 0.0146f},
        {0.3132f, 0.4780f, 0.0146f, 0.0146f}, {0.3167f, 0.5945f, 0.0149f, 0.0146f},

        // 4. Right Leg Slot -> Attached to Right Hip (Hip 1) - FOOT UPDATED HERE
        {0.8696f, 0.1641f, 0.0142f, 0.0146f}, {0.6260f, 0.4172f, 0.0154f, 0.0154f},
        {0.6169f, 0.4700f, 0.0154f, 0.0154f}, {0.6211f, 0.5691f, 0.0146f, 0.0146f},
        {0.6296f, 0.6331f, 0.0142f, 0.0142f}, {0.8020f, 0.9404f, 0.0076f, 0.0076f},

        // 5. Left Leg Slot -> Attached to Left Hip (Hip 2) - 100% RESTORED TO ORIGINAL DEFAULT
        {0.8347f, 0.1636f, 0.0151f, 0.0151f}, {0.6260f, 0.4172f, 0.0154f, 0.0154f},
        {0.6169f, 0.4700f, 0.0154f, 0.0154f}, {0.6211f, 0.5691f, 0.0146f, 0.0146f},
        {0.6294f, 0.6326f, 0.0146f, 0.0146f}, {0.8022f, 0.9402f, 0.0076f, 0.0076f},

        // ================= POSE 5 =================
        {0.1162f, 0.4216f, 0.0095f, 0.0095f}, {0.8911f, 0.8428f, 0.0088f, 0.0088f},
        {0.1436f, 0.4451f, 0.0154f, 0.0154f}, {0.3252f, 0.4243f, 0.0146f, 0.0146f},
        {0.3132f, 0.4780f, 0.0146f, 0.0146f}, {0.3167f, 0.5945f, 0.0149f, 0.0146f},
        {0.0854f, 0.4456f, 0.0122f, 0.0122f}, {0.3252f, 0.4243f, 0.0146f, 0.0146f},
        {0.3132f, 0.4780f, 0.0146f, 0.0146f}, {0.3167f, 0.5945f, 0.0149f, 0.0146f},
        {0.1335f, 0.5449f, 0.0144f, 0.0144f}, {0.6260f, 0.4172f, 0.0154f, 0.0154f},
        {0.6169f, 0.4700f, 0.0154f, 0.0154f}, {0.6211f, 0.5691f, 0.0146f, 0.0146f},
        {0.6294f, 0.6326f, 0.0146f, 0.0146f}, {0.9553f, 0.4023f, 0.0076f, 0.0076f},
        {0.0984f, 0.5442f, 0.0151f, 0.0151f}, {0.6260f, 0.4172f, 0.0154f, 0.0154f},
        {0.6169f, 0.4700f, 0.0154f, 0.0154f}, {0.6211f, 0.5691f, 0.0146f, 0.0146f},
        {0.6294f, 0.6326f, 0.0146f, 0.0146f}, {0.8806f, 0.3987f, 0.0078f, 0.0078f}
    };

    public CharacterSheetView(Context context) { super(context); init(); }
    public CharacterSheetView(Context context, AttributeSet attrs) { super(context, attrs); init(); }
    public CharacterSheetView(Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); init(); }

    private void init() {
        goldPaint = new Paint(); goldPaint.setColor(Color.parseColor("#FFD700")); goldPaint.setStyle(Paint.Style.STROKE); goldPaint.setStrokeWidth(5f);
        bonePaint = new Paint(); bonePaint.setColor(Color.WHITE); bonePaint.setStyle(Paint.Style.FILL);
        try { 
            InputStream is = getResources().openRawResource(R.drawable.character_sheet);
            regionDecoder = BitmapRegionDecoder.newInstance(is, false);
            originalWidth = regionDecoder.getWidth();
            originalHeight = regionDecoder.getHeight();
            BitmapFactory.Options options = new BitmapFactory.Options(); options.inScaled = false;
            sheet = BitmapFactory.decodeResource(getResources(), R.drawable.character_sheet, options); 
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void setSheetFromFile(String imagePath) {
        try {
            regionDecoder = BitmapRegionDecoder.newInstance(imagePath, false);
            originalWidth = regionDecoder.getWidth();
            originalHeight = regionDecoder.getHeight();
            BitmapFactory.Options previewOptions = new BitmapFactory.Options(); previewOptions.inSampleSize = 4;
            this.sheet = BitmapFactory.decodeFile(imagePath, previewOptions);
            invalidate();
        } catch (IOException e) { e.printStackTrace(); }
    }

    public void setSheetBitmap(Bitmap bitmap) { if (bitmap != null) { this.sheet = bitmap; invalidate(); } }
    public void setShowMapping(boolean visible) { this.showMap = visible; invalidate(); }
    public boolean isShowMap() { return showMap; }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.BLACK);
        if (sheet == null) return;
        float viewW = getWidth(); float viewH = getHeight();
        float imageRatio = (float) sheet.getWidth() / sheet.getHeight();
        float viewRatio = viewW / viewH;
        float drawW, drawH;
        if (imageRatio > viewRatio) { drawW = viewW; drawH = viewW / imageRatio; } 
        else { drawH = viewH; drawW = viewH * imageRatio; }
        float leftOffset = (viewW - drawW) / 2f; float topOffset = (viewH - drawH) / 2f;
        
        canvas.drawBitmap(sheet, null, new RectF(leftOffset, topOffset, leftOffset + drawW, topOffset + drawH), null);
        
        if (showMap) {
            for (float[] p : cropParts) { canvas.drawRect(leftOffset + (p[0] * drawW), topOffset + (p[1] * drawH), leftOffset + ((p[0] + p[2]) * drawW), topOffset + ((p[1] + p[3]) * drawH), goldPaint); }
            for (float[] bP : boneParts) { canvas.drawRect(leftOffset + (bP[0] * drawW), topOffset + (bP[1] * drawH), leftOffset + ((bP[0] + bP[2]) * drawW), topOffset + ((bP[1] + bP[3]) * drawH), bonePaint); }
        }
    }

    public Bitmap getCroppedPart(int index) {
        if (regionDecoder == null || index < 0 || index >= cropParts.length) return null;
        float[] p = cropParts[index];
        int x = (int)(p[0] * originalWidth); int y = (int)(p[1] * originalHeight);
        int w = (int)(p[2] * originalWidth); int h = (int)(p[3] * originalHeight);
        if (x < 0) x = 0; if (y < 0) y = 0;
        if (x + w > originalWidth) w = originalWidth - x;
        if (y + h > originalHeight) h = originalHeight - y;
        if (w <= 0 || h <= 0) return null;
        try {
            Rect cropRect = new Rect(x, y, x + w, y + h);
            BitmapFactory.Options options = new BitmapFactory.Options(); options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return regionDecoder.decodeRegion(cropRect, options);
        } catch (Exception e) { e.printStackTrace(); return null; }
    }
}
