package com.rakesh.toonrig;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;

public class BackgroundSelectionActivity extends Activity {
    private Button btnBgBack, tabBackgrounds, tabEffects, btnImportBg;
    private GridView bgGridView;
    
    // Yahan class ko 'static' banaya gaya hai taki data safe rahe
    public static class BgItem {
        String name; int colorCode; int resId; Uri imageUri;
        public BgItem(String name, int colorCode, int resId, Uri uri) {
            this.name = name; this.colorCode = colorCode; this.resId = resId; this.imageUri = uri;
        }
    }

    public static ArrayList<BgItem> bgList = new ArrayList<>();
    public static ArrayList<BgItem> effectsList = new ArrayList<>();
    private BgAdapter currentAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_background_selection);

        btnBgBack = findViewById(R.id.btnBgBack);
        tabBackgrounds = findViewById(R.id.tabBackgrounds);
        tabEffects = findViewById(R.id.tabEffects);
        btnImportBg = findViewById(R.id.btnImportBg);
        bgGridView = findViewById(R.id.bgGridView);

        if (bgList.isEmpty()) {
            bgList.add(new BgItem("Green Screen", Color.parseColor("#00FF00"), 0, null));
            bgList.add(new BgItem("Blue Screen", Color.parseColor("#0000FF"), 0, null));
            bgList.add(new BgItem("Dark (Default)", Color.parseColor("#222222"), 0, null));
        }

        if (effectsList.isEmpty()) {
            effectsList.add(new BgItem("Rain VFX", Color.parseColor("#424242"), 0, null));
            effectsList.add(new BgItem("Snow VFX", Color.parseColor("#424242"), 0, null));
        }

        currentAdapter = new BgAdapter(this, bgList);
        bgGridView.setAdapter(currentAdapter);

        tabBackgrounds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Build.VERSION.SDK_INT >= 21) {
                    tabBackgrounds.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#D19035"))); 
                    tabEffects.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#424242"))); 
                }
                currentAdapter = new BgAdapter(BackgroundSelectionActivity.this, bgList);
                bgGridView.setAdapter(currentAdapter);
            }
        });

        tabEffects.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Build.VERSION.SDK_INT >= 21) {
                    tabEffects.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#D19035"))); 
                    tabBackgrounds.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#424242"))); 
                }
                currentAdapter = new BgAdapter(BackgroundSelectionActivity.this, effectsList);
                bgGridView.setAdapter(currentAdapter);
            }
        });

        bgGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                BgItem clickedItem = (BgItem) currentAdapter.getItem(position);
                Intent resultIntent = new Intent();
                if(clickedItem.imageUri != null) {
                    resultIntent.setData(clickedItem.imageUri);
                } else if (clickedItem.resId != 0) {
                    resultIntent.putExtra("bgResId", clickedItem.resId);
                } else {
                    resultIntent.putExtra("bgColor", clickedItem.colorCode);
                }
                setResult(RESULT_OK, resultIntent);
                finish(); 
            }
        });

        btnImportBg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); 
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*"); 
                startActivityForResult(intent, 100);
            }
        });

        btnBgBack.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { finish(); } });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            try {
                // Permanent permission le rahe hain taki image gayab na ho
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    getContentResolver().takePersistableUriPermission(data.getData(), Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
            } catch (Exception e) {}
            
            bgList.add(new BgItem("Imported BG", Color.TRANSPARENT, 0, data.getData()));
            currentAdapter.notifyDataSetChanged();
        }
    }

    class BgAdapter extends BaseAdapter {
        Context context; ArrayList<BgItem> list;
        BgAdapter(Context c, ArrayList<BgItem> l) { this.context = c; this.list = l; }
        @Override public int getCount() { return list.size(); }
        @Override public Object getItem(int pos) { return list.get(pos); }
        @Override public long getItemId(int pos) { return pos; }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout layout = new LinearLayout(context);
            layout.setOrientation(LinearLayout.VERTICAL); layout.setGravity(Gravity.CENTER); layout.setPadding(10, 10, 10, 10);
            BgItem item = list.get(position);
            
            if(item.imageUri != null) {
                ImageView iv = new ImageView(context); iv.setLayoutParams(new LinearLayout.LayoutParams(150, 150));
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP); iv.setImageURI(item.imageUri); layout.addView(iv);
            } else if (item.resId != 0) {
                ImageView iv = new ImageView(context); iv.setLayoutParams(new LinearLayout.LayoutParams(150, 150));
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP); iv.setImageResource(item.resId); layout.addView(iv);
            } else {
                View colorBox = new View(context); colorBox.setLayoutParams(new LinearLayout.LayoutParams(150, 150));
                colorBox.setBackgroundColor(item.colorCode); layout.addView(colorBox);
            }

            TextView tv = new TextView(context); tv.setText(item.name); tv.setTextColor(Color.WHITE);
            tv.setGravity(Gravity.CENTER); tv.setPadding(0, 10, 0, 0); layout.addView(tv);
            return layout;
        }
    }
}
