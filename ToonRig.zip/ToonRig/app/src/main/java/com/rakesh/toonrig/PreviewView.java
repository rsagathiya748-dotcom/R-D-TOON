package com.rakesh.toonrig;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

public class PreviewView extends View {
    private Paint paint = new Paint();
    private ScaleGestureDetector scaleDetector;
    private float scaleFactor = 1.0f; 
    private float cx, cy;
    
    private Bitmap bgRefImage = null;
    private float bgX = 0f, bgY = 0f, bgScale = 1.0f;

    // 5 Modes Set 
    public static final int MODE_BONE = 0, MODE_CHAR = 1, MODE_BG = 2, MODE_MESH = 3, MODE_PERSPECTIVE = 4;
    private int currentMode = MODE_BONE;
    
    // Array Size 14 for Lock Panel (0-10 Bones, 11 Torso, 12 Full Body, 13 Shadow)
    private boolean[] unlockedParts = new boolean[14];
    private int chromaColor = Color.parseColor("#222222"); 
    
    private boolean isPlaying = false;
    private int currentPlayFrame = 0;
    private int currentViewFrame = 0; 
    private float prevX, prevY;
    private int animSpeedMs = 30;

    private HashMap<Integer, Matrix> currentPartMatrices = new HashMap<>();
    private int activeMeshPoint = -1;

    public float[] advScale = {1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f};
    public int[] advPose = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    public int[] advZIndex = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    class DrawAction implements Comparable<DrawAction> {
        int zIndex; Runnable action;
        DrawAction(int z, Runnable a) { zIndex = z; action = a; }
        public int compareTo(DrawAction o) { return Integer.compare(this.zIndex, o.zIndex); }
    }

    public interface OnFrameChangeListener { void onFrameChanged(int frame); }
    private OnFrameChangeListener frameListener;
    public void setOnFrameChangeListener(OnFrameChangeListener listener) { this.frameListener = listener; }

    public static class KeyFrame {
        int frameNo; float cX, cY, hR, hl1, hl2, hr1, hr2, ll1, ll2, f1, lr1, lr2, f2;
        public float sX = 0f, sY = 0f;
        public int alp = 255, ease = 0;
        
        public HashMap<Integer, float[]> kfMeshes = new HashMap<>();
        public HashMap<Integer, float[]> kfPerspectives = new HashMap<>();

        KeyFrame(int fNo, float cx, float cy, float hR, float hl1, float hl2, float hr1, float hr2, float ll1, float ll2, float f1, float lr1, float lr2, float f2) {
            this.frameNo = fNo; this.cX = cx; this.cY = cy; this.hR = hR;
            this.hl1 = hl1; this.hl2 = hl2; this.hr1 = hr1; this.hr2 = hr2;
            this.ll1 = ll1; this.ll2 = ll2; this.f1 = f1; this.lr1 = lr1; this.lr2 = lr2; this.f2 = f2;
        }
    }

    public PreviewView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint.setFilterBitmap(true); paint.setAntiAlias(true);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null); 
        scaleDetector = new ScaleGestureDetector(context, new ScaleListener());
    }

    public void setAnimSpeedMs(int speed) { this.animSpeedMs = speed; }
    public void setChromaColor(int color) { this.chromaColor = color; invalidate(); }
    public int getChromaColor() { return this.chromaColor; }
    public void setCurrentMode(int mode) { this.currentMode = mode; invalidate(); }
    public void setBackgroundReference(Bitmap bmp) { this.bgRefImage = bmp; bgX = 0; bgY = 0; bgScale = 1.0f; invalidate(); }
    public boolean[] getUnlockedParts() { return unlockedParts; }
    public void setUnlockedPart(int index, boolean isUnlocked) { unlockedParts[index] = isUnlocked; invalidate(); }
    
    public int getSingleUnlockedPart() {
        int idx = -1; int count = 0;
        for(int i=0; i<unlockedParts.length; i++) { if(unlockedParts[i]) { idx = i; count++; } }
        return count == 1 ? idx : -1;
    }
    
    public void toggleFlipX() { SceneCharacter sc = DataHolder.getActiveChar(); if(sc != null) { sc.flipX = !sc.flipX; invalidate(); } }
    public void toggleFlipY() { SceneCharacter sc = DataHolder.getActiveChar(); if(sc != null) { sc.flipY = !sc.flipY; invalidate(); } }
    
    public void changePose(int newPose) {
        SceneCharacter sc = DataHolder.getActiveChar();
        if(sc != null) {
            sc.currentPose = newPose; sc.globalX = 0f; sc.globalY = 0f; sc.headRot = 0f; 
            sc.hl1Rot = 0f; sc.hl2Rot = 0f; sc.hr1Rot = 0f; sc.hr2Rot = 0f; sc.ll1Rot = 0f; sc.ll2Rot = 0f; sc.f1Rot = 0f; sc.lr1Rot = 0f; sc.lr2Rot = 0f; sc.f2Rot = 0f; sc.flipX = false; sc.flipY = false;
            sc.skewX = 0f; sc.skewY = 0f; sc.alpha = 255; sc.easingType = 0;
        }
        scaleFactor = 1.0f; setFrameManualForAll(0); invalidate();
    }

    public HashMap<Integer, HashMap<Integer, KeyFrame>> getPoseTimelines() { if(DataHolder.getActiveChar() == null) return new HashMap<>(); return DataHolder.getActiveChar().animationTimelines; }
    public void setPoseTimelines(HashMap<Integer, HashMap<Integer, KeyFrame>> loadedTimelines) { if(DataHolder.getActiveChar() != null) { DataHolder.getActiveChar().animationTimelines = loadedTimelines; invalidate(); } }

    public void addKeyframeAtCurrentProgress(int frameNo) {
        SceneCharacter sc = DataHolder.getActiveChar(); if(sc == null) return;
        KeyFrame kf = new KeyFrame(frameNo, sc.globalX, sc.globalY, sc.headRot, sc.hl1Rot, sc.hl2Rot, sc.hr1Rot, sc.hr2Rot, sc.ll1Rot, sc.ll2Rot, sc.f1Rot, sc.lr1Rot, sc.lr2Rot, sc.f2Rot);
        kf.sX = sc.skewX; kf.sY = sc.skewY; kf.alp = sc.alpha; kf.ease = sc.easingType;
        
        String prefix = DataHolder.activeCharIndex + "_";
        for(String key : DataHolder.partMeshes.keySet()) { if(key.startsWith(prefix)) { int pId = Integer.parseInt(key.split("_")[1]); kf.kfMeshes.put(pId, DataHolder.partMeshes.get(key).clone()); } }
        for(String key : DataHolder.partPerspectives.keySet()) { if(key.startsWith(prefix)) { int pId = Integer.parseInt(key.split("_")[1]); kf.kfPerspectives.put(pId, DataHolder.partPerspectives.get(key).clone()); } }
        
        sc.animationTimelines.get(sc.currentPose).put(frameNo, kf);
    }
    public void removeKeyframeAtCurrentProgress(int frameNo) { SceneCharacter sc = DataHolder.getActiveChar(); if(sc != null) sc.animationTimelines.get(sc.currentPose).remove(frameNo); }
    public ArrayList<Integer> getAllKeyframes() { ArrayList<Integer> keys = new ArrayList<>(); SceneCharacter sc = DataHolder.getActiveChar(); if (sc != null && sc.animationTimelines.containsKey(sc.currentPose)) { keys.addAll(sc.animationTimelines.get(sc.currentPose).keySet()); } return keys; }
    public int getLastKeyframeNumber() { int max = 0; for (SceneCharacter sc : DataHolder.sceneCharacters) { if (sc.animationTimelines.containsKey(sc.currentPose)) { for (Integer frame : sc.animationTimelines.get(sc.currentPose).keySet()) { if (frame > max) max = frame; } } } return max; }

    public void setFrameManualForAll(int targetFrame) { this.currentViewFrame = targetFrame; for (SceneCharacter sc : DataHolder.sceneCharacters) { applyFrameToCharacter(sc, targetFrame); } invalidate(); }
    public void setFrameManual(int targetFrame) { setFrameManualForAll(targetFrame); }

    private void applyFrameToCharacter(SceneCharacter sc, int targetFrame) {
        HashMap<Integer, KeyFrame> tl = sc.animationTimelines.get(sc.currentPose); if (tl == null || tl.isEmpty()) return;
        if (tl.containsKey(targetFrame)) {
            KeyFrame k = tl.get(targetFrame); sc.globalX = k.cX; sc.globalY = k.cY; sc.headRot = k.hR;
            sc.hl1Rot = k.hl1; sc.hl2Rot = k.hl2; sc.hr1Rot = k.hr1; sc.hr2Rot = k.hr2; sc.ll1Rot = k.ll1; sc.ll2Rot = k.ll2; sc.f1Rot = k.f1; sc.lr1Rot = k.lr1; sc.lr2Rot = k.lr2; sc.f2Rot = k.f2; 
            sc.skewX = k.sX; sc.skewY = k.sY; sc.alpha = k.alp; sc.easingType = k.ease;
            
            String pfix = DataHolder.sceneCharacters.indexOf(sc) + "_";
            for(int pId : k.kfMeshes.keySet()) { DataHolder.partMeshes.put(pfix+pId, k.kfMeshes.get(pId).clone()); }
            for(int pId : k.kfPerspectives.keySet()) { DataHolder.partPerspectives.put(pfix+pId, k.kfPerspectives.get(pId).clone()); }

        } else {
            int prevF = -1, nextF = 999;
            for (Integer frame : tl.keySet()) { if (frame < targetFrame && frame > prevF) prevF = frame; if (frame > targetFrame && frame < nextF) nextF = frame; }
            if (prevF != -1 && nextF != 999) {
                KeyFrame k1 = tl.get(prevF); KeyFrame k2 = tl.get(nextF); float f = (float) (targetFrame - prevF) / (nextF - prevF);
                if (k1.ease == 1) { f = f * f; } else if (k1.ease == 2) { f = f * (2f - f); } else if (k1.ease == 3) { f = f < 0.5f ? 2f * f * f : -1f + (4f - 2f * f) * f; } 
                sc.globalX = k1.cX + (k2.cX - k1.cX) * f; sc.globalY = k1.cY + (k2.cY - k1.cY) * f; sc.headRot = k1.hR + (k2.hR - k1.hR) * f;
                sc.hl1Rot = k1.hl1 + (k2.hl1 - k1.hl1) * f; sc.hl2Rot = k1.hl2 + (k2.hl2 - k1.hl2) * f; sc.hr1Rot = k1.hr1 + (k2.hr1 - k1.hr1) * f; sc.hr2Rot = k1.hr2 + (k2.hr2 - k1.hr2) * f;
                sc.ll1Rot = k1.ll1 + (k2.ll1 - k1.ll1) * f; sc.ll2Rot = k1.ll2 + (k2.ll2 - k1.ll2) * f; sc.f1Rot = k1.f1 + (k2.f1 - k1.f1) * f; sc.lr1Rot = k1.lr1 + (k2.lr1 - k1.lr1) * f; sc.lr2Rot = k1.lr2 + (k2.lr2 - k1.lr2) * f; sc.f2Rot = k1.f2 + (k2.f2 - k1.f2) * f;
                sc.skewX = k1.sX + (k2.sX - k1.sX) * f; sc.skewY = k1.sY + (k2.sY - k1.sY) * f; sc.alpha = (int) (k1.alp + (k2.alp - k1.alp) * f); sc.easingType = k1.ease;
                
                String pfix = DataHolder.sceneCharacters.indexOf(sc) + "_";
                for (int pId : k1.kfPerspectives.keySet()) {
                    float[] p1 = k1.kfPerspectives.get(pId); float[] p2 = k2.kfPerspectives.containsKey(pId) ? k2.kfPerspectives.get(pId) : p1;
                    float[] pCur = new float[p1.length]; for (int i=0; i<p1.length; i++) { pCur[i] = p1[i] + (p2[i] - p1[i]) * f; }
                    DataHolder.partPerspectives.put(pfix+pId, pCur);
                }
                for (int pId : k1.kfMeshes.keySet()) {
                    float[] m1 = k1.kfMeshes.get(pId); float[] m2 = k2.kfMeshes.containsKey(pId) ? k2.kfMeshes.get(pId) : m1;
                    float[] mCur = new float[m1.length]; for (int i=0; i<m1.length; i++) { mCur[i] = m1[i] + (m2[i] - m1[i]) * f; }
                    DataHolder.partMeshes.put(pfix+pId, mCur);
                }
            }
        }
    }

    private KeyFrame getPreviousKeyFrame(SceneCharacter sc, int currentFrame) {
        HashMap<Integer, KeyFrame> tl = sc.animationTimelines.get(sc.currentPose); if (tl == null || tl.isEmpty()) return null;
        int prevFrame = -1; for (Integer f : tl.keySet()) { if (f < currentFrame && f > prevFrame) prevFrame = f; }
        if (prevFrame != -1) return tl.get(prevFrame); return null;
    }

    public boolean isPlayingAnim() { return isPlaying; }
    public void startPlaying() { isPlaying = true; currentPlayFrame = 0; post(playRunnable); }
    public void stopPlaying() { isPlaying = false; }

    private Runnable playRunnable = new Runnable() {
        @Override public void run() {
            if (!isPlaying) return;
            setFrameManualForAll(currentPlayFrame); if(frameListener != null) frameListener.onFrameChanged(currentPlayFrame);
            if (currentPlayFrame >= getLastKeyframeNumber()) { currentPlayFrame = 0; } else { currentPlayFrame++; }
            postDelayed(this, animSpeedMs); 
        }
    };

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) { super.onSizeChanged(w, h, oldw, oldh); cx = w / 2f; cy = h / 2f; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas); canvas.drawColor(chromaColor); canvas.save(); canvas.scale(scaleFactor, scaleFactor, cx, cy);
        if (bgRefImage != null) { canvas.save(); canvas.translate(bgX, bgY); canvas.scale(bgScale, bgScale); canvas.drawBitmap(bgRefImage, 0, 0, paint); canvas.restore(); }
        
        currentPartMatrices.clear(); 
        ArrayList<SceneCharacter> sortedChars = new ArrayList<>(DataHolder.sceneCharacters);
        Collections.sort(sortedChars, new Comparator<SceneCharacter>() { @Override public int compare(SceneCharacter c1, SceneCharacter c2) { return Integer.compare(c1.zOrder, c2.zOrder); } });
        
        for (SceneCharacter sc : sortedChars) { 
            if (DataHolder.isOnionSkinEnabled && !isPlaying && currentViewFrame > 0) {
                KeyFrame prevKf = getPreviousKeyFrame(sc, currentViewFrame);
                if (prevKf != null) {
                    float tcx = sc.globalX, tcy = sc.globalY, thr = sc.headRot, thl1 = sc.hl1Rot, thl2 = sc.hl2Rot;
                    float thr1 = sc.hr1Rot, thr2 = sc.hr2Rot, tll1 = sc.ll1Rot, tll2 = sc.ll2Rot, tf1 = sc.f1Rot;
                    float tlr1 = sc.lr1Rot, tlr2 = sc.lr2Rot, tf2 = sc.f2Rot; float tSx = sc.skewX, tSy = sc.skewY; int tAlp = sc.alpha;
                    
                    sc.globalX = prevKf.cX; sc.globalY = prevKf.cY; sc.headRot = prevKf.hR;
                    sc.hl1Rot = prevKf.hl1; sc.hl2Rot = prevKf.hl2; sc.hr1Rot = prevKf.hr1; sc.hr2Rot = prevKf.hr2;
                    sc.ll1Rot = prevKf.ll1; sc.ll2Rot = prevKf.ll2; sc.f1Rot = prevKf.f1; sc.lr1Rot = prevKf.lr1; sc.lr2Rot = prevKf.lr2; sc.f2Rot = prevKf.f2; sc.skewX = prevKf.sX; sc.skewY = prevKf.sY; sc.alpha = prevKf.alp;
                    
                    drawSceneCharacter(canvas, sc, false, 80);
                    
                    sc.globalX = tcx; sc.globalY = tcy; sc.headRot = thr; sc.hl1Rot = thl1; sc.hl2Rot = thl2; sc.hr1Rot = thr1; sc.hr2Rot = thr2;
                    sc.ll1Rot = tll1; sc.ll2Rot = tll2; sc.f1Rot = tf1; sc.lr1Rot = tlr1; sc.lr2Rot = tlr2; sc.f2Rot = tf2; sc.skewX = tSx; sc.skewY = tSy; sc.alpha = tAlp;
                }
            }
            if (DataHolder.isShadowEnabled) { drawSceneCharacter(canvas, sc, true, 255); }
            drawSceneCharacter(canvas, sc, false, 255); 
        }
        canvas.restore(); 
        
        if ((currentMode == MODE_MESH || currentMode == MODE_PERSPECTIVE) && !isPlaying) {
            int activeUid = getSingleUnlockedPart();
            if (activeUid != -1 && currentPartMatrices.containsKey(activeUid)) {
                String key = DataHolder.activeCharIndex + "_" + activeUid;
                float[] ptsData = currentMode == MODE_MESH ? DataHolder.partMeshes.get(key) : DataHolder.partPerspectives.get(key);
                
                if (ptsData != null) {
                    Matrix m = currentPartMatrices.get(activeUid);
                    float[] localPts = new float[18];
                    localPts[0] = ptsData[0]; localPts[1] = ptsData[1]; localPts[2] = ptsData[2]; localPts[3] = ptsData[3];
                    localPts[4] = ptsData[4]; localPts[5] = ptsData[5]; localPts[6] = ptsData[6]; localPts[7] = ptsData[7];
                    localPts[8] = (ptsData[0]+ptsData[2])/2f; localPts[9] = (ptsData[1]+ptsData[3])/2f; 
                    localPts[10] = (ptsData[2]+ptsData[4])/2f; localPts[11] = (ptsData[3]+ptsData[5])/2f;
                    localPts[12] = (ptsData[4]+ptsData[6])/2f; localPts[13] = (ptsData[5]+ptsData[7])/2f;
                    localPts[14] = (ptsData[6]+ptsData[0])/2f; localPts[15] = (ptsData[7]+ptsData[1])/2f;
                    localPts[16] = (ptsData[0]+ptsData[2]+ptsData[4]+ptsData[6])/4f; localPts[17] = (ptsData[1]+ptsData[3]+ptsData[5]+ptsData[7])/4f;

                    float[] screenPts = localPts.clone(); m.mapPoints(screenPts);
                    
                    canvas.save(); canvas.setMatrix(new Matrix()); 
                    Paint lineP = new Paint(); 
                    
                    if (currentMode == MODE_PERSPECTIVE) {
                        lineP.setColor(Color.parseColor("#42A5F5")); lineP.setStrokeWidth(3f);
                        canvas.drawLine(screenPts[0], screenPts[1], screenPts[2], screenPts[3], lineP);
                        canvas.drawLine(screenPts[2], screenPts[3], screenPts[4], screenPts[5], lineP);
                        canvas.drawLine(screenPts[4], screenPts[5], screenPts[6], screenPts[7], lineP);
                        canvas.drawLine(screenPts[6], screenPts[7], screenPts[0], screenPts[1], lineP);
                    } else {
                        lineP.setColor(Color.WHITE); lineP.setAlpha(120); lineP.setStrokeWidth(2f);
                        canvas.drawLine(screenPts[0], screenPts[1], screenPts[4], screenPts[5], lineP); canvas.drawLine(screenPts[6], screenPts[7], screenPts[10], screenPts[11], lineP); canvas.drawLine(screenPts[12], screenPts[13], screenPts[16], screenPts[17], lineP);
                        canvas.drawLine(screenPts[0], screenPts[1], screenPts[12], screenPts[13], lineP); canvas.drawLine(screenPts[2], screenPts[3], screenPts[14], screenPts[15], lineP); canvas.drawLine(screenPts[4], screenPts[5], screenPts[16], screenPts[17], lineP);
                    }

                    Paint p = new Paint(); p.setAntiAlias(true);
                    for (int i=0; i< (currentMode == MODE_PERSPECTIVE ? 9 : 9); i++) {
                        float sx = screenPts[i*2]; float sy = screenPts[i*2+1];
                        if (i == activeMeshPoint) { p.setColor(Color.WHITE); }
                        else if (currentMode == MODE_PERSPECTIVE) {
                            if (i < 4) p.setColor(Color.parseColor("#1976D2")); 
                            else if (i < 8) p.setColor(Color.parseColor("#4CAF50")); 
                            else p.setColor(Color.parseColor("#FFCA28")); 
                        } else {
                            p.setColor(Color.argb(200, 244, 67, 54));
                        }
                        
                        canvas.drawCircle(sx, sy, 14f, p); 
                        p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3f); 
                        canvas.drawCircle(sx, sy, 14f, p); p.setStyle(Paint.Style.FILL);
                    }
                    canvas.restore();
                }
            }
        }
    }

    private Bitmap getPart(Bitmap[] parts, int index) { if (parts != null && index >= 0 && index < parts.length) { return parts[index]; } return null; }
    private float[] getRb(float[][] rb, int index) { if (rb != null && index >= 0 && index < rb.length) { return rb[index]; } return null; }

    private void drawAdvancedPart(Canvas c, Bitmap bmp, int uId, boolean isShadow) {
        if (bmp == null) return;
        if (uId == -1) { c.drawBitmap(bmp, 0, 0, paint); return; }
        
        String key = DataHolder.activeCharIndex + "_" + uId;
        int w = bmp.getWidth(); int h = bmp.getHeight();
        
        float[] persp = DataHolder.partPerspectives.get(key);
        if (persp == null) { persp = new float[] { 0, 0, w, 0, w, h, 0, h }; DataHolder.partPerspectives.put(key, persp); }
        
        float[] mesh = DataHolder.partMeshes.get(key);
        if (mesh == null) { mesh = new float[] { 0, 0, w/2f, 0, w, 0, 0, h/2f, w/2f, h/2f, w, h/2f, 0, h, w/2f, h, w, h }; DataHolder.partMeshes.put(key, mesh); }

        if (!isShadow && getSingleUnlockedPart() == uId) { currentPartMatrices.put(uId, new Matrix(c.getMatrix())); }

        c.save();
        Matrix pMatrix = new Matrix(); float[] srcPersp = { 0, 0, w, 0, w, h, 0, h };
        pMatrix.setPolyToPoly(srcPersp, 0, persp, 0, 4); c.concat(pMatrix);
        c.drawBitmapMesh(bmp, 2, 2, mesh, 0, null, 0, paint);
        c.restore();
    }

    private void drawSceneCharacter(final Canvas canvas, final SceneCharacter sc, final boolean isShadow, final int alphaAmount) {
        int p = sc.currentPose - 1; if (p < 0 || p > 4) return;
        final Bitmap torso = getPart(sc.parts, 5 + p); if (torso == null) return;

        float baseScale = (getHeight() * 0.35f) / torso.getHeight();
        canvas.save(); canvas.scale((sc.flipX ? -baseScale : baseScale) * sc.globalScale, (sc.flipY ? -baseScale : baseScale) * sc.globalScale, cx, cy);

        final float tW = torso.getWidth(); final float tH = torso.getHeight();
        final float tL = (cx - (tW / 2f)) + sc.globalX; final float tT = (cy - (tH / 2f)) + sc.globalY;
        
        float pX = tL + (tW / 2f); float pY = tT + (tH / 2f);
        canvas.translate(pX, pY); canvas.skew(sc.skewX, sc.skewY); canvas.translate(-pX, -pY);
        
        // 12. FULL BODY PERSPECTIVE
        String fullKey = DataHolder.sceneCharacters.indexOf(sc) + "_12";
        float[] fullPersp = DataHolder.partPerspectives.get(fullKey);
        if (fullPersp == null) { float fW = tW * 1.5f; float fH = tH * 1.5f; fullPersp = new float[] { -fW, -fH, fW, -fH, fW, fH, -fW, fH }; DataHolder.partPerspectives.put(fullKey, fullPersp); }
        
        canvas.translate(pX, pY); 
        Matrix fMatrix = new Matrix(); float fW = tW * 1.5f; float fH = tH * 1.5f; float[] srcFp = { -fW, -fH, fW, -fH, fW, fH, -fW, fH };
        fMatrix.setPolyToPoly(srcFp, 0, fullPersp, 0, 4); canvas.concat(fMatrix);
        
        if (!isShadow && getSingleUnlockedPart() == 12) { Matrix saveM = new Matrix(canvas.getMatrix()); saveM.preTranslate(-pX, -pY); currentPartMatrices.put(12, saveM); }
        canvas.translate(-pX, -pY);
        
        // 13. SHADOW 3D PERSPECTIVE CAST
        if (isShadow) {
            paint.setColorFilter(new PorterDuffColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN)); paint.setAlpha(255); 
            canvas.save(); float pivotY = tT + (tH * 0.90f); canvas.translate(pX, pivotY);
            
            float sL = DataHolder.shadowLength;
            if (DataHolder.shadowDirection == 0)      { canvas.scale(1f, -0.4f * sL); }    
            else if (DataHolder.shadowDirection == 1) { canvas.skew(-0.6f, 0f); canvas.scale(1f, -0.4f * sL); } 
            else if (DataHolder.shadowDirection == 2) { canvas.skew(-1.2f, 0f); canvas.scale(1f, -0.1f * sL); } 
            else if (DataHolder.shadowDirection == 3) { canvas.skew(-0.6f, 0f); canvas.scale(1f, 0.4f * sL); }  
            else if (DataHolder.shadowDirection == 4) { canvas.scale(1f, 0.4f * sL); }     
            else if (DataHolder.shadowDirection == 5) { canvas.skew(0.6f, 0f); canvas.scale(1f, 0.4f * sL); }   
            else if (DataHolder.shadowDirection == 6) { canvas.skew(1.2f, 0f); canvas.scale(1f, -0.1f * sL); }  
            else if (DataHolder.shadowDirection == 7) { canvas.skew(0.6f, 0f); canvas.scale(1f, -0.4f * sL); }  
            
            String shadowKey = DataHolder.sceneCharacters.indexOf(sc) + "_13";
            float[] shadowPersp = DataHolder.partPerspectives.get(shadowKey);
            if (shadowPersp == null) { float sw = tW * 1.5f; float sh = tH * 1.5f; shadowPersp = new float[] { -sw, -sh, sw, -sh, sw, sh, -sw, sh }; DataHolder.partPerspectives.put(shadowKey, shadowPersp); }
            Matrix sMatrix = new Matrix(); float[] srcSp = { -fW, -fH, fW, -fH, fW, fH, -fW, fH };
            sMatrix.setPolyToPoly(srcSp, 0, shadowPersp, 0, 4); canvas.concat(sMatrix);
            
            if (!isPlaying && getSingleUnlockedPart() == 13) { Matrix saveM = new Matrix(canvas.getMatrix()); saveM.preTranslate(-pX, -pivotY); currentPartMatrices.put(13, saveM); }
            canvas.translate(-pX, -pivotY);
        } else { paint.setAlpha((alphaAmount * sc.alpha) / 255); }

        final float[][] rb = sc.relBones; final int b = p * 22;
        int pHd = advPose[0] != -1 ? advPose[0] : p; final Bitmap head = getPart(sc.parts, 0 + pHd); final float[] hNeck = getRb(rb, pHd * 22 + 1);
        int pLA = advPose[1] != -1 ? advPose[1] : (advPose[2] != -1 ? advPose[2] : p); final Bitmap lArmT = getPart(sc.parts, 15 + pLA), lArmB = getPart(sc.parts, 25 + pLA); final float[] lSh = getRb(rb, pLA * 22 + 7), lE1 = getRb(rb, pLA * 22 + 8), lE2 = getRb(rb, pLA * 22 + 9);
        int pRA = advPose[3] != -1 ? advPose[3] : (advPose[4] != -1 ? advPose[4] : p); final Bitmap rArmT = getPart(sc.parts, 10 + pRA), rArmB = getPart(sc.parts, 20 + pRA); final float[] rSh = getRb(rb, pRA * 22 + 3), rE1 = getRb(rb, pRA * 22 + 4), rE2 = getRb(rb, pRA * 22 + 5);
        int pLL = advPose[5] != -1 ? advPose[5] : (advPose[6] != -1 ? advPose[6] : (advPose[7] != -1 ? advPose[7] : p)); final Bitmap lLegT = getPart(sc.parts, 35 + pLL), lLegB = getPart(sc.parts, 45 + pLL), lPalm = getPart(sc.parts, 55 + pLL); final float[] lHip = getRb(rb, pLL * 22 + 17), lK1 = getRb(rb, pLL * 22 + 18), lK2 = getRb(rb, pLL * 22 + 19), lFt = getRb(rb, pLL * 22 + 20), lFj = getRb(rb, pLL * 22 + 21);
        int pRL = advPose[8] != -1 ? advPose[8] : (advPose[9] != -1 ? advPose[9] : (advPose[10] != -1 ? advPose[10] : p)); final Bitmap rLegT = getPart(sc.parts, 30 + pRL), rLegB = getPart(sc.parts, 40 + pRL), rPalm = getPart(sc.parts, 50 + pRL); final float[] rHip = getRb(rb, pRL * 22 + 11), rK1 = getRb(rb, pRL * 22 + 12), rK2 = getRb(rb, pRL * 22 + 13), rFt = getRb(rb, pRL * 22 + 14), rFj = getRb(rb, pRL * 22 + 15);

        int zT=40, zH=60, zRA=50, zLA=10, zRL=30, zLL=20;
        if(sc.currentPose == 4 || sc.currentPose == 5) { zRA=10; zRL=20; zLA=30; zLL=40; zT=50; zH=60; } else if (sc.currentPose == 2) { zRA=50; zRL=30; zT=20; zLA=10; zH=60; zLL=40; }

        zH += advZIndex[0]; zLA += advZIndex[1] + advZIndex[2]; zRA += advZIndex[3] + advZIndex[4]; zLL += advZIndex[5] + advZIndex[6]; zRL += advZIndex[8] + advZIndex[9]; zT += advZIndex[11];
        final float[] f_rb0 = getRb(rb, b+0), f_rb2 = getRb(rb, b+2), f_rb6 = getRb(rb, b+6), f_rb10 = getRb(rb, b+10), f_rb16 = getRb(rb, b+16);

        ArrayList<DrawAction> draws = new ArrayList<>();
        draws.add(new DrawAction(zH, new Runnable() { public void run() { drawHead(canvas, tL, tT, tW, tH, f_rb0, head, hNeck, sc.headRot, advScale[0], 0, isShadow); } }));
        draws.add(new DrawAction(zT, new Runnable() { public void run() { canvas.save(); canvas.translate(tL, tT); drawAdvancedPart(canvas, torso, 11, isShadow); canvas.restore(); } }));
        draws.add(new DrawAction(zLA, new Runnable() { public void run() { drawArm(canvas, tL, tT, tW, tH, f_rb6, lArmT, lArmB, lSh, lE1, lE2, sc.hl1Rot, sc.hl2Rot, advScale[1], advScale[2], 1, 2, isShadow); } }));
        draws.add(new DrawAction(zRA, new Runnable() { public void run() { drawArm(canvas, tL, tT, tW, tH, f_rb2, rArmT, rArmB, rSh, rE1, rE2, sc.hr1Rot, sc.hr2Rot, advScale[3], advScale[4], 3, 4, isShadow); } }));
        draws.add(new DrawAction(zLL, new Runnable() { public void run() { drawLeg(canvas, tL, tT, tW, tH, f_rb16, lLegT, lLegB, lPalm, lHip, lK1, lK2, lFt, lFj, sc.ll1Rot, sc.ll2Rot, sc.f1Rot, advScale[5], advScale[6], advScale[7], 5, 6, 7, isShadow); } }));
        draws.add(new DrawAction(zRL, new Runnable() { public void run() { drawLeg(canvas, tL, tT, tW, tH, f_rb10, rLegT, rLegB, rPalm, rHip, rK1, rK2, rFt, rFj, sc.lr1Rot, sc.lr2Rot, sc.f2Rot, advScale[8], advScale[9], advScale[10], 8, 9, 10, isShadow); } }));

        Collections.sort(draws); for(DrawAction d : draws) { d.action.run(); }
        if (isShadow) { canvas.restore(); paint.setColorFilter(null); paint.setAlpha(255); } else if (alphaAmount != 255 || sc.alpha != 255) { paint.setAlpha(255); }
        canvas.restore(); 
    }

    private void drawHead(Canvas c, float tL, float tT, float tW, float tH, float[] tNeck, Bitmap head, float[] hNeck, float rot, float scale, int uId, boolean isShadow) {
        if (head == null || tNeck == null || hNeck == null) return; c.save(); c.translate(tL + (tW * tNeck[0]), tT + (tH * tNeck[1])); c.rotate(rot); c.scale(scale, scale); c.translate(-(head.getWidth() * hNeck[0]), -(head.getHeight() * hNeck[1])); drawAdvancedPart(c, head, uId, isShadow); c.restore();
    }
    private void drawArm(Canvas c, float tL, float tT, float tW, float tH, float[] torsoSh, Bitmap p1, Bitmap p2, float[] pSh, float[] pE1, float[] pE2, float rot1, float rot2, float scale1, float scale2, int uId1, int uId2, boolean isShadow) {
        if (p1 == null || torsoSh == null || pSh == null) return; c.save(); c.translate(tL + (tW * torsoSh[0]), tT + (tH * torsoSh[1])); c.rotate(rot1); c.scale(scale1, scale1); 
        if (p2 != null && pE1 != null && pE2 != null) { c.save(); c.translate(p1.getWidth() * (pE1[0] - pSh[0]), p1.getHeight() * (pE1[1] - pSh[1])); c.rotate(rot2); c.scale(scale2 / scale1, scale2 / scale1); c.translate(-(p2.getWidth() * pE2[0]), -(p2.getHeight() * pE2[1])); drawAdvancedPart(c, p2, uId2, isShadow); c.restore(); } 
        c.translate(-(p1.getWidth() * pSh[0]), -(p1.getHeight() * pSh[1])); drawAdvancedPart(c, p1, uId1, isShadow); c.restore();
    }
    private void drawLeg(Canvas c, float tL, float tT, float tW, float tH, float[] torsoHip, Bitmap p1, Bitmap p2, Bitmap f, float[] pHip, float[] pK1, float[] pK2, float[] pFoot, float[] fJoint, float rot1, float rot2, float rotF, float scale1, float scale2, float scale3, int uId1, int uId2, int uId3, boolean isShadow) {
        if (p1 == null || torsoHip == null || pHip == null) return; c.save(); c.translate(tL + (tW * torsoHip[0]), tT + (tH * torsoHip[1])); c.rotate(rot1); c.scale(scale1, scale1); 
        if (p2 != null && pK1 != null && pK2 != null) { c.save(); c.translate(p1.getWidth() * (pK1[0] - pHip[0]), p1.getHeight() * (pK1[1] - pHip[1])); c.rotate(rot2); c.scale(scale2 / scale1, scale2 / scale1); 
            if (f != null && pFoot != null && fJoint != null) { c.save(); c.translate(p2.getWidth() * (pFoot[0] - pK2[0]), p2.getHeight() * (pFoot[1] - pK2[1])); c.rotate(rotF); c.scale(scale3 / scale2, scale3 / scale2); c.translate(-(f.getWidth() * fJoint[0]), -(f.getHeight() * fJoint[1])); drawAdvancedPart(c, f, uId3, isShadow); c.restore(); } 
            c.translate(-(p2.getWidth() * pK2[0]), -(p2.getHeight() * pK2[1])); drawAdvancedPart(c, p2, uId2, isShadow); c.restore(); } 
        c.translate(-(p1.getWidth() * pHip[0]), -(p1.getHeight() * pHip[1])); drawAdvancedPart(c, p1, uId1, isShadow); c.restore();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (isPlaying) return true; scaleDetector.onTouchEvent(event); if (event.getPointerCount() > 1) return true;
        float tx = event.getX(), ty = event.getY(); SceneCharacter sc = DataHolder.getActiveChar();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: prevX = tx; prevY = ty; 
                if (currentMode == MODE_MESH || currentMode == MODE_PERSPECTIVE) {
                    int uId = getSingleUnlockedPart();
                    if (uId != -1 && currentPartMatrices.containsKey(uId)) {
                        String key = DataHolder.activeCharIndex + "_" + uId; 
                        float[] ptsData = currentMode == MODE_MESH ? DataHolder.partMeshes.get(key) : DataHolder.partPerspectives.get(key);
                        if (ptsData != null) { 
                            Matrix m = currentPartMatrices.get(uId); 
                            float[] localPts = new float[18];
                            localPts[0] = ptsData[0]; localPts[1] = ptsData[1]; localPts[2] = ptsData[2]; localPts[3] = ptsData[3];
                            localPts[4] = ptsData[4]; localPts[5] = ptsData[5]; localPts[6] = ptsData[6]; localPts[7] = ptsData[7];
                            localPts[8] = (ptsData[0]+ptsData[2])/2f; localPts[9] = (ptsData[1]+ptsData[3])/2f; 
                            localPts[10] = (ptsData[2]+ptsData[4])/2f; localPts[11] = (ptsData[3]+ptsData[5])/2f;
                            localPts[12] = (ptsData[4]+ptsData[6])/2f; localPts[13] = (ptsData[5]+ptsData[7])/2f;
                            localPts[14] = (ptsData[6]+ptsData[0])/2f; localPts[15] = (ptsData[7]+ptsData[1])/2f;
                            localPts[16] = (ptsData[0]+ptsData[2]+ptsData[4]+ptsData[6])/4f; localPts[17] = (ptsData[1]+ptsData[3]+ptsData[5]+ptsData[7])/4f;
                            float[] screenPts = localPts.clone(); m.mapPoints(screenPts); activeMeshPoint = -1; float minDist = 80f; 
                            for (int i=0; i<9; i++) { float dx = screenPts[i*2] - tx; float dy = screenPts[i*2+1] - ty; float dist = (float)Math.sqrt(dx*dx + dy*dy); if (dist < minDist) { minDist = dist; activeMeshPoint = i; } }
                            if (activeMeshPoint != -1) { invalidate(); return true; }
                        }
                    }
                } break;
                
            case MotionEvent.ACTION_MOVE:
                if ((currentMode == MODE_MESH || currentMode == MODE_PERSPECTIVE) && activeMeshPoint != -1) {
                    int uId = getSingleUnlockedPart();
                    if (uId != -1 && currentPartMatrices.containsKey(uId)) {
                        String key = DataHolder.activeCharIndex + "_" + uId; 
                        float[] ptsData = currentMode == MODE_MESH ? DataHolder.partMeshes.get(key) : DataHolder.partPerspectives.get(key);
                        if (ptsData != null) { 
                            Matrix inv = new Matrix(); currentPartMatrices.get(uId).invert(inv); 
                            float[] pts = {tx, ty}; inv.mapPoints(pts); float[] prevPts = {prevX, prevY}; inv.mapPoints(prevPts);
                            float ldx = pts[0] - prevPts[0]; float ldy = pts[1] - prevPts[1];
                            
                            if (currentMode == MODE_PERSPECTIVE) {
                                if(activeMeshPoint == 0) { ptsData[0]+=ldx; ptsData[1]+=ldy; } else if(activeMeshPoint == 1) { ptsData[2]+=ldx; ptsData[3]+=ldy; } else if(activeMeshPoint == 2) { ptsData[4]+=ldx; ptsData[5]+=ldy; } else if(activeMeshPoint == 3) { ptsData[6]+=ldx; ptsData[7]+=ldy; } else if(activeMeshPoint == 4) { ptsData[1]+=ldy; ptsData[3]+=ldy; } else if(activeMeshPoint == 5) { ptsData[2]+=ldx; ptsData[4]+=ldx; } else if(activeMeshPoint == 6) { ptsData[5]+=ldy; ptsData[7]+=ldy; } else if(activeMeshPoint == 7) { ptsData[0]+=ldx; ptsData[6]+=ldx; } else if(activeMeshPoint == 8) { float cxL = (ptsData[0]+ptsData[2]+ptsData[4]+ptsData[6])/4f; float cyL = (ptsData[1]+ptsData[3]+ptsData[5]+ptsData[7])/4f; float sM = 1.0f + (ldx - ldy) * 0.005f; for(int i=0; i<4; i++) { ptsData[i*2] = cxL + (ptsData[i*2] - cxL)*sM; ptsData[i*2+1] = cyL + (ptsData[i*2+1] - cyL)*sM; } }
                            } else {
                                ptsData[activeMeshPoint] = pts[0]; ptsData[activeMeshPoint+1] = pts[1];
                            }
                            invalidate(); prevX = tx; prevY = ty; return true; 
                        }
                    }
                }
                float adjustedDiffX = (tx - prevX) / scaleFactor; float adjustedDiffY = (ty - prevY) / scaleFactor;
                if (currentMode == MODE_BG) { bgX += adjustedDiffX; bgY += adjustedDiffY; invalidate(); } 
                else if (currentMode == MODE_CHAR && sc != null) { sc.globalX += adjustedDiffX; sc.globalY += adjustedDiffY; invalidate(); } 
                else if (currentMode == MODE_BONE && sc != null) {
                    boolean allLocked = true; for (boolean unlocked : unlockedParts) { if (unlocked) { allLocked = false; break; } }
                    if (allLocked) { sc.globalX += adjustedDiffX; sc.globalY += adjustedDiffY; } 
                    else {
                        float diffAngle = (tx - prevX + ty - prevY) * 0.3f; if (sc.flipX) diffAngle = -diffAngle;
                        if (unlockedParts[0]) sc.headRot += diffAngle; if (unlockedParts[1]) sc.hl1Rot += diffAngle; if (unlockedParts[2]) sc.hl2Rot += diffAngle; if (unlockedParts[3]) sc.hr1Rot += diffAngle; if (unlockedParts[4]) sc.hr2Rot += diffAngle; if (unlockedParts[5]) sc.ll1Rot += diffAngle; if (unlockedParts[6]) sc.ll2Rot += diffAngle; if (unlockedParts[7]) sc.f1Rot += diffAngle; if (unlockedParts[8]) sc.lr1Rot += diffAngle; if (unlockedParts[9]) sc.lr2Rot += diffAngle; if (unlockedParts[10]) sc.f2Rot += diffAngle;
                    } invalidate();
                } prevX = tx; prevY = ty; break;
            case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL:
                if (currentMode == MODE_MESH || currentMode == MODE_PERSPECTIVE) { activeMeshPoint = -1; invalidate(); } break;
        } return true;
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override public boolean onScale(ScaleGestureDetector detector) {
            if(currentMode == MODE_BG) { bgScale *= detector.getScaleFactor(); bgScale = Math.max(0.01f, Math.min(bgScale, 100.0f)); } 
            else if (currentMode == MODE_CHAR && DataHolder.getActiveChar() != null) { DataHolder.getActiveChar().globalScale *= detector.getScaleFactor(); DataHolder.getActiveChar().globalScale = Math.max(0.1f, Math.min(DataHolder.getActiveChar().globalScale, 10.0f)); }
            else { scaleFactor *= detector.getScaleFactor(); scaleFactor = Math.max(0.01f, Math.min(scaleFactor, 100.0f)); }
            invalidate(); return true;
        }
    }
}
