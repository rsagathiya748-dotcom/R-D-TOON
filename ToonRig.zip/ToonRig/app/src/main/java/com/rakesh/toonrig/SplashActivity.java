package com.rakesh.toonrig;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class SplashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Background Color (Dark Navy Blue)
        LinearLayout root = new LinearLayout(this);
        root.setBackgroundColor(Color.parseColor("#0B132B")); 
        root.setGravity(Gravity.CENTER);

        // Aapka Bada Wala Logo (splash_logo.png)
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.splash_logo);
        
        // Logo ka size (agar zyada bada ya chhota lage toh 800 ko badal lena)
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(800, 800);
        logo.setLayoutParams(lp);

        root.addView(logo);
        setContentView(root);

        // 3 Second (3000 ms) ke baad automatically HomeActivity par le jayega
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(SplashActivity.this, HomeActivity.class));
                finish(); // Splash screen ko background se hata dega
            }
        }, 3000);
    }
}
