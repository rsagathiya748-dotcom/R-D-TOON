package com.rakesh.toonrig;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CategoryActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // DARK STUDIO BACKGROUND
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL); // Side by Side Layout
        root.setBackgroundColor(Color.parseColor("#1C1E26"));
        root.setWeightSum(3);

        // LEFT SIDE: TITLE SECTION
        LinearLayout leftPanel = new LinearLayout(this);
        leftPanel.setOrientation(LinearLayout.VERTICAL);
        leftPanel.setGravity(Gravity.CENTER);
        leftPanel.setPadding(50, 50, 50, 50);
        LinearLayout.LayoutParams lpLeft = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1);
        leftPanel.setLayoutParams(lpLeft);

        TextView tvCatTitle = new TextView(this);
        tvCatTitle.setText("SELECT\nYOUR\nRIG");
        tvCatTitle.setTextColor(Color.WHITE);
        tvCatTitle.setTextSize(35);
        tvCatTitle.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        
        TextView tvCatSub = new TextView(this);
        tvCatSub.setText("Choose a category to start your project.");
        tvCatSub.setTextColor(Color.parseColor("#90A4AE"));
        tvCatSub.setTextSize(16);
        tvCatSub.setPadding(0, 20, 0, 0);

        leftPanel.addView(tvCatTitle);
        leftPanel.addView(tvCatSub);
        root.addView(leftPanel);

        // RIGHT SIDE: BIG BUTTON CARDS
        LinearLayout rightPanel = new LinearLayout(this);
        rightPanel.setOrientation(LinearLayout.VERTICAL);
        rightPanel.setGravity(Gravity.CENTER);
        rightPanel.setPadding(40, 20, 40, 20);
        LinearLayout.LayoutParams lpRight = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 2);
        rightPanel.setLayoutParams(lpRight);

        // BIG BUTTONS
        Button btnHuman = createBigCardButton("🧍  HUMAN RIGS", "#2962FF"); // Blue
        Button btnAnimal = createBigCardButton("🐕  ANIMAL RIGS", "#00C853"); // Green
        Button btnBird = createBigCardButton("🦅  BIRD RIGS", "#FF6D00"); // Orange

        btnHuman.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(CategoryActivity.this, ProjectActivity.class));
            }
        });

        rightPanel.addView(btnHuman);
        rightPanel.addView(btnAnimal);
        rightPanel.addView(btnBird);
        root.addView(rightPanel);

        setContentView(root);
    }

    private Button createBigCardButton(String text, String colorHex) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor(colorHex));
        b.setTextSize(18);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        b.setPadding(60, 40, 40, 40); // Padding inside button
        
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(20, 15, 20, 15); // Gap between buttons
        b.setLayoutParams(lp);
        
        return b;
    }
}
