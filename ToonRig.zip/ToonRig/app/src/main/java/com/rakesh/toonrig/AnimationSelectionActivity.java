package com.rakesh.toonrig;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;

public class AnimationSelectionActivity extends Activity {
    private Button btnAnimBack, btnAnimPose, btnCharSwitch, btnDirectorMode;
    private ListView listAnimations;
    private TextView tvStatus;
    private LinearLayout appliedAnimContainer;
    private PreviewView miniPreview;

    private int currentCharIndex = 0;
    private ArrayList<String> savedAnimations;
    
    // YAHAN STEP 2 WALA CHANGE HAI: Ise public static kar diya gaya hai
    public static HashMap<Integer, ArrayList<String>> charAnimChains = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            setContentView(R.layout.activity_animation_selection);

            btnAnimBack = findViewById(R.id.btnAnimBack);
            btnAnimPose = findViewById(R.id.btnAnimPose);
            btnCharSwitch = findViewById(R.id.btnCharSwitch);
            btnDirectorMode = findViewById(R.id.btnDirectorMode);
            listAnimations = findViewById(R.id.listAnimations);
            tvStatus = findViewById(R.id.tvStatus);
            appliedAnimContainer = findViewById(R.id.appliedAnimContainer);
            miniPreview = findViewById(R.id.miniPreview);

            if (DataHolder.sceneCharacters == null) {
                DataHolder.sceneCharacters = new ArrayList<>();
            }

            int charCount = DataHolder.sceneCharacters.size();
            if (charCount == 0) charCount = 1; 

            // Sabhi characters ke liye empty list bana lo (agar pehle se nahi hai)
            if (charAnimChains == null) charAnimChains = new HashMap<>();
            for (int i = 0; i < charCount; i++) {
                if (!charAnimChains.containsKey(i)) {
                    charAnimChains.put(i, new ArrayList<String>());
                }
            }

            updateUI();
            refreshAppliedList();

            // Load Real JSON Animations
            savedAnimations = AnimationStorage.getSavedAnimationNames(this);
            if (savedAnimations == null || savedAnimations.isEmpty()) {
                savedAnimations = new ArrayList<>();
                savedAnimations.add("No Animations Found!");
            }

            listAnimations.setAdapter(new AnimAdapter());

            btnAnimBack.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { finish(); }
            });

            btnAnimPose.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    String[] poses = {"Pose 1 (Front)", "Pose 2", "Pose 3 (Side)", "Pose 4", "Pose 5 (Back)"};
                    new AlertDialog.Builder(AnimationSelectionActivity.this).setTitle("Select Pose").setItems(poses, new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface dialog, int which) { 
                            if (miniPreview != null) miniPreview.changePose(which + 1); 
                        }
                    }).show();
                }
            });

            btnCharSwitch.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    currentCharIndex++;
                    if (currentCharIndex >= DataHolder.sceneCharacters.size()) {
                        currentCharIndex = 0; 
                    }
                    DataHolder.activeCharIndex = currentCharIndex; 
                    updateUI();
                    refreshAppliedList();
                }
            });

            // ADD ANIMATION TO CHAIN
            listAnimations.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (savedAnimations.get(position).contains("No Animations")) return;
                    
                    charAnimChains.get(currentCharIndex).add(savedAnimations.get(position));
                    
                    updateUI();
                    refreshAppliedList(); 
                }
            });

            // SCREEN 4 PAR JANE KA INTENT
            btnDirectorMode.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isAllAnimated()) {
                        startActivity(new Intent(AnimationSelectionActivity.this, DirectorModeActivity.class));
                    } else {
                        Toast.makeText(AnimationSelectionActivity.this, "LOCKED! Sabhi characters ko kam se kam 1 animation do!", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        } catch (Throwable t) {
            Toast.makeText(this, "Crash Prevented: " + t.toString(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void updateUI() {
        int total = DataHolder.sceneCharacters.size();
        if (total == 0) total = 1;
        
        int animatedCount = 0;
        for (int i = 0; i < total; i++) {
            if (charAnimChains.containsKey(i) && charAnimChains.get(i).size() > 0) {
                animatedCount++;
            }
        }

        btnCharSwitch.setText("CHAR: " + (currentCharIndex + 1));
        tvStatus.setText(animatedCount + "/" + total + " Characters Animated");

        if (animatedCount >= total) {
            tvStatus.setTextColor(Color.WHITE); 
            tvStatus.setBackgroundColor(Color.parseColor("#4CAF50")); 
            btnDirectorMode.setText("PREVIEW (READY)");
            btnDirectorMode.setTextColor(Color.WHITE);
            btnDirectorMode.setBackgroundColor(Color.parseColor("#B77D43")); 
        } else {
            tvStatus.setTextColor(Color.WHITE); 
            tvStatus.setBackgroundColor(Color.parseColor("#D32F2F")); 
            btnDirectorMode.setText("PREVIEW (LOCKED)");
            btnDirectorMode.setTextColor(Color.parseColor("#888888"));
            btnDirectorMode.setBackgroundColor(Color.parseColor("#333333")); 
        }
        
        if(miniPreview != null) miniPreview.invalidate();
    }

    private boolean isAllAnimated() {
        int total = DataHolder.sceneCharacters.size();
        if (total == 0) return false;
        for (int i = 0; i < total; i++) {
            if (!charAnimChains.containsKey(i) || charAnimChains.get(i).isEmpty()) {
                return false; 
            }
        }
        return true;
    }

    // ========================================================
    // ADVANCED DRAG & DROP (CRASH SAFE)
    // ========================================================
    private void refreshAppliedList() {
        appliedAnimContainer.removeAllViews();
        final ArrayList<String> currentChain = charAnimChains.get(currentCharIndex);
        
        if (currentChain == null || currentChain.isEmpty()) {
            TextView emptyTv = new TextView(this);
            emptyTv.setText("Chain is empty.\nClick animations from left to add.");
            emptyTv.setTextColor(Color.GRAY);
            emptyTv.setGravity(Gravity.CENTER);
            emptyTv.setPadding(0, 50, 0, 0);
            appliedAnimContainer.addView(emptyTv);
            return;
        }

        for (int i = 0; i < currentChain.size(); i++) {
            final String animName = currentChain.get(i);
            final LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(10, 15, 10, 15);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackgroundColor(Color.parseColor("#F5F5F5"));
            
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rowParams.setMargins(0, 0, 0, 10);
            row.setLayoutParams(rowParams);

            TextView tvName = new TextView(this);
            tvName.setText((i + 1) + ". " + animName);
            tvName.setTextColor(Color.BLACK);
            tvName.setTextSize(16);
            tvName.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            row.addView(tvName);

            // DRAG HANDLE
            TextView dragHandle = new TextView(this);
            dragHandle.setText(" ☰ "); 
            dragHandle.setTextColor(Color.GRAY);
            dragHandle.setTextSize(26);
            dragHandle.setPadding(20, 0, 20, 0);
            
            dragHandle.setOnTouchListener(new View.OnTouchListener() {
                float startY;
                int originalIndex;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    ViewGroup scrollView = (ViewGroup) appliedAnimContainer.getParent();
                    
                    try {
                        switch (event.getAction()) {
                            case MotionEvent.ACTION_DOWN:
                                if (scrollView != null) scrollView.requestDisallowInterceptTouchEvent(true);
                                row.setBackgroundColor(Color.parseColor("#E0E0E0")); 
                                row.setAlpha(0.7f); 
                                startY = event.getRawY();
                                originalIndex = currentChain.indexOf(animName);
                                return true;
                            
                            case MotionEvent.ACTION_MOVE:
                                float diff = event.getRawY() - startY;
                                row.setTranslationY(diff); 
                                return true;
                            
                            case MotionEvent.ACTION_UP:
                            case MotionEvent.ACTION_CANCEL:
                                row.setAlpha(1.0f);
                                row.setBackgroundColor(Color.parseColor("#F5F5F5"));
                                row.setTranslationY(0f); 
                                
                                float dropY = event.getRawY() - startY;
                                int rowHeight = row.getHeight() == 0 ? 120 : row.getHeight();
                                int steps = Math.round(dropY / rowHeight); 
                                
                                final int newIndex = originalIndex + steps;

                                // POST (DELAY) WALA SAFE LOGIC
                                appliedAnimContainer.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            int targetIndex = newIndex;
                                            if (targetIndex < 0) targetIndex = 0;
                                            if (targetIndex >= currentChain.size()) targetIndex = currentChain.size() - 1;

                                            if (targetIndex != originalIndex && originalIndex >= 0 && originalIndex < currentChain.size()) {
                                                String movedItem = currentChain.remove(originalIndex);
                                                if (targetIndex > currentChain.size()) targetIndex = currentChain.size();
                                                currentChain.add(targetIndex, movedItem);
                                                refreshAppliedList(); 
                                            }
                                        } catch (Exception e) {}
                                    }
                                });
                                
                                if (scrollView != null) scrollView.requestDisallowInterceptTouchEvent(false);
                                return true;
                        }
                    } catch (Exception e) {}
                    return false;
                }
            });
            row.addView(dragHandle);

            // DELETE BUTTON
            Button btnDel = new Button(this);
            btnDel.setText("X"); 
            btnDel.setTextColor(Color.WHITE);
            btnDel.setBackgroundColor(Color.parseColor("#F44336")); 
            btnDel.setTextSize(12);
            btnDel.setPadding(0,0,0,0);
            LinearLayout.LayoutParams lpDel = new LinearLayout.LayoutParams(90, 90);
            lpDel.setMargins(10, 0, 0, 0);
            btnDel.setLayoutParams(lpDel);
            
            btnDel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    appliedAnimContainer.post(new Runnable() {
                        @Override
                        public void run() {
                            currentChain.remove(animName); 
                            refreshAppliedList(); 
                            updateUI(); 
                        }
                    });
                }
            });
            row.addView(btnDel);

            appliedAnimContainer.addView(row);
        }
    }

    class AnimAdapter extends BaseAdapter {
        @Override public int getCount() { return savedAnimations.size(); }
        @Override public Object getItem(int position) { return savedAnimations.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView tv = new TextView(AnimationSelectionActivity.this);
            tv.setText(savedAnimations.get(position));
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(16f);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(20, 30, 20, 30);
            tv.setBackgroundColor(Color.parseColor("#268F8E"));
            return tv;
        }
    }
}
