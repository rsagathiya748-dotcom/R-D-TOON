package com.rakesh.toonrig;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class RecordService extends Service {
    private MediaProjection mMediaProjection;
    private VirtualDisplay mVirtualDisplay;
    private MediaRecorder mMediaRecorder;
    private File tempFile;
    private int selectedQuality = 1; // Default SD (720p)

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("RecChannel", "Recording", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(channel);

            Notification notification = new Notification.Builder(this, "RecChannel")
                    .setContentTitle("ToonRig Recording")
                    .setContentText("Saving high quality video...")
                    .setSmallIcon(android.R.drawable.ic_media_play)
                    .build();
            
            if (Build.VERSION.SDK_INT >= 29) { 
                startForeground(1, notification, 32); 
            } else {
                startForeground(1, notification);
            }
        }

        int resultCode = intent.getIntExtra("code", 0);
        Intent resultData = intent.getParcelableExtra("data");
        
        // HubActivity/DirectorMode se aayi hui choice read karenge
        selectedQuality = intent.getIntExtra("quality_index", 1);

        if (resultCode != android.app.Activity.RESULT_OK || resultData == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        mMediaProjection = mpm.getMediaProjection(resultCode, resultData);

        initRecorder();
        return START_STICKY;
    }

    private void initRecorder() {
        try {
            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics metrics = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(metrics); // getRealMetrics se asli bina kati hui screen size milegi
            
            // SUPER FIX: Service ko lagta hai phone Portrait me hai, par app Landscape me hai!
            // Isliye hum zabardasti Width ko bada aur Height ko chhota set karenge.
            int realWidth = Math.max(metrics.widthPixels, metrics.heightPixels);
            int realHeight = Math.min(metrics.widthPixels, metrics.heightPixels);
            
            float ratio = (float) realWidth / realHeight;
            
            int finalW = realWidth;
            int finalH = realHeight;
            int finalBitRate = 4000000; 

            // User ki choice ke hisaab se resolution aur paki High Quality (Bitrate) set
            if (selectedQuality == 0) {
                // Low (480p)
                finalH = 480; 
                finalW = (int) (finalH * ratio);
                finalBitRate = 1500000; // 1.5 Mbps
            } else if (selectedQuality == 1) {
                // SD (720p)
                finalH = 720; 
                finalW = (int) (finalH * ratio);
                finalBitRate = 4000000; // 4 Mbps (Crisp SD)
            } else if (selectedQuality == 2) {
                // HD (1080p)
                finalH = 1080; 
                finalW = (int) (finalH * ratio);
                finalBitRate = 8000000; // 8 Mbps (Real Full HD Quality)
            }

            // Android Hardware encoder multiple of 16 mangta hai crash rokne ke liye
            finalW = (finalW / 16) * 16;
            finalH = (finalH / 16) * 16;

            tempFile = new File(getCacheDir(), "toonrig_temp.mp4");

            mMediaRecorder = new MediaRecorder();
            mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mMediaRecorder.setOutputFile(tempFile.getAbsolutePath());
            
            mMediaRecorder.setVideoSize(finalW, finalH);
            mMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            mMediaRecorder.setVideoEncodingBitRate(finalBitRate); 
            mMediaRecorder.setVideoFrameRate(60); // SMOOTH 60 FPS ANIMATION!
            mMediaRecorder.prepare();

            mVirtualDisplay = mMediaProjection.createVirtualDisplay("ScreenRecord",
                    finalW, finalH, metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    mMediaRecorder.getSurface(), null, null);

            mMediaRecorder.start();

        } catch (final Exception e) {
            showToast("Recorder Error: " + e.getMessage());
            stopSelf();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            if (mMediaRecorder != null) {
                mMediaRecorder.stop();
                mMediaRecorder.reset();
                mMediaRecorder.release();
            }
        } catch (Exception e) {}

        if (mVirtualDisplay != null) mVirtualDisplay.release();
        if (mMediaProjection != null) mMediaProjection.stop();

        if (tempFile != null && tempFile.exists() && tempFile.length() > 0) {
            saveToPublicGallery();
        }
    }

    private void saveToPublicGallery() {
        try {
            String qName = "720p";
            if(selectedQuality == 0) qName = "480p";
            if(selectedQuality == 2) qName = "1080p";
            
            String fileName = "ToonRig_" + qName + "_" + System.currentTimeMillis() + ".mp4";
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
                values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ToonRig");

                Uri videoUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
                if (videoUri != null) {
                    OutputStream out = resolver.openOutputStream(videoUri);
                    FileInputStream in = new FileInputStream(tempFile);
                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    while ((bytesRead = in.read(buffer)) > 0) { out.write(buffer, 0, bytesRead); }
                    in.close(); out.close();
                    showToast("✅ SUCCESS! Video Saved: " + qName);
                }
            } else {
                File moviesDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "ToonRig");
                if (!moviesDir.exists()) moviesDir.mkdirs();
                File finalFile = new File(moviesDir, fileName);

                FileOutputStream out = new FileOutputStream(finalFile);
                FileInputStream in = new FileInputStream(tempFile);
                byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = in.read(buffer)) > 0) { out.write(buffer, 0, bytesRead); }
                in.close(); out.close();

                MediaScannerConnection.scanFile(this, new String[]{finalFile.getAbsolutePath()}, new String[]{"video/mp4"}, null);
                showToast("✅ SUCCESS! Video Saved: " + qName);
            }
            tempFile.delete();

        } catch (final Exception e) {
            e.printStackTrace();
            showToast("❌ Save Error: " + e.getMessage());
        }
    }

    private void showToast(final String msg) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override public void run() {
                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
