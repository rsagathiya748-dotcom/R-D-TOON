package com.rakesh.toonrig;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;

public class PreviewActivity extends Activity {
    private PreviewView previewView;
    private Button btnTools, btnImportBG, btnMode, btnPlay, btnAddKey;
    private Button btnPrevPage, btnNextPage;
    
    private SeekBar timelineSeekBar;
    private TextView tvCurrentFrame, tvAnimName;
    private FrameLayout dotsContainer, rulerContainer;

    private LinearLayout lockButtonsContainer;
    private int currentInteractionViewMode = PreviewView.MODE_BONE;
    private int currentTimelinePage = 0; 
    private final int FRAMES_PER_PAGE = 50;
    
    private HorizontalScrollView advancedToolsBarWrapper;
    private TextView tvAdvTitle, tvAdvScale, tvAdvZ, tvAdvPose;
    private Button btnAdvScaleMinus, btnAdvScalePlus, btnAdvZMinus, btnAdvZPlus, btnAdvPoseMinus, btnAdvPosePlus, btnAdvReset, btnAdvClose;
    private int activeAdvTargetIndex = -1;
    
    private ArrayList<PreviewView.KeyFrame> clipboardBlock = new ArrayList<>();

    // 18 MENU OPTIONS
    private String[] toolsMenuOptions = {
        "Select Pose", "Flip Left/Right ↔️", "Flip Up/Down ↕️", 
        "Remove Current Key 🗑", "Save Animation 💾", "🛠️ Advanced Part Adjust", 
        "👤 Toggle Shadow (On/Off)", "🔄 Shadow Pose (1-8)", "📏 Shadow Size (Length)", 
        "📑 Copy Current Pose (Single)", "✂️ Copy Multiple Frames (Block)", "📋 Paste Frame(s)",
        "👻 Toggle Onion Skin (On/Off)", "🕸️ Reset Mesh & Perspective", "⏱️ Change Anim Speed (FPS)",
        "🌫️ Character Opacity (Fade)", "🌊 Motion Easing (Current Frame)", "🌊 Motion Easing (ALL Frames)"
    };
    
    // 14 LOCK PANEL ITEMS
    private String[] lockNames = {"Head", "L-Arm Top", "L-Elbow", "R-Arm Top", "R-Elbow", "L-Leg Top", "L-Knee", "L-Foot", "R-Leg Top", "R-Knee", "R-Foot", "Torso (Body)", "Full Character", "Shadow (3D Cast)"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);
        
        previewView = findViewById(R.id.previewView);
        tvAnimName = findViewById(R.id.tvAnimName);
        lockButtonsContainer = findViewById(R.id.lockButtonsContainer);
        
        showCreateAnimationDialog();

        btnTools = findViewById(R.id.btnTools);
        btnImportBG = findViewById(R.id.btnImportBG);
        btnMode = findViewById(R.id.btnMode);
        btnAddKey = findViewById(R.id.btnAddKey);
        btnPlay = findViewById(R.id.btnPlay);
        
        btnPrevPage = findViewById(R.id.btnPrevPage);
        btnNextPage = findViewById(R.id.btnNextPage);
        timelineSeekBar = findViewById(R.id.timelineSeekBar);
        tvCurrentFrame = findViewById(R.id.tvCurrentFrame);
        dotsContainer = findViewById(R.id.dotsContainer);
        rulerContainer = findViewById(R.id.rulerContainer);

        timelineSeekBar.setMax(FRAMES_PER_PAGE);
        buildSideLockPanel();
        initAdvancedToolsBar();

        btnTools.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(PreviewActivity.this)
                    .setTitle("Tools & Settings")
                    .setItems(toolsMenuOptions, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (which == 0) { showPoseDialog(); } 
                            else if (which == 1) { previewView.toggleFlipX(); } 
                            else if (which == 2) { previewView.toggleFlipY(); } 
                            else if (which == 3) { 
                                int actualFrame = (currentTimelinePage * FRAMES_PER_PAGE) + timelineSeekBar.getProgress();
                                previewView.removeKeyframeAtCurrentProgress(actualFrame); updateTimelineUI(); Toast.makeText(PreviewActivity.this, "Key Removed", Toast.LENGTH_SHORT).show();
                            } 
                            else if (which == 4) { saveAnimationAndExit(); } 
                            else if (which == 5) { openAdvancedAdjustUI(); } 
                            else if (which == 6) { DataHolder.isShadowEnabled = !DataHolder.isShadowEnabled; previewView.invalidate(); Toast.makeText(PreviewActivity.this, DataHolder.isShadowEnabled ? "Shadow ON" : "Shadow OFF", Toast.LENGTH_SHORT).show(); } 
                            else if (which == 7) { 
                                if (!DataHolder.isShadowEnabled) { Toast.makeText(PreviewActivity.this, "Turn ON Shadow first!", Toast.LENGTH_SHORT).show(); return; }
                                String[] sa = {"Shadow 1", "Shadow 2", "Shadow 3", "Shadow 4", "Shadow 5", "Shadow 6", "Shadow 7", "Shadow 8"};
                                new AlertDialog.Builder(PreviewActivity.this).setTitle("Shadow Pose").setItems(sa, new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface dialog, int w) { DataHolder.shadowDirection = w; previewView.invalidate(); } }).show();
                            }
                            else if (which == 8) { 
                                if (!DataHolder.isShadowEnabled) { Toast.makeText(PreviewActivity.this, "Turn ON Shadow first!", Toast.LENGTH_SHORT).show(); return; }
                                String[] sizes = {"0.5x", "1.0x", "1.5x", "2.0x", "2.5x", "3.0x"};
                                new AlertDialog.Builder(PreviewActivity.this).setTitle("Shadow Size").setItems(sizes, new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface dialog, int w) { if(w==0) DataHolder.shadowLength=0.5f; else if(w==1) DataHolder.shadowLength=1.0f; else if(w==2) DataHolder.shadowLength=1.5f; else if(w==3) DataHolder.shadowLength=2.0f; else if(w==4) DataHolder.shadowLength=2.5f; else if(w==5) DataHolder.shadowLength=3.0f; previewView.invalidate(); } }).show();
                            }
                            else if (which == 9) { 
                                SceneCharacter sc = DataHolder.getActiveChar();
                                if (sc != null) { clipboardBlock.clear(); PreviewView.KeyFrame poseToCopy = new PreviewView.KeyFrame(0, sc.globalX, sc.globalY, sc.headRot, sc.hl1Rot, sc.hl2Rot, sc.hr1Rot, sc.hr2Rot, sc.ll1Rot, sc.ll2Rot, sc.f1Rot, sc.lr1Rot, sc.lr2Rot, sc.f2Rot); clipboardBlock.add(poseToCopy); Toast.makeText(PreviewActivity.this, "Pose Copied! 📑", Toast.LENGTH_SHORT).show(); }
                            }
                            else if (which == 10) { 
                                LinearLayout layout = new LinearLayout(PreviewActivity.this); layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(50, 20, 50, 20);
                                final EditText startInput = new EditText(PreviewActivity.this); startInput.setHint("Start Frame"); startInput.setInputType(InputType.TYPE_CLASS_NUMBER); layout.addView(startInput);
                                final EditText endInput = new EditText(PreviewActivity.this); endInput.setHint("End Frame"); endInput.setInputType(InputType.TYPE_CLASS_NUMBER); layout.addView(endInput);
                                new AlertDialog.Builder(PreviewActivity.this).setTitle("Copy Multiple Frames").setView(layout).setPositiveButton("Copy", new DialogInterface.OnClickListener() {
                                        @Override public void onClick(DialogInterface dialog, int w) {
                                            try { int startF = Integer.parseInt(startInput.getText().toString()); int endF = Integer.parseInt(endInput.getText().toString());
                                                SceneCharacter sc = DataHolder.getActiveChar();
                                                if (sc != null && sc.animationTimelines.containsKey(sc.currentPose)) {
                                                    clipboardBlock.clear(); HashMap<Integer, PreviewView.KeyFrame> tl = sc.animationTimelines.get(sc.currentPose); int count = 0;
                                                    for (Integer fNum : tl.keySet()) { if (fNum >= startF && fNum <= endF) { 
                                                        PreviewView.KeyFrame original = tl.get(fNum); 
                                                        PreviewView.KeyFrame copied = new PreviewView.KeyFrame(fNum - startF, original.cX, original.cY, original.hR, original.hl1, original.hl2, original.hr1, original.hr2, original.ll1, original.ll2, original.f1, original.lr1, original.lr2, original.f2); 
                                                        clipboardBlock.add(copied); count++; } }
                                                    Toast.makeText(PreviewActivity.this, count + " Frames Copied! ✂️", Toast.LENGTH_SHORT).show();
                                                }
                                            } catch (Exception e) { Toast.makeText(PreviewActivity.this, "Invalid Numbers!", Toast.LENGTH_SHORT).show(); }
                                        }
                                    }).setNegativeButton("Cancel", null).show();
                            }
                            else if (which == 11) { 
                                if (clipboardBlock.isEmpty()) { Toast.makeText(PreviewActivity.this, "⚠️ Clipboard empty!", Toast.LENGTH_SHORT).show(); return; }
                                int pasteStartFrame = (currentTimelinePage * FRAMES_PER_PAGE) + timelineSeekBar.getProgress(); SceneCharacter sc = DataHolder.getActiveChar();
                                if (sc != null) {
                                    for(PreviewView.KeyFrame kf : clipboardBlock) { int targetFrame = pasteStartFrame + kf.frameNo; PreviewView.KeyFrame newKf = new PreviewView.KeyFrame(targetFrame, kf.cX, kf.cY, kf.hR, kf.hl1, kf.hl2, kf.hr1, kf.hr2, kf.ll1, kf.ll2, kf.f1, kf.lr1, kf.lr2, kf.f2); sc.animationTimelines.get(sc.currentPose).put(targetFrame, newKf); }
                                    updateTimelineUI(); previewView.setFrameManual(pasteStartFrame); Toast.makeText(PreviewActivity.this, "Pasted Successfully! 📋", Toast.LENGTH_SHORT).show();
                                }
                            }
                            else if (which == 12) { DataHolder.isOnionSkinEnabled = !DataHolder.isOnionSkinEnabled; previewView.invalidate(); Toast.makeText(PreviewActivity.this, DataHolder.isOnionSkinEnabled ? "Onion Skin ON 👻" : "Onion Skin OFF", Toast.LENGTH_SHORT).show(); }
                            else if (which == 13) {
                                int uId = previewView.getSingleUnlockedPart();
                                if (uId == -1) { Toast.makeText(PreviewActivity.this, "⚠️ Pehle Lock Panel se 1 part Unlock karo!", Toast.LENGTH_LONG).show(); } 
                                else { 
                                    String meshKey = DataHolder.activeCharIndex + "_" + uId; 
                                    DataHolder.partMeshes.remove(meshKey); DataHolder.partPerspectives.remove(meshKey); 
                                    previewView.invalidate(); Toast.makeText(PreviewActivity.this, "Reset Done! ✨", Toast.LENGTH_SHORT).show(); 
                                }
                            }
                            else if (which == 14) {
                                String[] speeds = {"12 FPS (Anime Style)", "24 FPS (Cinematic)", "30 FPS (Standard)", "60 FPS (Super Smooth)"};
                                new AlertDialog.Builder(PreviewActivity.this).setTitle("Select Playback Speed").setItems(speeds, new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface dialog, int w) { if(w==0) previewView.setAnimSpeedMs(1000/12); else if(w==1) previewView.setAnimSpeedMs(1000/24); else if(w==2) previewView.setAnimSpeedMs(1000/30); else if(w==3) previewView.setAnimSpeedMs(1000/60); Toast.makeText(PreviewActivity.this, "Speed Applied Globally! 🚀", Toast.LENGTH_SHORT).show(); } }).show();
                            }
                            else if (which == 15) {
                                final SceneCharacter sc = DataHolder.getActiveChar(); if (sc == null) return;
                                LinearLayout layout = new LinearLayout(PreviewActivity.this); layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(50, 20, 50, 20);
                                final EditText alp = new EditText(PreviewActivity.this); alp.setHint("Opacity (0 = Gayab, 255 = Pura)"); alp.setText(String.valueOf(sc.alpha)); alp.setInputType(InputType.TYPE_CLASS_NUMBER); layout.addView(alp);
                                new AlertDialog.Builder(PreviewActivity.this).setTitle("Character Opacity").setView(layout).setPositiveButton("Apply", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface dialog, int w) { try { int a = Integer.parseInt(alp.getText().toString()); sc.alpha = Math.max(0, Math.min(255, a)); previewView.invalidate(); } catch (Exception e) {} } }).setNegativeButton("Full Visible", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface dialog, int which) { sc.alpha = 255; previewView.invalidate(); } }).show();
                            }
                            else if (which == 16) {
                                final SceneCharacter sc = DataHolder.getActiveChar(); if (sc == null) return;
                                String[] eases = {"Linear (Robotic)", "Ease-In (Slow Start)", "Ease-Out (Slow Stop)", "Smooth In-Out (Natural)"};
                                new AlertDialog.Builder(PreviewActivity.this).setTitle("Set Motion Easing (Current Frame)").setItems(eases, new DialogInterface.OnClickListener() { 
                                    @Override public void onClick(DialogInterface dialog, int w) { 
                                        sc.easingType = w; 
                                        int actualFrame = (currentTimelinePage * FRAMES_PER_PAGE) + timelineSeekBar.getProgress();
                                        HashMap<Integer, PreviewView.KeyFrame> tl = sc.animationTimelines.get(sc.currentPose);
                                        if (tl != null && tl.containsKey(actualFrame)) { tl.get(actualFrame).ease = w; }
                                        Toast.makeText(PreviewActivity.this, "Easing Applied to Current Frame! 🌊", Toast.LENGTH_SHORT).show(); 
                                    } 
                                }).show();
                            }
                            else if (which == 17) {
                                final SceneCharacter sc = DataHolder.getActiveChar(); if (sc == null) return;
                                String[] eases = {"Linear (Robotic)", "Ease-In (Slow Start)", "Ease-Out (Slow Stop)", "Smooth In-Out (Natural)"};
                                new AlertDialog.Builder(PreviewActivity.this).setTitle("Apply Easing to ALL Frames").setItems(eases, new DialogInterface.OnClickListener() { 
                                    @Override public void onClick(DialogInterface dialog, int w) { 
                                        HashMap<Integer, PreviewView.KeyFrame> tl = sc.animationTimelines.get(sc.currentPose);
                                        if (tl != null && !tl.isEmpty()) {
                                            for (PreviewView.KeyFrame kf : tl.values()) { kf.ease = w; }
                                            sc.easingType = w;
                                            previewView.invalidate();
                                            Toast.makeText(PreviewActivity.this, "Applied to all " + tl.size() + " frames! 🌊", Toast.LENGTH_SHORT).show();
                                        } else {
                                            Toast.makeText(PreviewActivity.this, "Pehle timeline pe keyframes add karo!", Toast.LENGTH_SHORT).show();
                                        }
                                    } 
                                }).show();
                            }
                        }
                    }).show();
            }
        });

        btnImportBG.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { Intent intent = new Intent(Intent.ACTION_PICK); intent.setType("image/*"); startActivityForResult(intent, 300); } });

        btnMode.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                // Yahan 5 Modes hain ab (0 to 4)
                currentInteractionViewMode++; if(currentInteractionViewMode > 4) currentInteractionViewMode = 0;
                previewView.setCurrentMode(currentInteractionViewMode);
                if(currentInteractionViewMode == PreviewView.MODE_BONE) { btnMode.setText("Mode: BONES"); btnMode.setBackgroundColor(Color.parseColor("#FF9800")); } 
                else if(currentInteractionViewMode == PreviewView.MODE_CHAR) { btnMode.setText("Mode: CHAR"); btnMode.setBackgroundColor(Color.parseColor("#00BCD4")); } 
                else if(currentInteractionViewMode == PreviewView.MODE_BG) { btnMode.setText("Mode: BG"); btnMode.setBackgroundColor(Color.parseColor("#9C27B0")); }
                else if(currentInteractionViewMode == PreviewView.MODE_MESH) { btnMode.setText("Mode: MESH"); btnMode.setBackgroundColor(Color.parseColor("#E91E63")); }
                else { btnMode.setText("Mode: PERSP"); btnMode.setBackgroundColor(Color.parseColor("#1976D2")); } 
            }
        });

        btnAddKey.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { int actualFrame = (currentTimelinePage * FRAMES_PER_PAGE) + timelineSeekBar.getProgress(); previewView.addKeyframeAtCurrentProgress(actualFrame); updateTimelineUI(); Toast.makeText(PreviewActivity.this, "Key Added at " + actualFrame, Toast.LENGTH_SHORT).show(); } });

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (previewView.isPlayingAnim()) { previewView.stopPlaying(); btnPlay.setText("▶ PLAY"); btnPlay.setBackgroundColor(Color.parseColor("#2196F3")); } 
                else { if(previewView.getLastKeyframeNumber() == 0) { Toast.makeText(PreviewActivity.this, "Pehle timeline pe '+ ADD KEY' dabao", Toast.LENGTH_SHORT).show(); return; } previewView.startPlaying(); btnPlay.setText("⏹ STOP"); btnPlay.setBackgroundColor(Color.parseColor("#FF9800")); }
            }
        });

        btnPrevPage.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if (currentTimelinePage > 0) { currentTimelinePage--; timelineSeekBar.setProgress(0); updateTimelineUI(); } } });
        btnNextPage.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { currentTimelinePage++; timelineSeekBar.setProgress(0); updateTimelineUI(); } });

        timelineSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { int actualFrame = (currentTimelinePage * FRAMES_PER_PAGE) + progress; tvCurrentFrame.setText("Current Frame: " + actualFrame); if (fromUser) { previewView.setFrameManual(actualFrame); } }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { previewView.stopPlaying(); }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        previewView.setOnFrameChangeListener(new PreviewView.OnFrameChangeListener() {
            @Override public void onFrameChanged(int frame) { tvCurrentFrame.setText("Current Frame: " + frame); int neededPage = frame / FRAMES_PER_PAGE; if (neededPage != currentTimelinePage) { currentTimelinePage = neededPage; updateTimelineUI(); } else { timelineSeekBar.setProgress(frame % FRAMES_PER_PAGE); } }
        });
    }

    private void initAdvancedToolsBar() {
        advancedToolsBarWrapper = findViewById(R.id.advancedToolsBarWrapper); tvAdvTitle = findViewById(R.id.tvAdvTitle); tvAdvScale = findViewById(R.id.tvAdvScale); tvAdvZ = findViewById(R.id.tvAdvZ); tvAdvPose = findViewById(R.id.tvAdvPose);
        btnAdvScaleMinus = findViewById(R.id.btnAdvScaleMinus); btnAdvScalePlus = findViewById(R.id.btnAdvScalePlus); btnAdvZMinus = findViewById(R.id.btnAdvZMinus); btnAdvZPlus = findViewById(R.id.btnAdvZPlus); btnAdvPoseMinus = findViewById(R.id.btnAdvPoseMinus); btnAdvPosePlus = findViewById(R.id.btnAdvPosePlus); btnAdvReset = findViewById(R.id.btnAdvReset); btnAdvClose = findViewById(R.id.btnAdvClose);

        btnAdvScaleMinus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activeAdvTargetIndex==-1) return; previewView.advScale[activeAdvTargetIndex] -= 0.1f; tvAdvScale.setText(String.format("%.1fx", previewView.advScale[activeAdvTargetIndex])); previewView.invalidate(); } });
        btnAdvScalePlus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activeAdvTargetIndex==-1) return; previewView.advScale[activeAdvTargetIndex] += 0.1f; tvAdvScale.setText(String.format("%.1fx", previewView.advScale[activeAdvTargetIndex])); previewView.invalidate(); } });
        btnAdvZMinus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activeAdvTargetIndex==-1) return; previewView.advZIndex[activeAdvTargetIndex] -= 10; tvAdvZ.setText(String.valueOf(previewView.advZIndex[activeAdvTargetIndex])); previewView.invalidate(); } });
        btnAdvZPlus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activeAdvTargetIndex==-1) return; previewView.advZIndex[activeAdvTargetIndex] += 10; tvAdvZ.setText(String.valueOf(previewView.advZIndex[activeAdvTargetIndex])); previewView.invalidate(); } });
        btnAdvPoseMinus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activeAdvTargetIndex==-1) return; previewView.advPose[activeAdvTargetIndex]--; if(previewView.advPose[activeAdvTargetIndex] < -1) previewView.advPose[activeAdvTargetIndex] = 4; tvAdvPose.setText(previewView.advPose[activeAdvTargetIndex] == -1 ? "Def" : "P" + (previewView.advPose[activeAdvTargetIndex] + 1)); previewView.invalidate(); }});
        btnAdvPosePlus.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activeAdvTargetIndex==-1) return; previewView.advPose[activeAdvTargetIndex]++; if(previewView.advPose[activeAdvTargetIndex] > 4) previewView.advPose[activeAdvTargetIndex] = -1; tvAdvPose.setText(previewView.advPose[activeAdvTargetIndex] == -1 ? "Def" : "P" + (previewView.advPose[activeAdvTargetIndex] + 1)); previewView.invalidate(); }});
        btnAdvReset.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(activeAdvTargetIndex==-1) return; previewView.advScale[activeAdvTargetIndex] = 1f; previewView.advZIndex[activeAdvTargetIndex] = 0; previewView.advPose[activeAdvTargetIndex] = -1; tvAdvScale.setText("1.0x"); tvAdvZ.setText("0"); tvAdvPose.setText("Def"); previewView.invalidate(); }});
        btnAdvClose.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { advancedToolsBarWrapper.setVisibility(View.GONE); }});
    }

    private void openAdvancedAdjustUI() {
        boolean[] locks = previewView.getUnlockedParts(); int unlockedIndex = -1, count = 0;
        for (int i = 0; i < locks.length; i++) { if (locks[i]) { unlockedIndex = i; count++; } }
        if (count == 0) { Toast.makeText(this, "⚠️ Please UNLOCK a part from Lock Panel first!", Toast.LENGTH_SHORT).show(); return; }
        if (count > 1) { Toast.makeText(this, "⚠️ Please UNLOCK ONLY ONE part!", Toast.LENGTH_SHORT).show(); return; }
        activeAdvTargetIndex = unlockedIndex; tvAdvTitle.setText("Edit: " + lockNames[activeAdvTargetIndex]); tvAdvScale.setText(String.format("%.1fx", previewView.advScale[activeAdvTargetIndex])); tvAdvZ.setText(String.valueOf(previewView.advZIndex[activeAdvTargetIndex])); tvAdvPose.setText(previewView.advPose[activeAdvTargetIndex] == -1 ? "Def" : "P" + (previewView.advPose[activeAdvTargetIndex] + 1)); advancedToolsBarWrapper.setVisibility(View.VISIBLE);
    }

    private void buildSideLockPanel() {
        if (lockButtonsContainer == null) return; lockButtonsContainer.removeAllViews(); TextView title = new TextView(this); title.setText("LOCK PANEL"); title.setTextColor(Color.WHITE); title.setTextSize(11f); title.setGravity(android.view.Gravity.CENTER); title.setTypeface(null, android.graphics.Typeface.BOLD); title.setPadding(0, 10, 0, 15); lockButtonsContainer.addView(title);
        for (int i = 0; i < lockNames.length; i++) { final int index = i; final Button btn = new Button(this); LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); params.setMargins(0, 4, 0, 4); btn.setLayoutParams(params); btn.setTextSize(9f); btn.setPadding(2, 6, 2, 6); btn.setId(5000 + i);
            btn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { boolean[] locks = previewView.getUnlockedParts(); if (locks != null && index < locks.length) { boolean newStatus = !locks[index]; previewView.setUnlockedPart(index, newStatus); updateSingleLockButton(btn, index, newStatus); if(newStatus && advancedToolsBarWrapper.getVisibility() == View.VISIBLE) { openAdvancedAdjustUI(); } } } }); lockButtonsContainer.addView(btn);
        } refreshLockPanelUi();
    }

    private void refreshLockPanelUi() {
        boolean[] currentLocks = previewView.getUnlockedParts(); if (currentLocks == null || lockButtonsContainer == null) return;
        for (int i = 0; i < lockNames.length; i++) { Button btn = lockButtonsContainer.findViewById(5000 + i); if (btn != null && i < currentLocks.length) { updateSingleLockButton(btn, i, currentLocks[i]); } }
    }

    private void updateSingleLockButton(Button btn, int index, boolean isUnlocked) {
        if (isUnlocked) { btn.setText(lockNames[index] + "\n(UNLOCKED)"); btn.setBackgroundColor(Color.parseColor("#4CAF50")); btn.setTextColor(Color.WHITE); } 
        else { btn.setText(lockNames[index] + "\n(LOCKED)"); btn.setBackgroundColor(Color.parseColor("#E53935")); btn.setTextColor(Color.WHITE); }
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus) { updateTimelineUI(); refreshLockPanelUi(); } }

    private void updateTimelineUI() {
        if (rulerContainer.getWidth() == 0) return; rulerContainer.removeAllViews(); dotsContainer.removeAllViews();
        int startFrame = currentTimelinePage * FRAMES_PER_PAGE; int endFrame = startFrame + FRAMES_PER_PAGE; int paddingLeft = timelineSeekBar.getPaddingLeft(); int trackWidth = timelineSeekBar.getWidth() - paddingLeft - timelineSeekBar.getPaddingRight();
        for (int i = 0; i <= FRAMES_PER_PAGE; i += 10) { TextView tv = new TextView(this); tv.setText(String.valueOf(startFrame + i)); tv.setTextSize(10f); tv.setTextColor(Color.BLACK); FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT); params.leftMargin = paddingLeft + (int) (trackWidth * ((float) i / FRAMES_PER_PAGE)) - 10; rulerContainer.addView(tv, params); }
        ArrayList<Integer> keys = previewView.getAllKeyframes();
        for (int frame : keys) { if (frame >= startFrame && frame <= endFrame) { View dot = new View(this); dot.setBackgroundColor(Color.RED); FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(16, 30); params.leftMargin = paddingLeft + (int) (trackWidth * ((float) (frame - startFrame) / FRAMES_PER_PAGE)) - 8; params.topMargin = 10; dotsContainer.addView(dot, params); } }
        tvCurrentFrame.setText("Current Frame: " + ((currentTimelinePage * FRAMES_PER_PAGE) + timelineSeekBar.getProgress()));
    }

    private void showPoseDialog() {
        final String[] poses = {"Pose 1 (Front)", "Pose 2 (Front 3/4)", "Pose 3 (Side)", "Pose 4 (Back 3/4)", "Pose 5 (Back)"};
        new AlertDialog.Builder(this).setTitle("Select Pose").setItems(poses, new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface dialog, int which) { previewView.changePose(which + 1); currentTimelinePage = 0; timelineSeekBar.setProgress(0); updateTimelineUI(); refreshLockPanelUi(); } }).show();
    }

    private void showCreateAnimationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this); builder.setTitle("Create Animation"); builder.setCancelable(false); final EditText input = new EditText(this); input.setHint("Animation Name (e.g., Run, Jump)"); builder.setView(input);
        builder.setPositiveButton("Create", new DialogInterface.OnClickListener() { @Override public void onClick(DialogInterface dialog, int which) { String animName = input.getText().toString().trim(); if (animName.isEmpty()) animName = "Untitled"; tvAnimName.setText("Anim: " + animName); } }); builder.show();
    }

    private void saveAnimationAndExit() { String saveName = tvAnimName.getText().toString().replace("Anim: ", ""); AnimationStorage.saveAnimation(PreviewActivity.this, saveName, previewView.getPoseTimelines()); Toast.makeText(PreviewActivity.this, saveName + " Saved Successfully!", Toast.LENGTH_LONG).show(); finish(); }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) { if (requestCode == 300 && resultCode == RESULT_OK && data != null) { try { Bitmap bmp = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData()); previewView.setBackgroundReference(bmp); } catch (Exception e) {} } }
}
