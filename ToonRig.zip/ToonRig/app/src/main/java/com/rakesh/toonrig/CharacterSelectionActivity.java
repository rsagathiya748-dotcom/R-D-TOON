package com.rakesh.toonrig;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;
import java.util.ArrayList;

public class CharacterSelectionActivity extends Activity {

    private GridView gridView;
    private CharacterAdapter adapter;
    private ArrayList<CharacterModel> allCharacters;
    private ArrayList<CharacterModel> filteredCharacters;
    private Button btnImportCustom, btnAddCharacter, btnNext;
    private Button btnFilterPro, btnFilterFree, btnFilterCustom;

    private boolean showPro = true;
    private boolean showFree = true;
    private boolean showCustom = true;

    // 🔥 NAYA: Signal receiver jo background se download hote hi grid refresh karega
    public static Runnable liveUpdateListener = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character_selection);

        if (DataHolder.sceneCharacters == null) {
            DataHolder.sceneCharacters = new ArrayList<>();
        } else if (!DataHolder.isAddingNewChar) {
            DataHolder.sceneCharacters.clear(); 
        }

        gridView = findViewById(R.id.character_grid);
        btnImportCustom = findViewById(R.id.btnImportCustom);
        btnAddCharacter = findViewById(R.id.btnAddCharacter);
        btnNext = findViewById(R.id.btnNext);
        btnFilterPro = findViewById(R.id.btnFilterPro);
        btnFilterFree = findViewById(R.id.btnFilterFree);
        btnFilterCustom = findViewById(R.id.btnFilterCustom);

        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        } else {
            loadAllCharacters();
        }

        btnFilterPro.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showPro = !showPro; updateFilterUI(); applyFilters(); }
        });
        btnFilterFree.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showFree = !showFree; updateFilterUI(); applyFilters(); }
        });
        btnFilterCustom.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showCustom = !showCustom; updateFilterUI(); applyFilters(); }
        });
        updateFilterUI(); 

        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (filteredCharacters != null && position < filteredCharacters.size()) {
                    CharacterModel selected = filteredCharacters.get(position);
                    if (selected.isCustom()) {
                        showCustomOptionsDialog(selected);
                        return true;
                    } else {
                        Toast.makeText(CharacterSelectionActivity.this, "Aap sirf Custom characters ko edit kar sakte hain!", Toast.LENGTH_SHORT).show();
                    }
                }
                return false;
            }
        });

        btnImportCustom.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String[] options = {"1. Quick Import (Single Sprite Sheet)", "2. Build Custom Rig (Part by Part)"};
                new AlertDialog.Builder(CharacterSelectionActivity.this)
                    .setTitle("Choose Import Method")
                    .setItems(options, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (which == 0) {
                                Intent intent = new Intent(Intent.ACTION_PICK); 
                                intent.setType("image/*"); 
                                startActivityForResult(intent, 100);
                            } else {
                                startActivity(new Intent(CharacterSelectionActivity.this, CustomBuilderActivity.class));
                            }
                        }
                    }).show();
            }
        });

        btnAddCharacter.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (adapter != null) {
                    CharacterModel selected = adapter.getSelectedCharacter();
                    if (selected != null) {
                        if (DataHolder.sceneCharacters.size() >= 10) {
                            Toast.makeText(CharacterSelectionActivity.this, "Max 10 characters allowed!", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        
                        String path = selected.getFilePath();
                        String customPath = (path != null && !path.isEmpty()) ? path : null;
                        int resId = (customPath != null) ? -1 : selected.getResId();
                        
                        SceneCharacter newChar = RiggingHelper.createCharacter(CharacterSelectionActivity.this, selected.getName(), resId, customPath);
                        DataHolder.sceneCharacters.add(newChar);
                        
                        Toast.makeText(CharacterSelectionActivity.this, selected.getName() + " Added! Total: " + DataHolder.sceneCharacters.size(), Toast.LENGTH_SHORT).show();
                        
                        if (DataHolder.isAddingNewChar) {
                            DataHolder.isAddingNewChar = false;
                            finish(); 
                        }
                    } else {
                        Toast.makeText(CharacterSelectionActivity.this, "Pehle ek character select karo!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (DataHolder.sceneCharacters.isEmpty()) {
                    Toast.makeText(CharacterSelectionActivity.this, "Kam se kam 1 character add karo!", Toast.LENGTH_SHORT).show();
                } else {
                    DataHolder.isAddingNewChar = false;
                    startActivity(new Intent(CharacterSelectionActivity.this, HubActivity.class));
                    finish(); 
                }
            }
        });
    }

    // ==========================================
    // 🔥 LIVE UPDATE: SCREEN VISIBLE HONE PAR ON KAREIN 🔥
    // ==========================================
    @Override
    protected void onResume() {
        super.onResume();
        loadAllCharacters();
        
        liveUpdateListener = new Runnable() {
            @Override
            public void run() {
                loadAllCharacters(); // Jese hi background me download hoga, grid apne aap naye character dhikhadegi!
            }
        };
    }

    // 🔥 MEMORY LEAK BACHANE KE LIYE OFF KAREIN 🔥
    @Override
    protected void onPause() {
        super.onPause();
        liveUpdateListener = null;
    }

    public void showCustomOptionsDialog(final CharacterModel model) {
        String[] options = {"✏️ Edit Poses", "📝 Rename", "🗑️ Delete"};
        new AlertDialog.Builder(this)
            .setTitle(model.getName())
            .setItems(options, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (which == 0) {
                        openEditMode(model);
                    } else if (which == 1) {
                        showRenameDialog(model);
                    } else if (which == 2) {
                        showDeleteDialog(model);
                    }
                }
            }).show();
    }

    private void openEditMode(CharacterModel model) {
        Intent intent = new Intent(CharacterSelectionActivity.this, CustomBuilderActivity.class);
        intent.putExtra("EDIT_PATH", model.getFilePath());
        intent.putExtra("EDIT_NAME", model.getName());
        startActivity(intent);
    }

    public void showRenameDialog(final CharacterModel model) {
        if (!model.isCustom()) { Toast.makeText(this, "Aap App ke default character ko rename nahi kar sakte.", Toast.LENGTH_SHORT).show(); return; }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Rename Character");
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setText(model.getName()); builder.setView(input);
        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
                String newName = input.getText().toString().trim();
                if (!newName.isEmpty()) {
                    CharacterStorage.renameCustomCharacter(CharacterSelectionActivity.this, model.getFilePath(), newName);
                    loadAllCharacters(); Toast.makeText(CharacterSelectionActivity.this, "Character Renamed!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", null); builder.show();
    }

    public void showDeleteDialog(final CharacterModel model) {
        if (!model.isCustom()) { Toast.makeText(this, "Aap App ke default character ko delete nahi kar sakte.", Toast.LENGTH_SHORT).show(); return; }
        new AlertDialog.Builder(this).setTitle("Delete Character").setMessage("Kya aap is custom character ko delete karna chahte hain?")
            .setPositiveButton("Haan", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    CharacterStorage.removeCustomCharacter(CharacterSelectionActivity.this, model.getFilePath());
                    loadAllCharacters(); Toast.makeText(CharacterSelectionActivity.this, "Character Deleted!", Toast.LENGTH_SHORT).show();
                }
            }).setNegativeButton("Nahi", null).show();
    }

    private void updateFilterUI() {
        btnFilterPro.setBackgroundColor(showPro ? Color.parseColor("#008080") : Color.parseColor("#555555"));
        btnFilterFree.setBackgroundColor(showFree ? Color.parseColor("#008080") : Color.parseColor("#555555"));
        btnFilterCustom.setBackgroundColor(showCustom ? Color.parseColor("#008080") : Color.parseColor("#555555"));
    }

    private void applyFilters() {
        filteredCharacters = new ArrayList<>();
        if (showPro) for (CharacterModel c : allCharacters) if (c.getType() == CharacterModel.TYPE_PRO) filteredCharacters.add(c);
        if (showFree) for (CharacterModel c : allCharacters) if (c.getType() == CharacterModel.TYPE_FREE) filteredCharacters.add(c);
        if (showCustom) for (CharacterModel c : allCharacters) if (c.getType() == CharacterModel.TYPE_CUSTOM) filteredCharacters.add(c);
        adapter = new CharacterAdapter(this, filteredCharacters); gridView.setAdapter(adapter);
    }

    private void loadAllCharacters() {
        allCharacters = new ArrayList<CharacterModel>();
        allCharacters.add(new CharacterModel("Ajay", R.drawable.ajay, CharacterModel.TYPE_PRO));
        allCharacters.add(new CharacterModel("Amit", R.drawable.amit, CharacterModel.TYPE_PRO));
        allCharacters.add(new CharacterModel("Atul", R.drawable.atul, CharacterModel.TYPE_FREE));
        allCharacters.add(new CharacterModel("Chirag", R.drawable.chirag, CharacterModel.TYPE_FREE));
        allCharacters.add(new CharacterModel("Mayur", R.drawable.mayur, CharacterModel.TYPE_FREE));
        allCharacters.add(new CharacterModel("Karan", R.drawable.karan, CharacterModel.TYPE_FREE));
        allCharacters.add(new CharacterModel("Jayesh", R.drawable.jayesh, CharacterModel.TYPE_FREE));
        allCharacters.add(new CharacterModel("Rohit", R.drawable.rohit, CharacterModel.TYPE_FREE));
        allCharacters.add(new CharacterModel("Mohit", R.drawable.mohit, CharacterModel.TYPE_FREE));
        allCharacters.add(new CharacterModel("Rahul", R.drawable.rahul, CharacterModel.TYPE_FREE));
        allCharacters.add(new CharacterModel("Main Character", R.drawable.character_sheet, CharacterModel.TYPE_FREE));
        allCharacters.addAll(CharacterStorage.getCustomCharacters(this));
        applyFilters();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try { 
                Bitmap bmp = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData());
                String savedPath = CharacterStorage.saveBitmapInternal(this, bmp, "Custom_Char");
                if (savedPath != null) {
                    // Quick import hamesha "CUSTOM" (2) aayega aur uski version 1 hogi
                    CharacterStorage.addCustomCharacter(this, "My Custom Character", savedPath, 2, 1);
                    loadAllCharacters(); 
                    Toast.makeText(this, "Import Success!", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {}
        }
    }
}
