package com.rakesh.toonrig;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Collections;
import java.util.Comparator;

public class HubActivity extends Activity {
    private PreviewView hubPreviewView;
    private Button btnCreateAnim, btnHubPose, btnHubBack, btnHubAdjust;
    private Button btnHubMoveMode, btnHubSwitchChar, btnHubFlip;
    private Button btnGoToAnimation, btnHubAssets, btnHubAudio, btnHubBackgrounds;
    private Button btnHubShadow, btnHubShadowAngle, btnHubShadowSize;
    
    private boolean isRecording = false;
    private static final int REC_CODE = 1000;
    private static final int PICK_BG_CODE = 201;
    
    public static int selectedQualityIndex = 1; 
    private int currentMoveMode = PreviewView.MODE_CHAR; 
    
    private View topBar;
    private View bottomToolsScroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hub);

        if (DataHolder.sceneCharacters.isEmpty()) { DataHolder.addNewCharacterToScene("Player 1"); }

        topBar = findViewById(R.id.topBar);
        bottomToolsScroll = findViewById(R.id.bottomToolsScroll);
        hubPreviewView = findViewById(R.id.hubPreviewView);
        
        btnCreateAnim = findViewById(R.id.btnCreateAnim);
        btnHubBack = findViewById(R.id.btnHubBack);
        btnHubPose = findViewById(R.id.btnHubPose);
        btnHubFlip = findViewById(R.id.btnHubFlip);
        btnHubAdjust = findViewById(R.id.btnHubAdjust);
        btnHubMoveMode = findViewById(R.id.btnHubMoveMode);
        btnHubSwitchChar = findViewById(R.id.btnHubSwitchChar);
        
        btnGoToAnimation = findViewById(R.id.btnGoToAnimation);
        btnHubAssets = findViewById(R.id.btnHubAssets);
        btnHubAudio = findViewById(R.id.btnHubAudio);
        btnHubBackgrounds = findViewById(R.id.btnHubBackgrounds);
        
        btnHubShadow = findViewById(R.id.btnHubShadow);
        btnHubShadowAngle = findViewById(R.id.btnHubShadowAngle);
        btnHubShadowSize = findViewById(R.id.btnHubShadowSize);

        hubPreviewView.setCurrentMode(currentMoveMode);
        updateSwitchButtonText();

        hubPreviewView.setOnFrameChangeListener(new PreviewView.OnFrameChangeListener() {
            @Override
            public void onFrameChanged(int frame) {
                int lastFrame = hubPreviewView.getLastKeyframeNumber();
                if (isRecording && lastFrame > 0 && frame >= lastFrame) {
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override public void run() { stopRecordingAuto(); }
                    }, 200);
                }
            }
        });

        btnGoToAnimation.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HubActivity.this, AnimationSelectionActivity.class));
            }
        });

        btnHubSwitchChar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showCharacterManagerDialog(); }
        });

        btnHubBackgrounds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(HubActivity.this, BackgroundSelectionActivity.class), PICK_BG_CODE);
            }
        });

        btnHubAssets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HubActivity.this, AssetSelectionActivity.class));
            }
        });

        btnHubAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(HubActivity.this, "Audio & Voiceover Coming Soon!", Toast.LENGTH_SHORT).show();
            }
        });

        btnHubMoveMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentMoveMode == PreviewView.MODE_CHAR) {
                    currentMoveMode = PreviewView.MODE_BG;
                    btnHubMoveMode.setText("MOVE: BG"); btnHubMoveMode.setBackgroundColor(Color.parseColor("#D81B60")); 
                } else {
                    currentMoveMode = PreviewView.MODE_CHAR;
                    btnHubMoveMode.setText("MOVE: CHAR"); btnHubMoveMode.setBackgroundColor(Color.parseColor("#00897B")); 
                }
                hubPreviewView.setCurrentMode(currentMoveMode);
            }
        });

        btnHubBack.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (isRecording) stopRecordingAuto(); finish(); }
        });

        btnHubPose.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String[] poses = {"Pose 1 (Front)", "Pose 2", "Pose 3 (Side)", "Pose 4", "Pose 5 (Back)"};
                new AlertDialog.Builder(HubActivity.this).setTitle("Select Pose").setItems(poses, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) { hubPreviewView.changePose(which + 1); }
                }).show();
            }
        });
        
        btnHubFlip.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { hubPreviewView.toggleFlipX(); }
        });

        btnHubAdjust.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { hubPreviewView.stopPlaying(); startActivity(new Intent(HubActivity.this, AdjustmentActivity.class)); } });
        btnCreateAnim.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { hubPreviewView.stopPlaying(); startActivity(new Intent(HubActivity.this, PreviewActivity.class)); } });

        if(DataHolder.isShadowEnabled) {
            btnHubShadow.setBackgroundColor(Color.parseColor("#FFC107"));
            btnHubShadow.setTextColor(Color.BLACK);
        }
        
        btnHubShadow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                DataHolder.isShadowEnabled = !DataHolder.isShadowEnabled;
                if(DataHolder.isShadowEnabled) {
                    btnHubShadow.setBackgroundColor(Color.parseColor("#FFC107"));
                    btnHubShadow.setTextColor(Color.BLACK);
                    Toast.makeText(HubActivity.this, "Shadow ON", Toast.LENGTH_SHORT).show();
                } else {
                    btnHubShadow.setBackgroundColor(Color.parseColor("#424242"));
                    btnHubShadow.setTextColor(Color.WHITE);
                    Toast.makeText(HubActivity.this, "Shadow OFF", Toast.LENGTH_SHORT).show();
                }
                hubPreviewView.invalidate();
            }
        });

        btnHubShadowAngle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!DataHolder.isShadowEnabled) { Toast.makeText(HubActivity.this, "Turn ON Shadow first!", Toast.LENGTH_SHORT).show(); return; }
                String[] shadowAngles = {"Shadow 1", "Shadow 2", "Shadow 3", "Shadow 4", "Shadow 5", "Shadow 6", "Shadow 7", "Shadow 8"};
                new AlertDialog.Builder(HubActivity.this).setTitle("Select Shadow Pose").setItems(shadowAngles, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int w) { DataHolder.shadowDirection = w; hubPreviewView.invalidate(); }
                }).show();
            }
        });

        btnHubShadowSize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!DataHolder.isShadowEnabled) { Toast.makeText(HubActivity.this, "Turn ON Shadow first!", Toast.LENGTH_SHORT).show(); return; }
                String[] sizes = {"0.5x (Chhota)", "1.0x (Normal)", "1.5x (Bada)", "2.0x (Bahut Bada)", "2.5x (Giant)", "3.0x (Max)"};
                new AlertDialog.Builder(HubActivity.this).setTitle("Shadow Size").setItems(sizes, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int w) {
                        if(w==0) DataHolder.shadowLength = 0.5f; else if(w==1) DataHolder.shadowLength = 1.0f;
                        else if(w==2) DataHolder.shadowLength = 1.5f; else if(w==3) DataHolder.shadowLength = 2.0f;
                        else if(w==4) DataHolder.shadowLength = 2.5f; else if(w==5) DataHolder.shadowLength = 3.0f;
                        hubPreviewView.invalidate();
                    }
                }).show();
            }
        });
    }

    private void showCharacterManagerDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_manage_chars);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        final LinearLayout container = dialog.findViewById(R.id.charListContainer);
        Button btnClose = dialog.findViewById(R.id.btnCloseDialog);
        btnClose.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { dialog.dismiss(); } });
        refreshDialogList(dialog, container);
        dialog.show();
    }

    private void refreshDialogList(final Dialog dialog, final LinearLayout container) {
        container.removeAllViews();
        Button btnAddNew = new Button(this);
        btnAddNew.setText("+ ADD NEW CHARACTER");
        btnAddNew.setBackgroundColor(Color.parseColor("#2196F3"));
        btnAddNew.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, 15);
        btnAddNew.setLayoutParams(params);
        btnAddNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (DataHolder.sceneCharacters.size() >= 10) {
                    Toast.makeText(HubActivity.this, "Max 10 characters allowed!", Toast.LENGTH_SHORT).show();
                    return;
                }
                DataHolder.isAddingNewChar = true;
                startActivity(new Intent(HubActivity.this, CharacterSelectionActivity.class));
                dialog.dismiss();
            }
        });
        container.addView(btnAddNew);

        Collections.sort(DataHolder.sceneCharacters, new Comparator<SceneCharacter>() {
            @Override public int compare(SceneCharacter c1, SceneCharacter c2) { return Integer.compare(c2.zOrder, c1.zOrder); }
        });
        for(int i=0; i<DataHolder.sceneCharacters.size(); i++) {
            DataHolder.sceneCharacters.get(i).zOrder = DataHolder.sceneCharacters.size() - i;
        }

        for (int i = 0; i < DataHolder.sceneCharacters.size(); i++) {
            final SceneCharacter sc = DataHolder.sceneCharacters.get(i);
            final LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(10, 15, 10, 15);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView tvName = new TextView(this);
            boolean isActive = DataHolder.getActiveChar() == sc;
            tvName.setText(sc.charName + (isActive ? " (Active)" : ""));
            tvName.setTextColor(isActive ? Color.parseColor("#4CAF50") : Color.WHITE);
            tvName.setTextSize(16);
            tvName.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            tvName.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    DataHolder.activeCharIndex = DataHolder.sceneCharacters.indexOf(sc);
                    updateSwitchButtonText();
                    hubPreviewView.invalidate();
                    dialog.dismiss();
                }
            });
            row.addView(tvName);
            TextView dragHandle = new TextView(this);
            dragHandle.setText(" ☰ "); dragHandle.setTextColor(Color.LTGRAY); dragHandle.setTextSize(26); dragHandle.setPadding(20, 0, 30, 0);
            dragHandle.setOnTouchListener(new View.OnTouchListener() {
                float startY;
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    ViewGroup scrollView = (ViewGroup) container.getParent(); 
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            if (scrollView != null) scrollView.requestDisallowInterceptTouchEvent(true);
                            row.setBackgroundColor(Color.parseColor("#444444")); startY = event.getRawY(); return true;
                        case MotionEvent.ACTION_MOVE:
                            float diff = event.getRawY() - startY;
                            int rowHeight = row.getHeight() == 0 ? 100 : row.getHeight();
                            if (Math.abs(diff) > rowHeight) { 
                                int currentIndex = container.indexOfChild(row);
                                if (currentIndex == -1) return true;
                                int targetIndex = diff > 0 ? currentIndex + 1 : currentIndex - 1;
                                if (targetIndex > 0 && targetIndex < container.getChildCount()) {
                                    try {
                                        container.removeView(row); container.addView(row, targetIndex);
                                        Collections.swap(DataHolder.sceneCharacters, currentIndex - 1, targetIndex - 1);
                                        for(int x=0; x<DataHolder.sceneCharacters.size(); x++) { DataHolder.sceneCharacters.get(x).zOrder = DataHolder.sceneCharacters.size() - x; }
                                        hubPreviewView.invalidate(); startY = event.getRawY(); 
                                    } catch (Exception e) {}
                                }
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            row.setBackgroundColor(Color.TRANSPARENT);
                            if (scrollView != null) scrollView.requestDisallowInterceptTouchEvent(false); return true;
                    }
                    return false;
                }
            });
            row.addView(dragHandle);
            Button btnDel = new Button(this);
            btnDel.setText("DEL"); btnDel.setTextColor(Color.WHITE); btnDel.setBackgroundColor(Color.parseColor("#F44336")); 
            btnDel.setTextSize(12); btnDel.setPadding(0,0,0,0);
            LinearLayout.LayoutParams lpDel = new LinearLayout.LayoutParams(110, 90); lpDel.setMargins(10, 0, 10, 0);
            btnDel.setLayoutParams(lpDel);
            btnDel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (DataHolder.sceneCharacters.size() <= 1) { Toast.makeText(HubActivity.this, "At least 1 character needed.", Toast.LENGTH_SHORT).show();
                    } else {
                        DataHolder.sceneCharacters.remove(sc); DataHolder.activeCharIndex = 0;
                        updateSwitchButtonText(); hubPreviewView.invalidate(); refreshDialogList(dialog, container);
                    }
                }
            });
            row.addView(btnDel); container.addView(row);
        }
    }

    private void updateSwitchButtonText() {
        if(DataHolder.getActiveChar() != null) { btnHubSwitchChar.setText("LAYERS: " + (DataHolder.activeCharIndex + 1)); }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (DataHolder.isAddingNewChar) {
            DataHolder.isAddingNewChar = false;
            String charName = "Player " + (DataHolder.sceneCharacters.size() + 1);
            if (DataHolder.selectedCustomPath != null && !DataHolder.selectedCustomPath.isEmpty()) {
                try {
                    String[] parts = DataHolder.selectedCustomPath.split("/");
                    if (parts.length >= 2) {
                        String folderName = parts[parts.length - 2]; String fileName = parts[parts.length - 1];
                        if (fileName.contains("Custom_Char") || fileName.matches(".*\\d{10,}.*")) {
                            if (!folderName.equals("0") && !folderName.equalsIgnoreCase("pictures")) charName = folderName;
                            else charName = "Custom Char " + (DataHolder.sceneCharacters.size() + 1);
                        } else { charName = fileName.replace(".png", "").replace(".jpg", ""); }
                    }
                } catch (Exception e) {}
            }
            SceneCharacter newChar = RiggingHelper.createCharacter(this, charName, DataHolder.selectedResId, DataHolder.selectedCustomPath);
            newChar.globalX = -100f; DataHolder.sceneCharacters.add(newChar); DataHolder.activeCharIndex = DataHolder.sceneCharacters.size() - 1; 
            updateSwitchButtonText(); hubPreviewView.invalidate();
        }
    }

    private void stopRecordingAuto() {
        if (!isRecording) return;
        isRecording = false; stopService(new Intent(HubActivity.this, RecordService.class)); hubPreviewView.stopPlaying();
        if (topBar != null) topBar.setVisibility(View.VISIBLE); if (bottomToolsScroll != null) bottomToolsScroll.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REC_CODE) {
            if (resultCode == RESULT_OK) {
                isRecording = true; 
                Intent serviceIntent = new Intent(this, RecordService.class);
                serviceIntent.putExtra("code", resultCode); serviceIntent.putExtra("data", data); serviceIntent.putExtra("quality_index", selectedQualityIndex);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { startForegroundService(serviceIntent); } else { startService(serviceIntent); }
                hubPreviewView.setFrameManualForAll(0);
                new Handler().postDelayed(new Runnable() { @Override public void run() { hubPreviewView.startPlaying(); } }, 800);
            } else { 
                if (topBar != null) topBar.setVisibility(View.VISIBLE); if (bottomToolsScroll != null) bottomToolsScroll.setVisibility(View.VISIBLE);
            }
        } 
        else if (requestCode == PICK_BG_CODE && resultCode == RESULT_OK && data != null) {
            if (data.hasExtra("bgColor")) {
                int color = data.getIntExtra("bgColor", Color.parseColor("#222222"));
                hubPreviewView.setChromaColor(color); 
                hubPreviewView.setBackgroundReference(null);
                DataHolder.bgColor = color;
                DataHolder.bgBitmap = null;
            } else if (data.hasExtra("bgResId")) {
                int resId = data.getIntExtra("bgResId", 0);
                Bitmap bmp = BitmapFactory.decodeResource(getResources(), resId);
                hubPreviewView.setBackgroundReference(bmp);
                DataHolder.bgBitmap = bmp;
                DataHolder.bgColor = Color.TRANSPARENT;
                currentMoveMode = PreviewView.MODE_BG; hubPreviewView.setCurrentMode(currentMoveMode);
                btnHubMoveMode.setText("MOVE: BG"); btnHubMoveMode.setBackgroundColor(Color.parseColor("#D81B60"));
            } else if (data.getData() != null) {
                try {
                    Bitmap bmp = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData());
                    hubPreviewView.setBackgroundReference(bmp);
                    DataHolder.bgBitmap = bmp;
                    DataHolder.bgColor = Color.TRANSPARENT;
                    currentMoveMode = PreviewView.MODE_BG; hubPreviewView.setCurrentMode(currentMoveMode);
                    btnHubMoveMode.setText("MOVE: BG"); btnHubMoveMode.setBackgroundColor(Color.parseColor("#D81B60"));
                } catch (Exception e) {}
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        ProjectEngine.saveAutoSave(this); 
    }
}
