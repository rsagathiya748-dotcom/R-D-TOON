package com.rakesh.toonrig;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class AdjustmentActivity extends Activity {

    private ListView lvParts;
    private AdjustPreviewView adjustPreviewView;
    private TextView tvSelectedPart;
    private AdjustmentAdapter adapter;
    private Button btnChangePose;

    private float moveStep = 2.0f; 
    private float scaleStep = 0.05f; 
    private String currentCharacterId; 
    private static final int PICK_SKIN_CODE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adjustment);

        if (DataHolder.selectedCustomPath != null) {
            currentCharacterId = DataHolder.selectedCustomPath; 
        } else {
            currentCharacterId = "char_res_" + DataHolder.selectedResId; 
        }

        // ==========================================
        //  BONE EDITOR FIX: EXACT OBJECT LINKING (Without getProfileId) 
        // ==========================================
        DataHolder.currentRigProfile = null;
        
        if (DataHolder.sceneCharacters != null && !DataHolder.sceneCharacters.isEmpty()) {
            // Seedha aakhiri add kiya hua character utha lo (kyuki wahi abhi active hai)
            SceneCharacter activeChar = DataHolder.sceneCharacters.get(DataHolder.sceneCharacters.size() - 1);
            if (activeChar.rigProfile != null) {
                DataHolder.currentRigProfile = activeChar.rigProfile;
            }
        }

        // Agar kisi wajah se null hai, tabhi disk se load karenge (Safe Fallback)
        if (DataHolder.currentRigProfile == null) {
            DataHolder.currentRigProfile = RigStorageManager.loadProfile(this, currentCharacterId);
        }

        lvParts = findViewById(R.id.lvParts);
        tvSelectedPart = findViewById(R.id.tvSelectedPart);
        btnChangePose = findViewById(R.id.btnChangePose);
        btnChangePose.setText("POSE: " + DataHolder.currentPose);

        FrameLayout container = findViewById(R.id.previewContainer);
        adjustPreviewView = new AdjustPreviewView(this, null);
        container.addView(adjustPreviewView, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, 
            FrameLayout.LayoutParams.MATCH_PARENT
        ));

        adapter = new AdjustmentAdapter(this, DataHolder.currentRigProfile.getRawSlots());
        lvParts.setAdapter(adapter);

        lvParts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                adapter.setSelectedIndex(position);
                BoneSlot selected = adapter.getSelectedSlot();
                if (selected != null) {
                    tvSelectedPart.setText("EDITING: " + selected.getDisplayName().toUpperCase());
                }
            }
        });

        btnChangePose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] poses = {"Pose 1 (Front)", "Pose 2", "Pose 3 (Side)", "Pose 4", "Pose 5 (Back)"};
                new AlertDialog.Builder(AdjustmentActivity.this).setTitle("Change Pose").setItems(poses, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        DataHolder.currentPose = which + 1;
                        btnChangePose.setText("POSE: " + DataHolder.currentPose);
                        adjustPreviewView.invalidate();
                    }
                }).show();
            }
        });

        findViewById(R.id.btnImportSkin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (adapter.getSelectedSlot() == null) {
                    Toast.makeText(AdjustmentActivity.this, "Pehle ek part select karein jisme skin lagani hai!", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent intent = new Intent(Intent.ACTION_PICK); 
                intent.setType("image/*"); 
                startActivityForResult(intent, PICK_SKIN_CODE);
            }
        });

        findViewById(R.id.btnLayerUp).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { changeLayerOrder(1); }
        });
        findViewById(R.id.btnLayerDown).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { changeLayerOrder(-1); }
        });

        findViewById(R.id.btnUp).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { moveSelectedPart(0, -moveStep); }
        });
        findViewById(R.id.btnDown).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { moveSelectedPart(0, moveStep); }
        });
        findViewById(R.id.btnLeft).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { moveSelectedPart(-moveStep, 0); }
        });
        findViewById(R.id.btnRight).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { moveSelectedPart(moveStep, 0); }
        });

        findViewById(R.id.btnScalePlus).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { scaleSelectedPart(scaleStep); }
        });
        findViewById(R.id.btnScaleMinus).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { scaleSelectedPart(-scaleStep); }
        });

        final Button btnAspectLock = findViewById(R.id.btnAspectLock);
        btnAspectLock.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                BoneSlot slot = adapter.getSelectedSlot();
                if (slot != null) {
                    slot.setAspectLocked(!slot.isAspectLocked());
                    btnAspectLock.setBackgroundColor(slot.isAspectLocked() ? Color.parseColor("#FF9800") : Color.parseColor("#9E9E9E"));
                    adapter.notifyDataSetChanged();
                }
            }
        });

        findViewById(R.id.btnResetPart).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                BoneSlot slot = adapter.getSelectedSlot();
                if (slot != null) {
                    slot.resetAdjustment();
                    slot.setCustomImagePath(null); 
                    adjustPreviewView.clearSkinCache(slot.getSlotId());
                    adjustPreviewView.invalidate();
                    Toast.makeText(AdjustmentActivity.this, slot.getDisplayName() + " Reset Done", Toast.LENGTH_SHORT).show();
                }
            }
        });

        findViewById(R.id.btnResetAll).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                new AlertDialog.Builder(AdjustmentActivity.this)
                    .setTitle("Reset All Parts?")
                    .setMessage("Kya aap saari editing aur custom skins hatakar wapas normal karna chahte hain?")
                    .setPositiveButton("Haan", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            DataHolder.currentRigProfile.resetAll();
                            for (BoneSlot s : DataHolder.currentRigProfile.getRawSlots()) {
                                s.setCustomImagePath(null);
                            }
                            adjustPreviewView.clearAllSkinCache();
                            adapter.notifyDataSetChanged();
                            adjustPreviewView.invalidate();
                            Toast.makeText(AdjustmentActivity.this, "Character Reset Successful", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            }
        });

        findViewById(R.id.btnSaveExit).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                RigStorageManager.saveProfile(AdjustmentActivity.this, DataHolder.currentRigProfile, currentCharacterId);
                Toast.makeText(AdjustmentActivity.this, "Saved Permanently!", Toast.LENGTH_LONG).show();
                finish(); 
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_SKIN_CODE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try { 
                Bitmap bmp = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData());
                BoneSlot slot = adapter.getSelectedSlot();
                if (slot != null) {
                    String savedPath = CharacterStorage.saveBitmapInternal(this, bmp, "Skin_" + slot.getSlotId());
                    if (savedPath != null) {
                        slot.setCustomImagePath(savedPath);
                        adjustPreviewView.clearSkinCache(slot.getSlotId()); 
                        adjustPreviewView.invalidate();
                        Toast.makeText(this, slot.getDisplayName() + " Skin Updated!", Toast.LENGTH_SHORT).show();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void changeLayerOrder(int changeAmount) {
        BoneSlot slot = adapter.getSelectedSlot();
        if (slot == null) return;
        slot.setZOrder(slot.getZOrder() + changeAmount);
        adapter.notifyDataSetChanged(); 
        adjustPreviewView.invalidate(); 
    }

    private void moveSelectedPart(float dx, float dy) {
        BoneSlot slot = adapter.getSelectedSlot();
        if (slot == null) return;
        slot.setOffsetX(slot.getOffsetX() + dx);
        slot.setOffsetY(slot.getOffsetY() + dy);
        adjustPreviewView.invalidate(); 
    }

    private void scaleSelectedPart(float dScale) {
        BoneSlot slot = adapter.getSelectedSlot();
        if (slot == null) return;
        if (slot.isAspectLocked()) {
            slot.setScaleX(slot.getScaleX() + dScale);
            slot.setScaleY(slot.getScaleY() + dScale);
        } else {
            slot.setScaleX(slot.getScaleX() + dScale);
        }
        adjustPreviewView.invalidate();
    }
}
