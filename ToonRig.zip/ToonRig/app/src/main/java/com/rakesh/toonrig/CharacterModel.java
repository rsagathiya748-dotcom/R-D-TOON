package com.rakesh.toonrig;

import android.graphics.Bitmap;

public class CharacterModel {
    public static final int TYPE_FREE = 0;
    public static final int TYPE_PRO = 1;
    public static final int TYPE_CUSTOM = 2;

    private String name;
    private int resId = -1;
    private String filePath = null;
    private int type;
    private int version = 1; // 🔥 NAYA: Version tracking ke liye
    private boolean isSelected = false;
    private Bitmap thumbnail = null; 

    // 1. App ke default characters ke liye constructor 
    public CharacterModel(String name, int resId, int type) {
        this.name = name;
        this.resId = resId;
        this.type = type;
        this.version = 1; // Default version 1
    }

    // 2. Custom characters ke liye constructor (isme version pass karenge)
    public CharacterModel(String name, String filePath, int type, int version) {
        this.name = name;
        this.filePath = filePath;
        this.type = type;
        this.version = version; // 🔥 NAYA: Version set ho raha hai
    }

    // Saare Getters aur Setters
    public String getName() { 
        return name; 
    }
    
    public void setName(String name) { 
        this.name = name; 
    }

    public int getResId() { 
        return resId; 
    }

    public String getFilePath() { 
        return filePath; 
    }

    public int getType() { 
        return type; 
    }

    public boolean isCustom() { 
        return type == TYPE_CUSTOM; 
    }

    // 🔥 NAYA: Getter for Version
    public int getVersion() {
        return version;
    }

    public boolean isSelected() { 
        return isSelected; 
    }

    public void setSelected(boolean selected) { 
        isSelected = selected; 
    }

    // ==================== ADAPTER KE LIYE THUMBNAIL METHODS ====================
    public Bitmap getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(Bitmap thumbnail) {
        this.thumbnail = thumbnail;
    }
}
