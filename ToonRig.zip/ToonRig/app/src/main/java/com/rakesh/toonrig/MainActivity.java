package com.rakesh.toonrig;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator; 

// PERMISSION KE LIYE NAYE IMPORTS
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;

public class MainActivity extends Activity {
    private CharacterSheetView csv;
    private Button btnCharacters, btnShowMap, btnPose, btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main); 

        csv = (CharacterSheetView) findViewById(R.id.characterSheetView);
        btnCharacters = (Button) findViewById(R.id.btnCharacters);
        btnShowMap = (Button) findViewById(R.id.btnShowMap);
        btnPose = (Button) findViewById(R.id.btnPose);
        btnNext = (Button) findViewById(R.id.btnNext);

        // AB SEEDHA DOWNLOAD NAHI HOGA, PEHLE PERMISSION CHECK HOGI
        checkPermissionsAndDownload();

        btnCharacters.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, CharacterSelectionActivity.class)); }
        });

        btnShowMap.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { csv.setShowMapping(!csv.isShowMap()); }
        });

        btnPose.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showPoseDialog(); }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                cropAndCalculateRigging();
                startActivity(new Intent(MainActivity.this, HubActivity.class));
            }
        });
        
        if (DataHolder.selectedResId == -1 && DataHolder.selectedCustomPath == null) {
            DataHolder.selectedResId = R.drawable.character_sheet;
        }
    }

    // ========================================================
    // NAYA METHOD: PERMISSION MANGNE KE LIYE
    // ========================================================
    private void checkPermissionsAndDownload() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                // Agar permission nahi hai, toh popup show karo
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
                return; 
            }
        }
        // Agar permission pehle se hai toh seedha download start karo
        startDownloading();
    }

    // Jab user popup me 'Allow' dabayega toh ye method chalega
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 100 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startDownloading(); 
        } else {
            Toast.makeText(this, "Storage Permission Required for Updates!", Toast.LENGTH_LONG).show();
        }
    }

    private void startDownloading() {
        checkForNewCharactersOnline();
        checkForNewAnimationsOnline();
    }
    // ========================================================

    private void checkForNewCharactersOnline() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String jsonUrl = "https://raw.githubusercontent.com/rsagathiya748-dotcom/toonrig-data/main/characters.json";
                    URL url = new URL(jsonUrl);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);
                    
                    InputStream in = new BufferedInputStream(conn.getInputStream());
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line);
                    reader.close();
                    
                    JSONArray jsonArray = new JSONArray(sb.toString());
                    ArrayList<CharacterModel> existingChars = CharacterStorage.getCustomCharacters(MainActivity.this);
                    
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        final String charName = obj.getString("name");
                        String imgUrl = obj.getString("url");
                        
                        boolean exists = false;
                        for (CharacterModel c : existingChars) { if (c.getName().equals(charName)) { exists = true; break; } }
                        
                        if (!exists) {
                            URL iUrl = new URL(imgUrl);
                            Bitmap bitmap = BitmapFactory.decodeStream(iUrl.openConnection().getInputStream());
                            String savedPath = CharacterStorage.saveBitmapInternal(MainActivity.this, bitmap, "Online_" + charName.replace(" ", ""));
                            if (savedPath != null) {
                                CharacterStorage.addCustomCharacter(MainActivity.this, charName, savedPath,0,1);
                                runOnUiThread(new Runnable() {
                                    @Override public void run() { Toast.makeText(MainActivity.this, "New Character Downloaded: " + charName, Toast.LENGTH_LONG).show(); }
                                });
                            }
                        }
                    }
                } catch (Exception e) { e.printStackTrace(); }
            }
        }).start();
    }

    private void checkForNewAnimationsOnline() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String jsonUrl = "https://raw.githubusercontent.com/rsagathiya748-dotcom/toonrig-data/main/animations.json";
                    URL url = new URL(jsonUrl);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(5000);
                    
                    InputStream in = new BufferedInputStream(conn.getInputStream());
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line);
                    reader.close();
                    
                    JSONObject onlineAnimations = new JSONObject(sb.toString());
                    JSONObject localAnimations = AnimationStorage.readRootObject();
                    boolean isNewAdded = false;
                    
                    Iterator<String> keys = onlineAnimations.keys();
                    while(keys.hasNext()) {
                        final String animName = keys.next();
                        
                        if(!localAnimations.has(animName)) {
                            localAnimations.put(animName, onlineAnimations.getJSONObject(animName));
                            isNewAdded = true;
                            
                            runOnUiThread(new Runnable() {
                                @Override public void run() { 
                                    Toast.makeText(MainActivity.this, "New Animation Added: " + animName, Toast.LENGTH_LONG).show(); 
                                }
                            });
                        }
                    }
                    
                    if(isNewAdded) {
                        AnimationStorage.writeRootObject(localAnimations);
                    }
                    
                } catch (Exception e) { 
                    e.printStackTrace(); 
                }
            }
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (DataHolder.selectedResId != -1) { csv.setSheetBitmap(BitmapFactory.decodeResource(getResources(), DataHolder.selectedResId)); } 
        else if (DataHolder.selectedCustomPath != null) { csv.setSheetFromFile(DataHolder.selectedCustomPath); }
    }

    private void showPoseDialog() {
        final String[] poses = {"Pose 1", "Pose 2", "Pose 3", "Pose 4", "Pose 5"};
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Select Pose");
        builder.setItems(poses, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
                DataHolder.currentPose = which + 1;
                Toast.makeText(MainActivity.this, poses[which] + " Selected", Toast.LENGTH_SHORT).show();
            }
        });
        builder.show();
    }

    private float[] getRelPoint(float[] crop, float[] bone) {
        float rx = ((bone[0] + (bone[2] / 2f)) - crop[0]) / crop[2];
        float ry = ((bone[1] + (bone[3] / 2f)) - crop[1]) / crop[3];
        return new float[]{rx, ry};
    }

    private void cropAndCalculateRigging() {
        float[][] cp = CharacterSheetView.cropParts;
        float[][] bp = CharacterSheetView.boneParts;

        for (int i = 0; i < cp.length; i++) {
            DataHolder.parts[i] = csv.getCroppedPart(i);
        }

        for (int p = 0; p < 5; p++) {
            int bOff = p * 22; 
            DataHolder.relBones[bOff + 0] = getRelPoint(cp[5+p], bp[bOff+0]);  
            DataHolder.relBones[bOff + 1] = getRelPoint(cp[0+p], bp[bOff+1]);  
            DataHolder.relBones[bOff + 2] = getRelPoint(cp[5+p], bp[bOff+2]);  
            DataHolder.relBones[bOff + 3] = getRelPoint(cp[10+p], bp[bOff+3]); 
            DataHolder.relBones[bOff + 4] = getRelPoint(cp[10+p], bp[bOff+4]); 
            DataHolder.relBones[bOff + 5] = getRelPoint(cp[20+p], bp[bOff+5]); 
            
            DataHolder.relBones[bOff + 6] = getRelPoint(cp[5+p], bp[bOff+6]);  
            DataHolder.relBones[bOff + 7] = getRelPoint(cp[15+p], bp[bOff+7]); 
            DataHolder.relBones[bOff + 8] = getRelPoint(cp[15+p], bp[bOff+8]); 
            DataHolder.relBones[bOff + 9] = getRelPoint(cp[25+p], bp[bOff+9]); 
            
            DataHolder.relBones[bOff + 10] = getRelPoint(cp[5+p], bp[bOff+10]);
            DataHolder.relBones[bOff + 11] = getRelPoint(cp[30+p], bp[bOff+11]);
            DataHolder.relBones[bOff + 12] = getRelPoint(cp[30+p], bp[bOff+12]);
            DataHolder.relBones[bOff + 13] = getRelPoint(cp[40+p], bp[bOff+13]);
            DataHolder.relBones[bOff + 14] = getRelPoint(cp[40+p], bp[bOff+14]);
            DataHolder.relBones[bOff + 15] = getRelPoint(cp[50+p], bp[bOff+15]);
            
            DataHolder.relBones[bOff + 16] = getRelPoint(cp[5+p], bp[bOff+16]);
            DataHolder.relBones[bOff + 17] = getRelPoint(cp[35+p], bp[bOff+17]);
            DataHolder.relBones[bOff + 18] = getRelPoint(cp[35+p], bp[bOff+18]);
            DataHolder.relBones[bOff + 19] = getRelPoint(cp[45+p], bp[bOff+19]);
            DataHolder.relBones[bOff + 20] = getRelPoint(cp[45+p], bp[bOff+20]);
            DataHolder.relBones[bOff + 21] = getRelPoint(cp[55+p], bp[bOff+21]);
        }
    }
}
