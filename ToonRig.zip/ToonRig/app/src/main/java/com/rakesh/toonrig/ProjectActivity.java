package com.rakesh.toonrig;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup; 
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ProjectActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#E0E0E0"));
        root.setPadding(50, 50, 50, 50);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Human Projects");
        tvTitle.setTextColor(Color.BLACK);
        tvTitle.setTextSize(26);
        root.addView(tvTitle);

        // NEW PROJECT BUTTON
        Button btnNew = new Button(this);
        btnNew.setText("➕ NEW PROJECT");
        btnNew.setTextSize(20);
        btnNew.setBackgroundColor(Color.parseColor("#E91E63"));
        btnNew.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams lpNew = new LinearLayout.LayoutParams(500, 150);
        lpNew.setMargins(0, 40, 0, 60);
        btnNew.setLayoutParams(lpNew);
        
        btnNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProjectEngine.clearDraft(ProjectActivity.this);
                if (DataHolder.sceneCharacters != null) DataHolder.sceneCharacters.clear();
                startActivity(new Intent(ProjectActivity.this, CharacterSelectionActivity.class));
            }
        });
        root.addView(btnNew);

        // RECENT PROJECT LIST
        SharedPreferences prefs = getSharedPreferences("ToonRigApp", MODE_PRIVATE);
        if (prefs.getBoolean("has_draft", false)) {
            Button btnSaved = new Button(this);
            btnSaved.setText("📁 Saved Draft Project (Tap to Open)");
            btnSaved.setBackgroundColor(Color.parseColor("#4CAF50"));
            btnSaved.setTextColor(Color.WHITE);
            btnSaved.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 150));
            
            btnSaved.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ProjectEngine.loadAutoSave(ProjectActivity.this);
                    startActivity(new Intent(ProjectActivity.this, HubActivity.class));
                }
            });
            root.addView(btnSaved);
        }

        setContentView(root);
    }
}
