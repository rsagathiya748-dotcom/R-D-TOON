package com.rakesh.toonrig;

import org.json.JSONException;
import org.json.JSONObject;

public class BoneSlot {
    private String slotId;
    private String displayName;
    private String customImagePath; 
    
    private float offsetX = 0f;
    private float offsetY = 0f;
    private float scaleX = 1f;
    private float scaleY = 1f;
    
    private boolean aspectLocked = true;
    private boolean isLocked = false;
    private int zOrder = 0;

    public BoneSlot(String slotId, String displayName, int zOrder) {
        this.slotId = slotId;
        this.displayName = displayName;
        this.zOrder = zOrder;
    }

    public void resetAdjustment() {
        this.offsetX = 0f;
        this.offsetY = 0f;
        this.scaleX = 1f;
        this.scaleY = 1f;
    }

    public JSONObject toJsonObject() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("slotId", slotId);
        obj.put("customImagePath", customImagePath == null ? "" : customImagePath);
        obj.put("offsetX", (double) offsetX);
        obj.put("offsetY", (double) offsetY);
        obj.put("scaleX", (double) scaleX);
        obj.put("scaleY", (double) scaleY);
        obj.put("aspectLocked", aspectLocked);
        obj.put("isLocked", isLocked);
        obj.put("zOrder", zOrder);
        return obj;
    }

    public static BoneSlot fromJsonObject(JSONObject obj) throws JSONException {
        BoneSlot slot = new BoneSlot(obj.getString("slotId"), obj.optString("slotId", "Part"), obj.optInt("zOrder", 0));
        String path = obj.optString("customImagePath", "");
        slot.setCustomImagePath(path.isEmpty() ? null : path);
        slot.setOffsetX((float) obj.optDouble("offsetX", 0.0));
        slot.setOffsetY((float) obj.optDouble("offsetY", 0.0));
        slot.setScaleX((float) obj.optDouble("scaleX", 1.0));
        slot.setScaleY((float) obj.optDouble("scaleY", 1.0));
        slot.setAspectLocked(obj.optBoolean("aspectLocked", true));
        slot.setLocked(obj.optBoolean("isLocked", false));
        return slot;
    }

    public String getSlotId() { return slotId; }
    public String getDisplayName() { return displayName; }
    public String getCustomImagePath() { return customImagePath; }
    public void setCustomImagePath(String customImagePath) { this.customImagePath = customImagePath; }
    public float getOffsetX() { return offsetX; }
    public void setOffsetX(float offsetX) { this.offsetX = offsetX; }
    public float getOffsetY() { return offsetY; }
    public void setOffsetY(float offsetY) { this.offsetY = offsetY; }
    public float getScaleX() { return scaleX; }
    public void setScaleX(float scaleX) { this.scaleX = scaleX; }
    public float getScaleY() { return scaleY; }
    public void setScaleY(float scaleY) { this.scaleY = scaleY; }
    public boolean isAspectLocked() { return aspectLocked; }
    public void setAspectLocked(boolean aspectLocked) { this.aspectLocked = aspectLocked; }
    public boolean isLocked() { return isLocked; }
    public void setLocked(boolean locked) { isLocked = locked; }
    public int getZOrder() { return zOrder; }
    public void setZOrder(int zOrder) { this.zOrder = zOrder; }
}
