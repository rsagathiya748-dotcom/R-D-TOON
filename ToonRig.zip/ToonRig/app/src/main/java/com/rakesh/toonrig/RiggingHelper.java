package com.rakesh.toonrig;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class RiggingHelper {
    
    public static SceneCharacter createCharacter(Context context, String name, int resId, String customPath) {
        SceneCharacter sc = new SceneCharacter(name);
        Bitmap sheet = null;
        try {
            if (customPath != null) {
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = 2; // Memory bachane ke liye
                sheet = BitmapFactory.decodeFile(customPath, opts);
            } else {
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inScaled = false;
                sheet = BitmapFactory.decodeResource(context.getResources(), resId, opts);
            }
        } catch (Exception e) { e.printStackTrace(); }

        if (sheet == null) return sc;

        float[][] cp = CharacterSheetView.cropParts;
        float[][] bp = CharacterSheetView.boneParts;
        int w = sheet.getWidth();
        int h = sheet.getHeight();

        // 60 Parts ki Cropping
        for (int i = 0; i < cp.length; i++) {
            int cx = (int)(cp[i][0] * w);
            int cy = (int)(cp[i][1] * h);
            int cw = (int)(cp[i][2] * w);
            int ch = (int)(cp[i][3] * h);
            
            if(cx < 0) cx = 0; if(cy < 0) cy = 0;
            if(cx + cw > w) cw = w - cx;
            if(cy + ch > h) ch = h - cy;
            
            if (cw > 0 && ch > 0) {
                sc.parts[i] = Bitmap.createBitmap(sheet, cx, cy, cw, ch);
            }
        }

        // 110 Bones ki Joint Mapping
        for (int p = 0; p < 5; p++) {
            int bOff = p * 22;
            sc.relBones[bOff + 0] = getRelPoint(cp[5+p], bp[bOff+0]);
            sc.relBones[bOff + 1] = getRelPoint(cp[0+p], bp[bOff+1]);  
            sc.relBones[bOff + 2] = getRelPoint(cp[5+p], bp[bOff+2]);  
            sc.relBones[bOff + 3] = getRelPoint(cp[10+p], bp[bOff+3]); 
            sc.relBones[bOff + 4] = getRelPoint(cp[10+p], bp[bOff+4]); 
            sc.relBones[bOff + 5] = getRelPoint(cp[20+p], bp[bOff+5]); 
            sc.relBones[bOff + 6] = getRelPoint(cp[5+p], bp[bOff+6]);  
            sc.relBones[bOff + 7] = getRelPoint(cp[15+p], bp[bOff+7]); 
            sc.relBones[bOff + 8] = getRelPoint(cp[15+p], bp[bOff+8]); 
            sc.relBones[bOff + 9] = getRelPoint(cp[25+p], bp[bOff+9]); 
            sc.relBones[bOff + 10] = getRelPoint(cp[5+p], bp[bOff+10]);
            sc.relBones[bOff + 11] = getRelPoint(cp[30+p], bp[bOff+11]);
            sc.relBones[bOff + 12] = getRelPoint(cp[30+p], bp[bOff+12]);
            sc.relBones[bOff + 13] = getRelPoint(cp[40+p], bp[bOff+13]);
            sc.relBones[bOff + 14] = getRelPoint(cp[40+p], bp[bOff+14]);
            sc.relBones[bOff + 15] = getRelPoint(cp[50+p], bp[bOff+15]);
            sc.relBones[bOff + 16] = getRelPoint(cp[5+p], bp[bOff+16]);
            sc.relBones[bOff + 17] = getRelPoint(cp[35+p], bp[bOff+17]);
            sc.relBones[bOff + 18] = getRelPoint(cp[35+p], bp[bOff+18]);
            sc.relBones[bOff + 19] = getRelPoint(cp[45+p], bp[bOff+19]);
            sc.relBones[bOff + 20] = getRelPoint(cp[45+p], bp[bOff+20]);
            sc.relBones[bOff + 21] = getRelPoint(cp[55+p], bp[bOff+21]);
        }
        
        // Character ki custom Skin Profile Load karna
        String profileId = (customPath != null) ? customPath : "char_res_" + resId;
        sc.rigProfile = RigStorageManager.loadProfile(context, profileId);
        sc.zOrder = DataHolder.sceneCharacters.size(); // Naya character hamesha aage aayega
        
        return sc;
    }

    private static float[] getRelPoint(float[] crop, float[] bone) {
        float rx = ((bone[0] + (bone[2] / 2f)) - crop[0]) / crop[2];
        float ry = ((bone[1] + (bone[3] / 2f)) - crop[1]) / crop[3];
        return new float[]{rx, ry};
    }
}
