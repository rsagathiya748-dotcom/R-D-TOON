package com.rakesh.toonrig;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CharacterRigProfile {
    private String profileId;
    private List<BoneSlot> slots;

    public CharacterRigProfile(String profileId) {
        this.profileId = profileId;
        this.slots = new ArrayList<>();
        initDefaultSlots();
    }

    private void initDefaultSlots() {
        slots.add(new BoneSlot("head", "Head", 12));
        slots.add(new BoneSlot("torso", "Torso", 5));
        slots.add(new BoneSlot("r_arm_top", "R-Arm Top", 2));
        slots.add(new BoneSlot("r_arm_bot", "R-Arm Bot", 1));
        slots.add(new BoneSlot("l_arm_top", "L-Arm Top", 11));
        slots.add(new BoneSlot("l_arm_bot", "L-Arm Bot", 10));
        slots.add(new BoneSlot("r_leg_top", "R-Leg Top", 4));
        slots.add(new BoneSlot("r_leg_bot", "R-Leg Bot", 3));
        slots.add(new BoneSlot("r_foot", "R-Foot", 2));
        slots.add(new BoneSlot("l_leg_top", "L-Leg Top", 9));
        slots.add(new BoneSlot("l_leg_bot", "L-Leg Bot", 8));
        slots.add(new BoneSlot("l_foot", "L-Foot", 7));
    }

    public List<BoneSlot> getSlotsSortedByZOrder() {
        List<BoneSlot> sortedList = new ArrayList<>(slots);
        Collections.sort(sortedList, new Comparator<BoneSlot>() {
            @Override
            public int compare(BoneSlot a, BoneSlot b) {
                return Integer.compare(a.getZOrder(), b.getZOrder());
            }
        });
        return sortedList;
    }

    public List<BoneSlot> getRawSlots() { return slots; }

    public BoneSlot getSlot(String slotId) {
        for (BoneSlot slot : slots) {
            if (slot.getSlotId().equals(slotId)) return slot;
        }
        return null;
    }

    public void resetAll() {
        for (BoneSlot slot : slots) { slot.resetAdjustment(); }
    }

    public String exportToJson() {
        try {
            JSONObject root = new JSONObject();
            root.put("profileId", profileId);
            JSONArray array = new JSONArray();
            for (BoneSlot slot : slots) { array.put(slot.toJsonObject()); }
            root.put("slots", array);
            return root.toString();
        } catch (Exception e) { return "{}"; }
    }

    public void loadFromJson(String json) {
        try {
            JSONObject root = new JSONObject(json);
            JSONArray array = root.getJSONArray("slots");
            slots.clear();
            for (int i = 0; i < array.length(); i++) {
                slots.add(BoneSlot.fromJsonObject(array.getJSONObject(i)));
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}
