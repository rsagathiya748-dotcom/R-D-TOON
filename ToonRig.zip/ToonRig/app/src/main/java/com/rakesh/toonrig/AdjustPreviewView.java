package com.rakesh.toonrig;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

public class AdjustPreviewView extends View {
    
    private HashMap<String, Bitmap> customSkinCache = new HashMap<>();

    private class DrawItem {
        Bitmap bmp;
        Matrix matrix;
        int zOrder;
        DrawItem(Bitmap b, Matrix m, int z) { this.bmp = b; this.matrix = m; this.zOrder = z; }
    }

    public AdjustPreviewView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void clearSkinCache(String slotId) {
        if (customSkinCache.containsKey(slotId)) customSkinCache.remove(slotId);
    }
    public void clearAllSkinCache() { customSkinCache.clear(); }

    private Bitmap getActualBitmap(BoneSlot slot, Bitmap defaultBmp) {
        if (slot == null) return defaultBmp;
        String path = slot.getCustomImagePath();
        if (path != null && !path.isEmpty()) {
            if (customSkinCache.containsKey(slot.getSlotId())) { return customSkinCache.get(slot.getSlotId()); } 
            else {
                Bitmap customBmp = BitmapFactory.decodeFile(path);
                if (customBmp != null) { customSkinCache.put(slot.getSlotId(), customBmp); return customBmp; }
            }
        }
        return defaultBmp;
    }

    private void applyAdjustments(Matrix m, BoneSlot slot, Bitmap bmp, boolean applyAdjustments) {
        if (applyAdjustments && slot != null && bmp != null) {
            m.preTranslate(slot.getOffsetX(), slot.getOffsetY());
            m.preScale(slot.getScaleX(), slot.getScaleY(), bmp.getWidth() / 2f, bmp.getHeight() / 2f);
        }
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawRig(canvas, false); drawRig(canvas, true);  
    }

    private void drawRig(Canvas canvas, boolean applyAdjustments) {
        SceneCharacter sc = DataHolder.getActiveChar();
        if (sc == null) return;

        int p = sc.currentPose - 1; 
        if (p < 0 || p > 4 || sc.parts[5 + p] == null) return;

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        
        Bitmap defaultTorso = sc.parts[5 + p];
        float baseScale = (getHeight() * 0.45f) / defaultTorso.getHeight();
        
        Matrix baseM = new Matrix();
        baseM.postTranslate(cx - (defaultTorso.getWidth() / 2f), cy - (defaultTorso.getHeight() / 2f));
        baseM.postScale(baseScale, baseScale, cx, cy);
        
        int b = p * 22; 
        float[][] rb = sc.relBones;
        CharacterRigProfile profile = sc.rigProfile;

        List<DrawItem> renderList = new ArrayList<>();

        BoneSlot sTorso = profile.getSlot("torso");
        Bitmap torso = getActualBitmap(sTorso, sc.parts[5 + p]);
        Matrix mTorso = new Matrix(baseM);
        applyAdjustments(mTorso, sTorso, torso, applyAdjustments);
        if (torso != null) renderList.add(new DrawItem(torso, mTorso, sTorso.getZOrder()));

        BoneSlot sHead = profile.getSlot("head");
        Bitmap head = getActualBitmap(sHead, sc.parts[0 + p]);
        Matrix mHead = new Matrix(mTorso);
        mHead.preTranslate(defaultTorso.getWidth() * rb[b+0][0], defaultTorso.getHeight() * rb[b+0][1]);
        if(head != null) mHead.preTranslate(-(head.getWidth() * rb[b+1][0]), -(head.getHeight() * rb[b+1][1]));
        applyAdjustments(mHead, sHead, head, applyAdjustments);
        if (head != null) renderList.add(new DrawItem(head, mHead, sHead.getZOrder()));

        BoneSlot sRArmT = profile.getSlot("r_arm_top");
        Bitmap rArmT = getActualBitmap(sRArmT, sc.parts[10 + p]);
        Matrix mRArmT = new Matrix(mTorso);
        mRArmT.preTranslate(defaultTorso.getWidth() * rb[b+2][0], defaultTorso.getHeight() * rb[b+2][1]);
        if(rArmT != null) mRArmT.preTranslate(-(rArmT.getWidth() * rb[b+3][0]), -(rArmT.getHeight() * rb[b+3][1]));
        applyAdjustments(mRArmT, sRArmT, rArmT, applyAdjustments);
        if (rArmT != null) renderList.add(new DrawItem(rArmT, mRArmT, sRArmT.getZOrder()));

        BoneSlot sRArmB = profile.getSlot("r_arm_bot");
        Bitmap rArmB = getActualBitmap(sRArmB, sc.parts[20 + p]);
        Matrix mRArmB = new Matrix(mRArmT);
        if(rArmT != null) mRArmB.preTranslate(rArmT.getWidth() * rb[b+4][0], rArmT.getHeight() * rb[b+4][1]);
        if(rArmB != null) mRArmB.preTranslate(-(rArmB.getWidth() * rb[b+5][0]), -(rArmB.getHeight() * rb[b+5][1]));
        applyAdjustments(mRArmB, sRArmB, rArmB, applyAdjustments);
        if (rArmB != null) renderList.add(new DrawItem(rArmB, mRArmB, sRArmB.getZOrder()));

        BoneSlot sLArmT = profile.getSlot("l_arm_top");
        Bitmap lArmT = getActualBitmap(sLArmT, sc.parts[15 + p]);
        Matrix mLArmT = new Matrix(mTorso);
        mLArmT.preTranslate(defaultTorso.getWidth() * rb[b+6][0], defaultTorso.getHeight() * rb[b+6][1]);
        if(lArmT != null) mLArmT.preTranslate(-(lArmT.getWidth() * rb[b+7][0]), -(lArmT.getHeight() * rb[b+7][1]));
        applyAdjustments(mLArmT, sLArmT, lArmT, applyAdjustments);
        if (lArmT != null) renderList.add(new DrawItem(lArmT, mLArmT, sLArmT.getZOrder()));

        BoneSlot sLArmB = profile.getSlot("l_arm_bot");
        Bitmap lArmB = getActualBitmap(sLArmB, sc.parts[25 + p]);
        Matrix mLArmB = new Matrix(mLArmT);
        if(lArmT != null) mLArmB.preTranslate(lArmT.getWidth() * rb[b+8][0], lArmT.getHeight() * rb[b+8][1]);
        if(lArmB != null) mLArmB.preTranslate(-(lArmB.getWidth() * rb[b+9][0]), -(lArmB.getHeight() * rb[b+9][1]));
        applyAdjustments(mLArmB, sLArmB, lArmB, applyAdjustments);
        if (lArmB != null) renderList.add(new DrawItem(lArmB, mLArmB, sLArmB.getZOrder()));

        BoneSlot sRLegT = profile.getSlot("r_leg_top");
        Bitmap rLegT = getActualBitmap(sRLegT, sc.parts[30 + p]);
        Matrix mRLegT = new Matrix(mTorso);
        mRLegT.preTranslate(defaultTorso.getWidth() * rb[b+10][0], defaultTorso.getHeight() * rb[b+10][1]);
        if(rLegT != null) mRLegT.preTranslate(-(rLegT.getWidth() * rb[b+11][0]), -(rLegT.getHeight() * rb[b+11][1]));
        applyAdjustments(mRLegT, sRLegT, rLegT, applyAdjustments);
        if (rLegT != null) renderList.add(new DrawItem(rLegT, mRLegT, sRLegT.getZOrder()));

        BoneSlot sRLegB = profile.getSlot("r_leg_bot");
        Bitmap rLegB = getActualBitmap(sRLegB, sc.parts[40 + p]);
        Matrix mRLegB = new Matrix(mRLegT);
        if(rLegT != null) mRLegB.preTranslate(rLegT.getWidth() * rb[b+12][0], rLegT.getHeight() * rb[b+12][1]);
        if(rLegB != null) mRLegB.preTranslate(-(rLegB.getWidth() * rb[b+13][0]), -(rLegB.getHeight() * rb[b+13][1]));
        applyAdjustments(mRLegB, sRLegB, rLegB, applyAdjustments);
        if (rLegB != null) renderList.add(new DrawItem(rLegB, mRLegB, sRLegB.getZOrder()));

        BoneSlot sRFoot = profile.getSlot("r_foot");
        Bitmap rPalm = getActualBitmap(sRFoot, sc.parts[50 + p]);
        Matrix mRFoot = new Matrix(mRLegB);
        if(rLegB != null) mRFoot.preTranslate(rLegB.getWidth() * rb[b+14][0], rLegB.getHeight() * rb[b+14][1]);
        if(rPalm != null) mRFoot.preTranslate(-(rPalm.getWidth() * rb[b+15][0]), -(rPalm.getHeight() * rb[b+15][1]));
        applyAdjustments(mRFoot, sRFoot, rPalm, applyAdjustments);
        if (rPalm != null) renderList.add(new DrawItem(rPalm, mRFoot, sRFoot.getZOrder()));

        BoneSlot sLLegT = profile.getSlot("l_leg_top");
        Bitmap lLegT = getActualBitmap(sLLegT, sc.parts[35 + p]);
        Matrix mLLegT = new Matrix(mTorso);
        mLLegT.preTranslate(defaultTorso.getWidth() * rb[b+16][0], defaultTorso.getHeight() * rb[b+16][1]);
        if(lLegT != null) mLLegT.preTranslate(-(lLegT.getWidth() * rb[b+17][0]), -(lLegT.getHeight() * rb[b+17][1]));
        applyAdjustments(mLLegT, sLLegT, lLegT, applyAdjustments);
        if (lLegT != null) renderList.add(new DrawItem(lLegT, mLLegT, sLLegT.getZOrder()));

        BoneSlot sLLegB = profile.getSlot("l_leg_bot");
        Bitmap lLegB = getActualBitmap(sLLegB, sc.parts[45 + p]);
        Matrix mLLegB = new Matrix(mLLegT);
        if(lLegT != null) mLLegB.preTranslate(lLegT.getWidth() * rb[b+18][0], lLegT.getHeight() * rb[b+18][1]);
        if(lLegB != null) mLLegB.preTranslate(-(lLegB.getWidth() * rb[b+19][0]), -(lLegB.getHeight() * rb[b+19][1]));
        applyAdjustments(mLLegB, sLLegB, lLegB, applyAdjustments);
        if (lLegB != null) renderList.add(new DrawItem(lLegB, mLLegB, sLLegB.getZOrder()));

        BoneSlot sLFoot = profile.getSlot("l_foot");
        Bitmap lPalm = getActualBitmap(sLFoot, sc.parts[55 + p]);
        Matrix mLFoot = new Matrix(mLLegB);
        if(lLegB != null) mLFoot.preTranslate(lLegB.getWidth() * rb[b+20][0], lLegB.getHeight() * rb[b+20][1]);
        if(lPalm != null) mLFoot.preTranslate(-(lPalm.getWidth() * rb[b+21][0]), -(lPalm.getHeight() * rb[b+21][1]));
        applyAdjustments(mLFoot, sLFoot, lPalm, applyAdjustments);
        if (lPalm != null) renderList.add(new DrawItem(lPalm, mLFoot, sLFoot.getZOrder()));

        Collections.sort(renderList, new Comparator<DrawItem>() {
            @Override public int compare(DrawItem d1, DrawItem d2) {
                return Integer.compare(d1.zOrder, d2.zOrder);
            }
        });

        Paint pnt = new Paint(); pnt.setFilterBitmap(true); pnt.setAntiAlias(true);
        if (!applyAdjustments) { pnt.setAlpha(60); } else { pnt.setAlpha(255); }

        for (DrawItem item : renderList) { canvas.drawBitmap(item.bmp, item.matrix, pnt); }
    }
}
