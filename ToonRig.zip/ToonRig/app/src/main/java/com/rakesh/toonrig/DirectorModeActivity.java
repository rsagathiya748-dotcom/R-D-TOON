package com.rakesh.toonrig;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.util.ArrayList;

public class DirectorModeActivity extends Activity {

    private PreviewView directorPreviewView;
    private Button btnDirBack, btnDirCamera, btnDirFlip, btnDirSpeed;
    private Button btnDirRewind, btnDirPlayPause, btnDirRecord;
    private View topDirectorBar;

    private boolean isRecording = false;
    private boolean isPlaying = false; 
    private static final int REC_CODE = 1000;
    public static int selectedQualityIndex = 1;
    
    private int currentMoveMode = PreviewView.MODE_CHAR; 
    private ScaleGestureDetector scaleGestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            setContentView(R.layout.activity_director_mode);

            topDirectorBar = findViewById(R.id.topDirectorBar);
            directorPreviewView = findViewById(R.id.directorPreviewView);
            
            btnDirBack = findViewById(R.id.btnDirBack);
            btnDirCamera = findViewById(R.id.btnDirCamera);
            btnDirFlip = findViewById(R.id.btnDirFlip);
            btnDirSpeed = findViewById(R.id.btnDirSpeed);
            btnDirRewind = findViewById(R.id.btnDirRewind);
            btnDirPlayPause = findViewById(R.id.btnDirPlayPause); 
            btnDirRecord = findViewById(R.id.btnDirRecord);

            if (DataHolder.bgBitmap != null) {
                directorPreviewView.setBackgroundReference(DataHolder.bgBitmap);
            } else {
                directorPreviewView.setChromaColor(DataHolder.bgColor);
                directorPreviewView.setBackgroundColor(DataHolder.bgColor);
            }

            // ANIMATION CHAIN LOAD LOGIC
            loadSelectedAnimations();
            
            directorPreviewView.setFrameManualForAll(0);
            directorPreviewView.invalidate();
            
            scaleGestureDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector detector) {
                    if (currentMoveMode == PreviewView.MODE_CHAR) {
                        SceneCharacter ac = DataHolder.getActiveChar();
                        if (ac != null) {
                            ac.globalScale *= detector.getScaleFactor();
                            directorPreviewView.invalidate();
                        }
                    } else {
                        directorPreviewView.setScaleX(directorPreviewView.getScaleX() * detector.getScaleFactor());
                        directorPreviewView.setScaleY(directorPreviewView.getScaleY() * detector.getScaleFactor());
                    }
                    return true;
                }
            });

            directorPreviewView.setOnTouchListener(new View.OnTouchListener() {
                float startX, startY;
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    scaleGestureDetector.onTouchEvent(event);
                    
                    if (event.getPointerCount() == 1) {
                        switch (event.getAction()) {
                            case MotionEvent.ACTION_DOWN:
                                startX = event.getX();
                                startY = event.getY();
                                break;
                            case MotionEvent.ACTION_MOVE:
                                float dx = event.getX() - startX;
                                float dy = event.getY() - startY;
                                
                                if (currentMoveMode == PreviewView.MODE_CHAR) {
                                    SceneCharacter ac = DataHolder.getActiveChar();
                                    if (ac != null) {
                                        ac.globalX += dx;
                                        ac.globalY += dy;
                                        
                                        if (ac.animationTimelines != null) {
                                            for (java.util.HashMap<Integer, PreviewView.KeyFrame> poseMap : ac.animationTimelines.values()) {
                                                if (poseMap != null) {
                                                    for (PreviewView.KeyFrame kf : poseMap.values()) {
                                                        kf.cX += dx;
                                                        kf.cY += dy;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    directorPreviewView.setTranslationX(directorPreviewView.getTranslationX() + dx);
                                    directorPreviewView.setTranslationY(directorPreviewView.getTranslationY() + dy);
                                }
                                
                                startX = event.getX();
                                startY = event.getY();
                                directorPreviewView.invalidate();
                                break;
                        }
                    }
                    return true; 
                }
            });

            directorPreviewView.setOnFrameChangeListener(new PreviewView.OnFrameChangeListener() {
                @Override
                public void onFrameChanged(int frame) {
                    int lastFrame = directorPreviewView.getLastKeyframeNumber();
                    if (isRecording && lastFrame > 0 && frame >= lastFrame) {
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override public void run() { stopRecordingAuto(); }
                        }, 200);
                    }
                }
            });

            btnDirBack.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { 
                    if (isRecording) stopRecordingAuto(); 
                    finish(); 
                }
            });

            btnDirCamera.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (currentMoveMode == PreviewView.MODE_CHAR) {
                        currentMoveMode = PreviewView.MODE_BG; 
                        btnDirCamera.setText("CAM: ON"); 
                        btnDirCamera.setBackgroundColor(Color.parseColor("#D81B60")); 
                    } else {
                        currentMoveMode = PreviewView.MODE_CHAR; 
                        btnDirCamera.setText("CAM: OFF"); 
                        btnDirCamera.setBackgroundColor(Color.parseColor("#00897B")); 
                    }
                    directorPreviewView.setCurrentMode(currentMoveMode);
                }
            });

            btnDirFlip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { directorPreviewView.toggleFlipX(); }
            });

            btnDirSpeed.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    String[] speeds = {"Slow (0.5x)", "Normal (1x)", "Fast (2x)"};
                    new AlertDialog.Builder(DirectorModeActivity.this).setTitle("Animation Speed").setItems(speeds, new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface dialog, int which) {
                            if (which == 0) directorPreviewView.setAnimSpeedMs(60);
                            else if (which == 1) directorPreviewView.setAnimSpeedMs(30);
                            else if (which == 2) directorPreviewView.setAnimSpeedMs(15);
                        }
                    }).show();
                }
            });

            btnDirRewind.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    directorPreviewView.stopPlaying();
                    directorPreviewView.setFrameManualForAll(0); 
                    directorPreviewView.invalidate();
                    isPlaying = false;
                    btnDirPlayPause.setText("▶ PLAY");
                    btnDirPlayPause.setBackgroundColor(Color.parseColor("#4CAF50")); 
                }
            });

            btnDirPlayPause.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (isPlaying) {
                        directorPreviewView.stopPlaying();
                        isPlaying = false;
                        btnDirPlayPause.setText("▶ PLAY");
                        btnDirPlayPause.setBackgroundColor(Color.parseColor("#4CAF50")); 
                    } else {
                        directorPreviewView.startPlaying();
                        isPlaying = true;
                        btnDirPlayPause.setText("⏸ PAUSE");
                        btnDirPlayPause.setBackgroundColor(Color.parseColor("#FF9800")); 
                    }
                }
            });

            btnDirRecord.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (isRecording) { stopRecordingAuto(); } 
                    else {
                        directorPreviewView.stopPlaying();
                        directorPreviewView.setFrameManualForAll(0);
                        isPlaying = false;
                        btnDirPlayPause.setText("▶ PLAY");
                        btnDirPlayPause.setBackgroundColor(Color.parseColor("#4CAF50"));
                        showQualityMenu();
                    }
                }
            });

        } catch (Exception e) { }
    }

    // 🔥 MASTER FIX: MEGA-TIMELINE STITCHER (ALL POSES SAFE) 🔥
    private void loadSelectedAnimations() {
        try {
            if (DataHolder.sceneCharacters == null) return;
            
            for (int i = 0; i < DataHolder.sceneCharacters.size(); i++) {
                SceneCharacter sc = DataHolder.sceneCharacters.get(i);
                
                // Pehle purani Mega-Timeline saaf kar do
                for (int p = 1; p <= 5; p++) {
                    if (sc.animationTimelines.get(p) != null) sc.animationTimelines.get(p).clear();
                }
                
                if (AnimationSelectionActivity.charAnimChains != null && AnimationSelectionActivity.charAnimChains.containsKey(i)) {
                    java.util.ArrayList<String> chain = AnimationSelectionActivity.charAnimChains.get(i);
                    
                    if (chain != null && !chain.isEmpty()) {
                        int[] lastOffsets = {0, 0, 0, 0, 0, 0}; // Har pose ka alag offset tracking
                        
                        // Chain me jitne bhi animation hain sabko jodo
                        for (int j = 0; j < chain.size(); j++) {
                            String animName = chain.get(j);
                            
                            // HashMap ka istemal karke saare 5 poses ka data ek sath nikalo
                            java.util.HashMap<Integer, java.util.HashMap<Integer, PreviewView.KeyFrame>> loadedAnim = AnimationStorage.loadAnimation(this, animName);
                            
                            if (loadedAnim != null && !loadedAnim.isEmpty()) {
                                int maxFramesInThisAnim = 0;
                                
                                // Har pose ke frames ko shift karke character ki Mega-Timeline me daalo
                                for (int p = 1; p <= 5; p++) {
                                    if (loadedAnim.containsKey(p) && loadedAnim.get(p) != null) {
                                        java.util.HashMap<Integer, PreviewView.KeyFrame> sourceFrames = loadedAnim.get(p);
                                        java.util.HashMap<Integer, PreviewView.KeyFrame> targetFrames = sc.animationTimelines.get(p);
                                        
                                        int currentOffset = lastOffsets[p];
                                        int maxFrameHere = 0;
                                        
                                        for (int frameNo : sourceFrames.keySet()) {
                                            PreviewView.KeyFrame originalKf = sourceFrames.get(frameNo);
                                            
                                            // Puraane frame number me pichle animation ka total joda gaya
                                            int newFrameNo = frameNo + currentOffset;
                                            
                                            // Naya KeyFrame object banaya taaki reference mix na ho
                                            PreviewView.KeyFrame shiftedKf = new PreviewView.KeyFrame(
                                                newFrameNo, originalKf.cX, originalKf.cY, originalKf.hR,
                                                originalKf.hl1, originalKf.hl2, originalKf.hr1, originalKf.hr2,
                                                originalKf.ll1, originalKf.ll2, originalKf.f1, originalKf.lr1,
                                                originalKf.lr2, originalKf.f2
                                            );
                                            shiftedKf.sX = originalKf.sX; shiftedKf.sY = originalKf.sY;
                                            shiftedKf.alp = originalKf.alp; shiftedKf.ease = originalKf.ease;
                                            shiftedKf.kfMeshes = originalKf.kfMeshes; shiftedKf.kfPerspectives = originalKf.kfPerspectives;

                                            targetFrames.put(newFrameNo, shiftedKf);
                                            
                                            if (frameNo > maxFrameHere) maxFrameHere = frameNo;
                                        }
                                        if (maxFrameHere > maxFramesInThisAnim) maxFramesInThisAnim = maxFrameHere;
                                    }
                                }
                                
                                // Agle animation ke liye offset badha do (Taaki agla theek iske khatam hone ke baad shuru ho)
                                for (int p = 1; p <= 5; p++) {
                                    lastOffsets[p] += maxFramesInThisAnim + 1;
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void showQualityMenu() {
        String[] qualityOptions = { "Low (480p)", "SD (720p)", "HD (1080p)", "2K (1440p)", "3K (1620p)", "4K (2160p)" };
        new AlertDialog.Builder(this).setTitle("Choose Export Quality").setItems(qualityOptions, new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    selectedQualityIndex = which;
                    if (topDirectorBar != null) topDirectorBar.setVisibility(View.GONE);

                    if (which <= 2) {
                        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                        startActivityForResult(mpm.createScreenCaptureIntent(), REC_CODE);
                    } else {
                        int height = 1440; int bitrate = 12000000; String qName = "2K";
                        if (which == 3) { height = 1440; bitrate = 12000000; qName = "2K"; }
                        else if (which == 4) { height = 1620; bitrate = 16000000; qName = "3K"; }
                        else if (which == 5) { height = 2160; bitrate = 20000000; qName = "4K"; }
                        
                        DisplayMetrics metrics = new DisplayMetrics(); 
                        getWindowManager().getDefaultDisplay().getMetrics(metrics);
                        float ratio = (float) metrics.widthPixels / metrics.heightPixels;
                        int width = (int) (height * ratio); width = (width / 16) * 16; height = (height / 16) * 16;
                        
                        AnimationExporter.exportVideo(DirectorModeActivity.this, directorPreviewView, width, height, bitrate, qName);
                        if (topDirectorBar != null) topDirectorBar.setVisibility(View.VISIBLE);
                    }
                }
            }).show();
    }

    private void stopRecordingAuto() {
        if (!isRecording) return;
        isRecording = false; 
        btnDirRecord.setText("REC 🔴"); btnDirRecord.setBackgroundColor(Color.parseColor("#D32F2F")); 
        stopService(new Intent(DirectorModeActivity.this, RecordService.class)); 
        directorPreviewView.stopPlaying();
        isPlaying = false;
        btnDirPlayPause.setText("▶ PLAY"); btnDirPlayPause.setBackgroundColor(Color.parseColor("#4CAF50"));
        if (topDirectorBar != null) topDirectorBar.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REC_CODE) {
            if (resultCode == RESULT_OK) {
                isRecording = true; 
                btnDirRecord.setText("STOP ⏹"); btnDirRecord.setBackgroundColor(Color.parseColor("#E91E63")); 
                Intent serviceIntent = new Intent(this, RecordService.class);
                serviceIntent.putExtra("code", resultCode); serviceIntent.putExtra("data", data); serviceIntent.putExtra("quality_index", selectedQualityIndex);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { startForegroundService(serviceIntent); } else { startService(serviceIntent); }
                directorPreviewView.setFrameManualForAll(0); 
                new Handler().postDelayed(new Runnable() { @Override public void run() { btnDirPlayPause.performClick(); } }, 800);
            } else { 
                if (topDirectorBar != null) topDirectorBar.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        ProjectEngine.saveAutoSave(this); 
    }
}
