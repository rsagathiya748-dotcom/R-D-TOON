package com.rakesh.toonrig;

import android.content.Context;
import android.content.SharedPreferences;

public class RigStorageManager {
    private static final String PREF_NAME = "ToonRig_Profiles";

    public static void saveProfile(Context context, CharacterRigProfile profile, String profileKey) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(profileKey, profile.exportToJson()).apply();
    }

    public static CharacterRigProfile loadProfile(Context context, String profileKey) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String json = prefs.getString(profileKey, null);
        CharacterRigProfile profile = new CharacterRigProfile(profileKey);
        if (json != null) {
            profile.loadFromJson(json);
        }
        return profile;
    }
}
