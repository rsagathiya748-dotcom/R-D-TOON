package com.rakesh.toonrig;

import android.content.Context;
import android.os.Environment;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class AnimationStorage {

    // FILE MANAGER ME DOCUMENTS FOLDER KA PATH
    private static File getExternalFile() {
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return new File(dir, "ToonRig_Saved_Animations.json");
    }

    // READ FULL FILE DATA
    public static JSONObject readRootObject() {
        File file = getExternalFile();
        if (!file.exists()) return new JSONObject();
        try {
            FileInputStream fis = new FileInputStream(file);
            byte[] data = new byte[(int) file.length()];
            fis.read(data);
            fis.close();
            return new JSONObject(new String(data, "UTF-8"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    // WRITE FULL FILE DATA
    public static void writeRootObject(JSONObject root) {
        try {
            File file = getExternalFile();
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(root.toString(4).getBytes("UTF-8"));
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // NAYA FUNCTION: JSON KO DIRECT READ KARNE KE LIYE
    public static String loadAnimationRawJson(Context context, String animName) {
        try {
            JSONObject root = readRootObject();
            if (root.has(animName)) {
                return root.getJSONObject(animName).toString();
            }
        } catch (Exception e) {}
        return null;
    }

    // SAVE ANIMATION TO PHONE DOCUMENTS
    public static void saveAnimation(Context ctx, String animName, HashMap<Integer, HashMap<Integer, PreviewView.KeyFrame>> timelines) {
        try {
            JSONObject root = readRootObject();
            JSONObject animObj = new JSONObject();
            
            for (int pose : timelines.keySet()) {
                JSONObject poseObj = new JSONObject();
                HashMap<Integer, PreviewView.KeyFrame> frames = timelines.get(pose);
                
                for (int frameNo : frames.keySet()) {
                    PreviewView.KeyFrame kf = frames.get(frameNo);
                    JSONObject kfObj = new JSONObject();
                    
                    kfObj.put("cX", (double)kf.cX); 
                    kfObj.put("cY", (double)kf.cY);
                    kfObj.put("hR", (double)kf.hR); 
                    kfObj.put("hl1", (double)kf.hl1); 
                    kfObj.put("hl2", (double)kf.hl2);
                    kfObj.put("hr1", (double)kf.hr1); 
                    kfObj.put("hr2", (double)kf.hr2);
                    kfObj.put("ll1", (double)kf.ll1); 
                    kfObj.put("ll2", (double)kf.ll2);
                    kfObj.put("f1", (double)kf.f1); 
                    kfObj.put("lr1", (double)kf.lr1);
                    kfObj.put("lr2", (double)kf.lr2); 
                    kfObj.put("f2", (double)kf.f2);
                    
                    poseObj.put(String.valueOf(frameNo), kfObj);
                }
                animObj.put("pose_" + pose, poseObj);
            }
            root.put(animName, animObj);
            writeRootObject(root);
        } catch (Exception e) { 
            e.printStackTrace(); 
        }
    }

    // LOAD ANIMATION FROM PHONE DOCUMENTS
    public static HashMap<Integer, HashMap<Integer, PreviewView.KeyFrame>> loadAnimation(Context ctx, String animName) {
        HashMap<Integer, HashMap<Integer, PreviewView.KeyFrame>> timelines = new HashMap<>();
        for (int i = 1; i <= 5; i++) timelines.put(i, new HashMap<Integer, PreviewView.KeyFrame>());

        try {
            JSONObject root = readRootObject();
            if (!root.has(animName)) return timelines;
            
            JSONObject animObj = root.getJSONObject(animName);
            for (int pose = 1; pose <= 5; pose++) {
                String poseKey = "pose_" + pose;
                if (animObj.has(poseKey)) {
                    JSONObject poseObj = animObj.getJSONObject(poseKey);
                    Iterator<String> keys = poseObj.keys();
                    while (keys.hasNext()) {
                        String frameStr = keys.next();
                        int frameNo = Integer.parseInt(frameStr);
                        JSONObject kfObj = poseObj.getJSONObject(frameStr);
                        
                        PreviewView.KeyFrame kf = new PreviewView.KeyFrame(frameNo,
                            0f, 
                            0f, 
                            (float)kfObj.getDouble("hR"),
                            (float)kfObj.getDouble("hl1"), (float)kfObj.getDouble("hl2"), 
                            (float)kfObj.getDouble("hr1"), (float)kfObj.getDouble("hr2"),
                            (float)kfObj.getDouble("ll1"), (float)kfObj.getDouble("ll2"), 
                            (float)kfObj.getDouble("f1"), (float)kfObj.getDouble("lr1"), 
                            (float)kfObj.getDouble("lr2"), (float)kfObj.getDouble("f2")
                        );
                        timelines.get(pose).put(frameNo, kf);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return timelines;
    }

    // GET ALL SAVED ANIMATION NAMES
    public static ArrayList<String> getSavedAnimationNames(Context ctx) {
        ArrayList<String> names = new ArrayList<>();
        try {
            JSONObject root = readRootObject();
            Iterator<String> keys = root.keys();
            while (keys.hasNext()) names.add(keys.next());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return names;
    }
}
